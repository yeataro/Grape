import { floatingSurface } from "/src/ui/floating.ts";
import { mountBuildInfo } from "/apps/web/build-info.ts";
import { icon } from "/src/features/node-browser.ts";
import { mountHover } from "/src/ui/hover.ts";
import { currentSources } from "/src/modules/sources-current.ts";
import {
  fixedValues,
  FIXED_VALUES_PIN
} from "/src/modules/fixed-values.ts";
import { vectorWidget } from "/src/features/vector-control.ts";
import { browserIdentity } from "/src/adapters/browser/identity.ts";
import { functionNetworks } from "/src/modules/function-networks.ts";
import {
  functionOperations,
  functionProfile
} from "/src/modules/function-operations.ts";
import { networkModule } from "/src/modules/networks.ts";
import { probeDefinitions } from "/src/modules/package-probe.ts";
import { extentModule } from "/src/modules/extents.ts";
import { BrowserLibraryStore } from "/src/adapters/browser/library.ts";
import { PersonalLibrary } from "/src/application/personal.ts";
import { mountPersonal } from "/apps/web/personal.ts";
import {
  currentOutputModule,
  currentGraphKinds,
  currentImageKind,
  currentOutputText
} from "/src/modules/image-current.ts";
import { shellText, shellPresentation, shellDefaults } from "/apps/web/shell-copy.ts";
import { Definitions } from "/src/definitions/registry.ts";
import { basicNodes, nodeText } from "/src/modules/nodes.ts";
import {
  graphKinds,
  imageKind,
  stages,
  esProfile
} from "/src/modules/image.ts";
import { EditorApplication } from "/src/application/editor.ts";
import { decodeInput } from "/src/persistence/png.ts";
import { renderDocumentPNG } from "/src/adapters/browser/png.ts";
import {
  BrowserStorage,
  browserOutput,
  downloadBytes
} from "/src/adapters/browser/storage.ts";
import { browserFeedback } from "/src/adapters/browser/presentation.ts";
import { Localization } from "/src/localization/service.ts";
import { Workspace } from "/src/ui/workspace.ts";
import { PanelRenderer } from "/src/ui/mount.ts";
import { WidgetRegistry } from "/src/ui/widgets.ts";
import {
  canvasType,
  canvasCommands,
  canvasText
} from "/src/features/canvas.ts";
import { inspectorType, inspectorText } from "/src/features/inspector.ts";
import { actionsType, actionsText } from "/src/features/actions.ts";
import { codeType, codeText } from "/src/features/code.ts";
import {
  jsonWidget,
  numberWidget,
  choiceWidget,
  controlsText
} from "/src/features/controls.ts";
const definitions = new Definitions();
stages.forEach((s) => definitions.registerStage(s));
definitions.register(basicNodes);
definitions.register(fixedValues);
definitions.register(networkModule);
definitions.register(extentModule);
definitions.register(currentSources);
definitions.register(functionNetworks);
definitions.register(functionOperations);
definitions.register(graphKinds);
definitions.registerKind(imageKind);
definitions.register(currentOutputModule);
definitions.register(currentGraphKinds);
definitions.registerKind(currentImageKind);
const locale = new Localization();
locale.registerModule(shellPresentation, shellDefaults);
for (const contribution of [
  nodeText,
  currentOutputText,
  canvasText,
  inspectorText,
  actionsText,
  codeText,
  controlsText
])
  locale.registerModule(contribution.presentation, contribution.defaults);
const text = (key, params) => locale.resolve(shellText(key, params)).text;
const feedback = browserFeedback(locale);
const widgets = new WidgetRegistry(feedback);
widgets.register(jsonWidget, (p) => p.spec.type === "json");
widgets.register(numberWidget, (p) => p.spec.type === "number");
widgets.register(choiceWidget, (p) => p.spec.type === "choice");
widgets.register(
  vectorWidget,
  (p) => p.spec.presentation.widget === "grape.widget.vector" && Array.isArray(p.value)
);
const application = new EditorApplication(
  definitions,
  browserIdentity(),
  currentImageKind.ref,
  functionProfile,
  new BrowserStorage(),
  browserOutput,
  probeDefinitions
);
const app = document.querySelector("#app");
app.innerHTML = '<header><div class="brand"><svg class="grape-mark" viewBox="0 0 64 64" width="28" height="28" aria-hidden="true"><circle cx="20" cy="23" r="11" fill="#bfa5f4"/><circle cx="44" cy="23" r="11" fill="#a98be2"/><circle cx="32" cy="44" r="11" fill="#b499ef"/></svg> Grape <small>SHADER WORKSPACE</small></div><nav aria-label="Document actions"></nav><div class="status"><span id="save-state"></span><span class="host">Host-free</span></div></header><div id="message" role="status"></div><div id="actions"></div><main><section id="canvases"></section><aside id="inspector"></aside></main><section id="code"></section><footer><span data-hint="connections">Click an output port, then an input to connect. Shift-click replaces a connection.</span><span data-hint="navigation">Scroll to zoom · Drag empty space to pan</span></footer><dialog id="open-dialog"><h2>Open saved document</h2><div id="saved-list"></div><button id="cancel-open">Cancel</button></dialog><dialog id="recovery"><h2>Document retained</h2><p id="recovery-message"></p><button id="export-original">Export original</button><button id="close-recovery">Close</button></dialog>';
const staticText = [
  [".brand small", "subtitle"],
  [".host", "hostFree"],
  ["[data-hint=connections]", "connections"],
  ["[data-hint=navigation]", "navigation"],
  ["#open-dialog h2", "openTitle"],
  ["#cancel-open", "cancel"],
  ["#recovery h2", "recoveryTitle"],
  ["#export-original", "original"],
  ["#close-recovery", "close"]
];
const renderShell = () => {
  for (const [selector, key] of staticText)
    app.querySelector(selector).textContent = text(key);
  app.querySelector("nav").setAttribute("aria-label", text("documentActions"));
};
renderShell();
locale.subscribe(renderShell);
mountBuildInfo(app.querySelector(".brand"));
const oldMessage = document.querySelector("#message"), message = document.createElement("button"), statusBar = document.createElement("div"), nav = app.querySelector("nav"), saveState = document.querySelector("#save-state");
message.id = "message";
message.type = "button";
message.ariaLabel = "Read full application status";
message.setAttribute("aria-haspopup", "dialog");
statusBar.className = "application-status";
statusBar.setAttribute("role", "status");
oldMessage.replaceWith(statusBar);
statusBar.append(message);
app.querySelector("footer").append(statusBar);
const statusText = document.createElement("div");
statusText.className = "status-details-text";
statusText.tabIndex = 0;
statusText.setAttribute("role", "region");
statusText.ariaLabel = "Full current application status";
const statusView = floatingSurface({
  host: app,
  trigger: message,
  content: statusText,
  title: "Application status details",
  closeLabel: "Close status details",
  kind: "anchored",
  width: 680,
  maxHeight: 420,
  beforeOpen: () => !!message.textContent,
  fallbackFocus: () => nav.querySelector("button:not(:disabled)")
});
const closeStatus = () => statusView.close();
message.onclick = () => {
  statusText.textContent = message.textContent;
  statusView.toggle();
};
const setMessage = (text2) => {
  message.textContent = text2;
  message.disabled = !text2;
  statusText.textContent = text2;
  if (!text2) closeStatus();
};
setMessage("");
const errors = /* @__PURE__ */ new Map();
const success = (text2) => {
  if (!errors.size) setMessage(text2);
};
const renderErrors = () => {
  setMessage([...errors.values()].join(" · "));
  message.classList.toggle("error", !!errors.size);
  statusBar.setAttribute("role", errors.size ? "alert" : "status");
};
const report = (error, key = "operation") => {
  errors.set(key, error instanceof Error ? error.message : String(error));
  renderErrors();
};
const action = (key, fn) => {
  const button = document.createElement("button");
  button.dataset.action = key;
  const symbol = {
    new: "add",
    save: "save",
    open: "folder",
    file: "folder",
    export: "download",
    png: "image",
    generate: "code",
    second: "panels",
    lock: "lock"
  };
  const renderAction = () => button.replaceChildren(
    icon(symbol[key] ?? "folder"),
    document.createTextNode(text(key))
  );
  renderAction();
  locale.subscribe(renderAction);
  button.addEventListener("click", () => {
    try {
      Promise.resolve(fn()).then(() => {
        if (errors.delete(key)) renderErrors();
      }).catch((error) => report(error, key));
    } catch (error) {
      report(error, key);
    }
  });
  nav.append(button);
  return button;
};
let workspace = null, renderer = null, canvasCount = 0;
const footer = app.querySelector("footer");
const outputTrigger = document.createElement("button"), output = app.querySelector("#code");
outputTrigger.type = "button";
outputTrigger.textContent = "Shader output";
footer.append(outputTrigger);
output.tabIndex = 0;
const outputView = floatingSurface({
  host: app,
  trigger: outputTrigger,
  content: output,
  title: "Shader output and diagnostics",
  closeLabel: "Close shader output",
  kind: "anchored",
  width: 860,
  maxHeight: 550,
  align: "end",
  dismissOutside: false
});
outputTrigger.onclick = () => outputView.toggle();
const hover = mountHover(app, () => application.busy || application.saving);
function buildWorkspace() {
  hover.invalidate();
  renderer?.dispose();
  workspace?.dispose();
  document.querySelector("#canvases").replaceChildren();
  document.querySelector("#inspector").replaceChildren();
  document.querySelector("#code").replaceChildren();
  document.querySelector("#actions").replaceChildren();
  workspace = new Workspace(application);
  workspace.register(canvasType);
  workspace.register(inspectorType(widgets, locale));
  workspace.register(
    actionsType(
      application.catalog().map(
        (item) => item.ref.moduleId === FIXED_VALUES_PIN.moduleId && item.ref.typeId === "float" ? {
          ...item,
          presentation: {
            ...item.presentation,
            label: {
              ...item.presentation.label,
              key: "float.authoring",
              fallback: "Float (fixed)"
            }
          }
        } : item
      ),
      () => ({
        undo: application.canUndo,
        redo: application.canRedo,
        editing: !application.readonly && !application.busy
      })
    )
  );
  workspace.register(
    codeType(() => ({
      compilation: application.compilation,
      snapshot: application.snapshot
    }))
  );
  canvasCount = 0;
  workspace.open({
    id: "actions",
    typeId: "grape.panel.actions",
    viewStateVersion: 1,
    state: {},
    paneId: "actions",
    hidden: false
  });
  workspace.open({
    id: "inspector",
    typeId: "grape.panel.inspector",
    viewStateVersion: 1,
    state: {},
    paneId: "inspector",
    hidden: false
  });
  workspace.open({
    id: "code",
    typeId: "grape.panel.code",
    viewStateVersion: 1,
    state: {},
    paneId: "code",
    hidden: false
  });
  addCanvas();
  renderer = new PanelRenderer(
    workspace,
    locale,
    (pane, id) => ({
      protocol: "grape.dom.v1",
      target: document.getElementById(pane)
    }),
    feedback
  );
}
function addCanvas() {
  const context = application.context(), id = "canvas-" + ++canvasCount;
  const container = document.createElement("section");
  container.id = id;
  container.className = "canvas-pane";
  const label = document.createElement("div");
  label.className = "pane-title";
  label.textContent = text("canvas", { number: canvasCount });
  container.append(label);
  document.querySelector("#canvases").append(container);
  workspace.open({
    id,
    typeId: canvasType.typeId,
    viewStateVersion: 1,
    state: {},
    paneId: id,
    hidden: false,
    contextId: context.id
  });
  workspace.activate(id);
}
application.grant(canvasType.typeId, canvasCommands);
application.grant("grape.panel.actions", [
  "grape.node.add",
  "grape.node.delete",
  "grape.undo",
  "grape.redo"
]);
application.grant("grape.panel.inspector", [
  "grape.edge.disconnect",
  "grape.node.rename"
]);
const replacing = () => {
  if (application.busy) throw Error(text("gestureBusy"));
  if (workspace?.records().some((r) => r.instance && !r.instance.canClose()))
    throw Error(text("draftBusy"));
  return !application.dirty || confirm(text("discard"));
};
function prepareReplace() {
  renderer?.dispose();
  renderer = null;
  workspace?.dispose();
  workspace = null;
}
action("new", () => {
  if (!replacing()) return;
  prepareReplace();
  application.newDocument();
  buildWorkspace();
});
const upgradeButton = document.createElement("button");
upgradeButton.textContent = "Upgrade subgraph owners";
upgradeButton.onclick = () => {
  try {
    if (!replacing()) return;
    prepareReplace();
    application.upgradeOwners();
    buildWorkspace();
    setMessage(
      "Subgraph owners upgraded explicitly; existing definitions remain expanded. Save to retain the upgraded document."
    );
  } catch (error) {
    report(error);
  }
};
nav.append(upgradeButton);
const saveButton = action("save", async () => {
  await application.save();
  success(text("stored"));
});
action("open", async () => {
  const list = document.querySelector("#saved-list");
  list.replaceChildren();
  for (const entry of await application.savedDocuments()) {
    const b = document.createElement("button");
    b.textContent = entry.name;
    b.dataset.documentKey = entry.key;
    b.onclick = () => {
      void (async () => {
        if (!replacing()) return;
        const result = await application.reopen(entry.key);
        if (result.status === "editable") {
          buildWorkspace();
          document.querySelector("#open-dialog").close();
        } else recovery(result.raw, result.reason);
      })().catch(report);
    };
    list.append(b);
  }
  if (!list.childNodes.length) list.textContent = text("noDocuments");
  document.querySelector("#open-dialog").showModal();
});
action("export", async () => {
  await application.download();
  success(text("exported"));
});
const pngDialog = document.createElement("dialog");
const pngTitle = document.createElement("h2"), pngImage = document.createElement("img"), pngDownload = document.createElement("button"), pngClose = document.createElement("button");
pngTitle.textContent = text("pngTitle");
pngDownload.textContent = text("pngDownload");
pngClose.textContent = text("cancel");
pngDialog.style.width = "min(1100px, 90vw)";
pngImage.alt = text("pngTitle");
pngImage.style.maxWidth = "100%";
pngImage.style.maxHeight = "65vh";
pngImage.style.display = "block";
pngImage.style.margin = "0 auto 16px";
pngDialog.append(pngTitle, pngImage, pngDownload, pngClose);
app.append(pngDialog);
let pngTicket = 0, pngURL = "", pngBytes = null, pngName = "";
const cancelPNG = () => {
  pngTicket++;
  pngBytes = null;
  if (pngURL) URL.revokeObjectURL(pngURL);
  pngURL = "";
  pngImage.removeAttribute("src");
  pngDialog.close();
};
pngClose.onclick = cancelPNG;
pngDialog.addEventListener("cancel", (event) => {
  event.preventDefault();
  cancelPNG();
});
pngDownload.onclick = () => {
  if (pngBytes)
    void downloadBytes(pngName, pngBytes.slice().buffer).catch(report);
};
action("png", async () => {
  cancelPNG();
  const ticket = pngTicket, snapshot = application.snapshot;
  const pane = document.querySelector(".canvas-pane");
  const layout = /* @__PURE__ */ new Map();
  pane?.querySelectorAll(".node[data-node]").forEach(
    (node) => layout.set(node.dataset.node, {
      width: node.offsetWidth,
      height: node.offsetHeight
    })
  );
  const stage = snapshot.document.graph.stages.find(
    (s) => s.network.nodes.some((n) => layout.has(n.id))
  );
  if (!stage) throw Error("PNG_LAYOUT_MISSING");
  pngDownload.disabled = true;
  pngDialog.showModal();
  try {
    const bytes = await renderDocumentPNG(snapshot.document, stage.id, layout);
    if (ticket !== pngTicket) return;
    pngBytes = bytes;
    pngName = `${snapshot.document.graph.name}-${snapshot.document.graph.kind.kindId}-${stage.key}.png`;
    pngURL = URL.createObjectURL(
      new Blob([bytes.slice().buffer], { type: "image/png" })
    );
    pngImage.src = pngURL;
    pngDownload.disabled = false;
  } catch (error) {
    if (ticket === pngTicket) {
      cancelPNG();
      throw error;
    }
  }
});
const input = document.createElement("input");
input.type = "file";
input.setAttribute("aria-label", "Open document file");
input.accept = ".json,.grape.json,.png,application/json,image/png";
input.hidden = true;
app.append(input);
action("file", () => {
  input.click();
});
input.addEventListener("change", () => {
  void (async () => {
    const file = input.files?.[0];
    if (!file) return;
    closeReview();
    const ticket = reviewTicket;
    const base = application.snapshot;
    recovery(file, "READING_INPUT");
    let bytes;
    try {
      bytes = await file.arrayBuffer();
    } catch {
      if (ticket === reviewTicket) recovery(file, "FILE_READ_FAILED");
      input.value = "";
      return;
    }
    if (ticket !== reviewTicket) return;
    if (base.loadId !== application.snapshot.loadId || base.revision !== application.snapshot.revision) {
      recovery(bytes, "OPEN_SUPERSEDED");
      input.value = "";
      return;
    }
    let raw;
    try {
      raw = decodeInput(new Uint8Array(bytes), file.name);
    } catch (error) {
      recovery(bytes, error instanceof Error ? error.message : String(error));
      input.value = "";
      return;
    }
    currentReview = application.inspectText(raw);
    document.querySelector("#recovery h2").textContent = text("reviewTitle");
    recovery(bytes, currentReview.status + ": " + currentReview.reason);
    reviewDetails.textContent = JSON.stringify(
      {
        diagnostics: currentReview.diagnostics,
        repairs: currentReview.repairs,
        provenance: currentReview.provenance,
        unknownPaths: currentReview.read.status === "recovery-readonly" ? currentReview.read.unknownPaths : [],
        candidate: currentReview.candidate
      },
      null,
      2
    );
    rawPreview.textContent = raw.slice(0, 12e3);
    loadButton.hidden = currentReview.read.status !== "editable" || !currentReview.document || currentReview.reason === "NETWORK_SIZE";
    refreshReplacement();
    input.value = "";
  })().catch(report);
});
action("generate", () => {
  const result = application.generate();
  if (result.status !== "success")
    throw Error(
      result.diagnostics.map((d) => d.code + ": " + d.message).join(" · ")
    );
});
action("second", () => {
  addCanvas();
});
const lockButton = action(
  "lock",
  () => application.setReadonly(!application.readonly)
);
lockButton.setAttribute("aria-checked", "false");
let original = "";
let currentReview = null, reviewTicket = 0;
const reviewDialog = document.querySelector("#recovery");
reviewDialog.style.width = "min(900px, 90vw)";
const reviewDetails = document.createElement("pre"), rawPreview = document.createElement("pre"), explanation = document.createElement("p"), replacementMessage = document.createElement("p"), acceptButton = document.createElement("button"), loadButton = document.createElement("button");
reviewDetails.setAttribute("aria-label", text("reviewDetails"));
rawPreview.setAttribute("aria-label", text("originalPreview"));
reviewDetails.style.maxHeight = "30vh";
rawPreview.style.maxHeight = "15vh";
reviewDetails.style.overflow = rawPreview.style.overflow = "auto";
explanation.textContent = text("loadExplanation");
replacementMessage.id = "replacement-message";
replacementMessage.setAttribute("role", "status");
acceptButton.textContent = text("acceptImport");
loadButton.textContent = text("openPreserved");
acceptButton.hidden = loadButton.hidden = true;
reviewDialog.append(
  explanation,
  reviewDetails,
  rawPreview,
  replacementMessage,
  acceptButton,
  loadButton
);
function refreshReplacement() {
  if (!currentReview) {
    replacementMessage.textContent = "";
    return;
  }
  const eligibility = application.replacementEligibility(currentReview);
  acceptButton.hidden = !currentReview.candidate;
  acceptButton.disabled = !eligibility.available;
  const code = eligibility.available ? null : eligibility.code;
  replacementMessage.textContent = !currentReview.candidate ? "" : code === null ? text("replaceReady") : code === "IMPORT_DEFINITIONS" ? text("replaceDefinitions") : code === "IMPORT_STALE" || code === "REVIEW_CLOSED" ? text("replaceStale", { code }) : code === "IMPORT_READONLY" ? text("replaceReadonly") : code === "HISTORY_BUSY" ? text("replaceBusy") : text("replaceUnavailable", { code });
  loadButton.disabled = application.readonly || application.busy || code === "IMPORT_STALE" || code === "REVIEW_CLOSED";
}
function closeReview() {
  reviewTicket++;
  if (currentReview) application.cancelReview(currentReview);
  currentReview = null;
  reviewDetails.textContent = rawPreview.textContent = "";
  replacementMessage.textContent = "";
  acceptButton.hidden = loadButton.hidden = true;
  reviewDialog.close();
  input.value = "";
}
reviewDialog.addEventListener("cancel", (event) => {
  event.preventDefault();
  closeReview();
});
acceptButton.onclick = () => {
  try {
    if (workspace?.records().some((r) => r.instance && !r.instance.canClose()))
      throw Error(text("draftBusy"));
    if (currentReview) application.acceptReview(currentReview);
    closeReview();
  } catch (error) {
    document.querySelector("#recovery-message").textContent = error instanceof Error ? error.message : String(error);
    refreshReplacement();
  }
};
loadButton.onclick = () => {
  try {
    if (!currentReview || !replacing()) return;
    application.openReviewed(currentReview);
    buildWorkspace();
    closeReview();
  } catch (error) {
    document.querySelector("#recovery-message").textContent = error instanceof Error ? error.message : String(error);
  }
};
function recovery(raw, reason) {
  original = raw;
  document.querySelector("#recovery-message").textContent = text("recovery", {
    reason
  });
  if (!reviewDialog.open) reviewDialog.showModal();
}
document.querySelector("#export-original").addEventListener(
  "click",
  () => void downloadBytes("recovery-original.json", original)
);
document.querySelector("#close-recovery").addEventListener("click", closeReview);
document.querySelector("#cancel-open").addEventListener(
  "click",
  () => document.querySelector("#open-dialog").close()
);
application.subscribe(() => {
  hover.invalidate();
  refreshReplacement();
  saveState.textContent = application.saving ? text("saving") : application.dirty ? text("dirty") : text("saved");
  saveButton.disabled = application.saving;
  lockButton.setAttribute("aria-checked", String(application.readonly));
});
application.newDocument();
buildWorkspace();
mountPersonal(
  nav,
  application,
  () => {
    const id = workspace?.records().find((r) => r.saved.id === "inspector")?.update.target?.scope.contextId;
    if (!id) throw Error("Select a Canvas first.");
    return application.context(id);
  },
  new PersonalLibrary(
    new BrowserLibraryStore(),
    definitions.pin(definitions.pins()),
    functionProfile,
    probeDefinitions
  ),
  (error, operation) => {
    const key = "personal:" + operation;
    if (error === void 0) {
      if (errors.delete(key)) renderErrors();
    } else report(error, key);
  }
);
const menuTrigger = document.createElement("button"), menuContent = document.createElement("div"), hintsTrigger = document.createElement("button"), hintsContent = document.createElement("div");
menuTrigger.type = "button";
menuTrigger.textContent = "Project actions";
menuTrigger.className = "project-actions";
menuContent.className = "function-actions";
menuContent.tabIndex = -1;
const documentGroup = document.createElement("div"), workspaceGroup = document.createElement("div");
for (const [group, label] of [
  [documentGroup, "Documents and library"],
  [workspaceGroup, "Workspace"]
]) {
  group.setAttribute("role", "group");
  group.ariaLabel = label;
  menuContent.append(group);
}
for (const child of Array.from(nav.children)) {
  const key = child.dataset.action;
  if (!(child instanceof HTMLButtonElement)) app.append(child);
  else if (key !== "save" && key !== "generate") {
    child.setAttribute(
      "role",
      key === "lock" ? "menuitemcheckbox" : "menuitem"
    );
    (key === "second" || key === "lock" ? workspaceGroup : documentGroup).append(child);
  }
}
footer.prepend(menuTrigger);
const projectMenu = floatingSurface({
  host: app,
  trigger: menuTrigger,
  content: menuContent,
  title: "Project actions",
  closeLabel: "Close project actions",
  kind: "menu",
  width: 310,
  maxHeight: 520
});
menuTrigger.onclick = () => projectMenu.toggle();
menuContent.addEventListener("click", (event) => {
  const action2 = event.target.closest("button")?.dataset.action;
  if (action2 && ["new", "export", "file", "second", "lock"].includes(action2))
    projectMenu.close(false);
});
hintsTrigger.type = "button";
hintsTrigger.textContent = "Hints";
hintsContent.tabIndex = 0;
for (const hint of Array.from(footer.querySelectorAll(":scope > span")))
  hintsContent.append(hint);
const inspectHint = document.createElement("span");
inspectHint.textContent = "F2 · Read the focused object information (read-only). Close or Escape returns focus.";
hintsContent.append(inspectHint);
footer.append(hintsTrigger);
const hintsView = floatingSurface({
  host: app,
  trigger: hintsTrigger,
  content: hintsContent,
  title: "Workspace hints",
  closeLabel: "Close hints",
  kind: "anchored",
  width: 370,
  maxHeight: 300,
  align: "end"
});
hintsTrigger.onclick = () => hintsView.toggle();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZmxvYXRpbmdTdXJmYWNlIH0gZnJvbSBcIi4uLy4uL3NyYy91aS9mbG9hdGluZy50c1wiO1xuaW1wb3J0IHsgbW91bnRCdWlsZEluZm8gfSBmcm9tIFwiLi9idWlsZC1pbmZvLnRzXCI7XG5pbXBvcnQgeyBpY29uIH0gZnJvbSBcIi4uLy4uL3NyYy9mZWF0dXJlcy9ub2RlLWJyb3dzZXIudHNcIjtcbmltcG9ydCB7IG1vdW50SG92ZXIgfSBmcm9tIFwiLi4vLi4vc3JjL3VpL2hvdmVyLnRzXCI7XG5pbXBvcnQgeyBjdXJyZW50U291cmNlcyB9IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9zb3VyY2VzLWN1cnJlbnQudHNcIjtcbmltcG9ydCB7XG4gIGZpeGVkVmFsdWVzLFxuICBGSVhFRF9WQUxVRVNfUElOLFxufSBmcm9tIFwiLi4vLi4vc3JjL21vZHVsZXMvZml4ZWQtdmFsdWVzLnRzXCI7XG5pbXBvcnQgeyB2ZWN0b3JXaWRnZXQgfSBmcm9tIFwiLi4vLi4vc3JjL2ZlYXR1cmVzL3ZlY3Rvci1jb250cm9sLnRzXCI7XG5pbXBvcnQgeyBicm93c2VySWRlbnRpdHkgfSBmcm9tIFwiLi4vLi4vc3JjL2FkYXB0ZXJzL2Jyb3dzZXIvaWRlbnRpdHkudHNcIjtcbmltcG9ydCB7IGZ1bmN0aW9uTmV0d29ya3MgfSBmcm9tIFwiLi4vLi4vc3JjL21vZHVsZXMvZnVuY3Rpb24tbmV0d29ya3MudHNcIjtcbmltcG9ydCB7XG4gIGZ1bmN0aW9uT3BlcmF0aW9ucyxcbiAgZnVuY3Rpb25Qcm9maWxlLFxufSBmcm9tIFwiLi4vLi4vc3JjL21vZHVsZXMvZnVuY3Rpb24tb3BlcmF0aW9ucy50c1wiO1xuaW1wb3J0IHsgbmV0d29ya01vZHVsZSB9IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9uZXR3b3Jrcy50c1wiO1xuaW1wb3J0IHsgcHJvYmVEZWZpbml0aW9ucyB9IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9wYWNrYWdlLXByb2JlLnRzXCI7XG5pbXBvcnQgeyBleHRlbnRNb2R1bGUgfSBmcm9tIFwiLi4vLi4vc3JjL21vZHVsZXMvZXh0ZW50cy50c1wiO1xuaW1wb3J0IHsgQnJvd3NlckxpYnJhcnlTdG9yZSB9IGZyb20gXCIuLi8uLi9zcmMvYWRhcHRlcnMvYnJvd3Nlci9saWJyYXJ5LnRzXCI7XG5pbXBvcnQgeyBQZXJzb25hbExpYnJhcnkgfSBmcm9tIFwiLi4vLi4vc3JjL2FwcGxpY2F0aW9uL3BlcnNvbmFsLnRzXCI7XG5pbXBvcnQgeyBtb3VudFBlcnNvbmFsIH0gZnJvbSBcIi4vcGVyc29uYWwudHNcIjtcbmltcG9ydCB7XG4gIGN1cnJlbnRPdXRwdXRNb2R1bGUsXG4gIGN1cnJlbnRHcmFwaEtpbmRzLFxuICBjdXJyZW50SW1hZ2VLaW5kLFxuICBjdXJyZW50T3V0cHV0VGV4dCxcbn0gZnJvbSBcIi4uLy4uL3NyYy9tb2R1bGVzL2ltYWdlLWN1cnJlbnQudHNcIjtcbmltcG9ydCB7IHNoZWxsVGV4dCwgc2hlbGxQcmVzZW50YXRpb24sIHNoZWxsRGVmYXVsdHMgfSBmcm9tIFwiLi9zaGVsbC1jb3B5LnRzXCI7XG5pbXBvcnQgeyBEZWZpbml0aW9ucyB9IGZyb20gXCIuLi8uLi9zcmMvZGVmaW5pdGlvbnMvcmVnaXN0cnkudHNcIjtcbmltcG9ydCB7IGJhc2ljTm9kZXMsIG5vZGVUZXh0IH0gZnJvbSBcIi4uLy4uL3NyYy9tb2R1bGVzL25vZGVzLnRzXCI7XG5pbXBvcnQge1xuICBncmFwaEtpbmRzLFxuICBpbWFnZUtpbmQsXG4gIHN0YWdlcyxcbiAgZXNQcm9maWxlLFxufSBmcm9tIFwiLi4vLi4vc3JjL21vZHVsZXMvaW1hZ2UudHNcIjtcbmltcG9ydCB7IEVkaXRvckFwcGxpY2F0aW9uIH0gZnJvbSBcIi4uLy4uL3NyYy9hcHBsaWNhdGlvbi9lZGl0b3IudHNcIjtcbmltcG9ydCB0eXBlIHsgRG9jdW1lbnRJbnNwZWN0aW9uIH0gZnJvbSBcIi4uLy4uL3NyYy9hcHBsaWNhdGlvbi9pbnNwZWN0aW9uLnRzXCI7XG5pbXBvcnQgeyBkZWNvZGVJbnB1dCB9IGZyb20gXCIuLi8uLi9zcmMvcGVyc2lzdGVuY2UvcG5nLnRzXCI7XG5pbXBvcnQgeyByZW5kZXJEb2N1bWVudFBORyB9IGZyb20gXCIuLi8uLi9zcmMvYWRhcHRlcnMvYnJvd3Nlci9wbmcudHNcIjtcbmltcG9ydCB7XG4gIEJyb3dzZXJTdG9yYWdlLFxuICBicm93c2VyT3V0cHV0LFxuICBkb3dubG9hZEJ5dGVzLFxufSBmcm9tIFwiLi4vLi4vc3JjL2FkYXB0ZXJzL2Jyb3dzZXIvc3RvcmFnZS50c1wiO1xuaW1wb3J0IHsgYnJvd3NlckZlZWRiYWNrIH0gZnJvbSBcIi4uLy4uL3NyYy9hZGFwdGVycy9icm93c2VyL3ByZXNlbnRhdGlvbi50c1wiO1xuaW1wb3J0IHsgTG9jYWxpemF0aW9uIH0gZnJvbSBcIi4uLy4uL3NyYy9sb2NhbGl6YXRpb24vc2VydmljZS50c1wiO1xuaW1wb3J0IHsgV29ya3NwYWNlIH0gZnJvbSBcIi4uLy4uL3NyYy91aS93b3Jrc3BhY2UudHNcIjtcbmltcG9ydCB7IFBhbmVsUmVuZGVyZXIgfSBmcm9tIFwiLi4vLi4vc3JjL3VpL21vdW50LnRzXCI7XG5pbXBvcnQgeyBXaWRnZXRSZWdpc3RyeSB9IGZyb20gXCIuLi8uLi9zcmMvdWkvd2lkZ2V0cy50c1wiO1xuaW1wb3J0IHtcbiAgY2FudmFzVHlwZSxcbiAgY2FudmFzQ29tbWFuZHMsXG4gIGNhbnZhc1RleHQsXG59IGZyb20gXCIuLi8uLi9zcmMvZmVhdHVyZXMvY2FudmFzLnRzXCI7XG5pbXBvcnQgeyBpbnNwZWN0b3JUeXBlLCBpbnNwZWN0b3JUZXh0IH0gZnJvbSBcIi4uLy4uL3NyYy9mZWF0dXJlcy9pbnNwZWN0b3IudHNcIjtcbmltcG9ydCB7IGFjdGlvbnNUeXBlLCBhY3Rpb25zVGV4dCB9IGZyb20gXCIuLi8uLi9zcmMvZmVhdHVyZXMvYWN0aW9ucy50c1wiO1xuaW1wb3J0IHsgY29kZVR5cGUsIGNvZGVUZXh0IH0gZnJvbSBcIi4uLy4uL3NyYy9mZWF0dXJlcy9jb2RlLnRzXCI7XG5pbXBvcnQge1xuICBqc29uV2lkZ2V0LFxuICBudW1iZXJXaWRnZXQsXG4gIGNob2ljZVdpZGdldCxcbiAgY29udHJvbHNUZXh0LFxufSBmcm9tIFwiLi4vLi4vc3JjL2ZlYXR1cmVzL2NvbnRyb2xzLnRzXCI7XG5cbmNvbnN0IGRlZmluaXRpb25zID0gbmV3IERlZmluaXRpb25zKCk7XG5zdGFnZXMuZm9yRWFjaCgocykgPT4gZGVmaW5pdGlvbnMucmVnaXN0ZXJTdGFnZShzKSk7XG5kZWZpbml0aW9ucy5yZWdpc3RlcihiYXNpY05vZGVzKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyKGZpeGVkVmFsdWVzKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyKG5ldHdvcmtNb2R1bGUpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIoZXh0ZW50TW9kdWxlKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyKGN1cnJlbnRTb3VyY2VzKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyKGZ1bmN0aW9uTmV0d29ya3MpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIoZnVuY3Rpb25PcGVyYXRpb25zKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyKGdyYXBoS2luZHMpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXJLaW5kKGltYWdlS2luZCk7XG5kZWZpbml0aW9ucy5yZWdpc3RlcihjdXJyZW50T3V0cHV0TW9kdWxlKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyKGN1cnJlbnRHcmFwaEtpbmRzKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyS2luZChjdXJyZW50SW1hZ2VLaW5kKTtcbmNvbnN0IGxvY2FsZSA9IG5ldyBMb2NhbGl6YXRpb24oKTtcbmxvY2FsZS5yZWdpc3Rlck1vZHVsZShzaGVsbFByZXNlbnRhdGlvbiwgc2hlbGxEZWZhdWx0cyk7XG5mb3IgKGNvbnN0IGNvbnRyaWJ1dGlvbiBvZiBbXG4gIG5vZGVUZXh0LFxuICBjdXJyZW50T3V0cHV0VGV4dCxcbiAgY2FudmFzVGV4dCxcbiAgaW5zcGVjdG9yVGV4dCxcbiAgYWN0aW9uc1RleHQsXG4gIGNvZGVUZXh0LFxuICBjb250cm9sc1RleHQsXG5dKVxuICBsb2NhbGUucmVnaXN0ZXJNb2R1bGUoY29udHJpYnV0aW9uLnByZXNlbnRhdGlvbiwgY29udHJpYnV0aW9uLmRlZmF1bHRzKTtcbmNvbnN0IHRleHQgPSAoXG4gIGtleTogUGFyYW1ldGVyczx0eXBlb2Ygc2hlbGxUZXh0PlswXSxcbiAgcGFyYW1zPzogUGFyYW1ldGVyczx0eXBlb2Ygc2hlbGxUZXh0PlsxXSxcbikgPT4gbG9jYWxlLnJlc29sdmUoc2hlbGxUZXh0KGtleSwgcGFyYW1zKSkudGV4dDtcbmNvbnN0IGZlZWRiYWNrID0gYnJvd3NlckZlZWRiYWNrKGxvY2FsZSk7XG5jb25zdCB3aWRnZXRzID0gbmV3IFdpZGdldFJlZ2lzdHJ5KGZlZWRiYWNrKTtcbndpZGdldHMucmVnaXN0ZXIoanNvbldpZGdldCwgKHApID0+IHAuc3BlYy50eXBlID09PSBcImpzb25cIik7XG53aWRnZXRzLnJlZ2lzdGVyKG51bWJlcldpZGdldCwgKHApID0+IHAuc3BlYy50eXBlID09PSBcIm51bWJlclwiKTtcbndpZGdldHMucmVnaXN0ZXIoY2hvaWNlV2lkZ2V0LCAocCkgPT4gcC5zcGVjLnR5cGUgPT09IFwiY2hvaWNlXCIpO1xud2lkZ2V0cy5yZWdpc3RlcihcbiAgdmVjdG9yV2lkZ2V0LFxuICAocCkgPT5cbiAgICBwLnNwZWMucHJlc2VudGF0aW9uLndpZGdldCA9PT0gXCJncmFwZS53aWRnZXQudmVjdG9yXCIgJiZcbiAgICBBcnJheS5pc0FycmF5KHAudmFsdWUpLFxuKTtcbmNvbnN0IGFwcGxpY2F0aW9uID0gbmV3IEVkaXRvckFwcGxpY2F0aW9uKFxuICBkZWZpbml0aW9ucyxcbiAgYnJvd3NlcklkZW50aXR5KCksXG4gIGN1cnJlbnRJbWFnZUtpbmQucmVmLFxuICBmdW5jdGlvblByb2ZpbGUsXG4gIG5ldyBCcm93c2VyU3RvcmFnZSgpLFxuICBicm93c2VyT3V0cHV0LFxuICBwcm9iZURlZmluaXRpb25zLFxuKTtcbmNvbnN0IGFwcCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KFwiI2FwcFwiKSE7XG5hcHAuaW5uZXJIVE1MID1cbiAgJzxoZWFkZXI+PGRpdiBjbGFzcz1cImJyYW5kXCI+PHN2ZyBjbGFzcz1cImdyYXBlLW1hcmtcIiB2aWV3Qm94PVwiMCAwIDY0IDY0XCIgd2lkdGg9XCIyOFwiIGhlaWdodD1cIjI4XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PGNpcmNsZSBjeD1cIjIwXCIgY3k9XCIyM1wiIHI9XCIxMVwiIGZpbGw9XCIjYmZhNWY0XCIvPjxjaXJjbGUgY3g9XCI0NFwiIGN5PVwiMjNcIiByPVwiMTFcIiBmaWxsPVwiI2E5OGJlMlwiLz48Y2lyY2xlIGN4PVwiMzJcIiBjeT1cIjQ0XCIgcj1cIjExXCIgZmlsbD1cIiNiNDk5ZWZcIi8+PC9zdmc+IEdyYXBlIDxzbWFsbD5TSEFERVIgV09SS1NQQUNFPC9zbWFsbD48L2Rpdj48bmF2IGFyaWEtbGFiZWw9XCJEb2N1bWVudCBhY3Rpb25zXCI+PC9uYXY+PGRpdiBjbGFzcz1cInN0YXR1c1wiPjxzcGFuIGlkPVwic2F2ZS1zdGF0ZVwiPjwvc3Bhbj48c3BhbiBjbGFzcz1cImhvc3RcIj5Ib3N0LWZyZWU8L3NwYW4+PC9kaXY+PC9oZWFkZXI+PGRpdiBpZD1cIm1lc3NhZ2VcIiByb2xlPVwic3RhdHVzXCI+PC9kaXY+PGRpdiBpZD1cImFjdGlvbnNcIj48L2Rpdj48bWFpbj48c2VjdGlvbiBpZD1cImNhbnZhc2VzXCI+PC9zZWN0aW9uPjxhc2lkZSBpZD1cImluc3BlY3RvclwiPjwvYXNpZGU+PC9tYWluPjxzZWN0aW9uIGlkPVwiY29kZVwiPjwvc2VjdGlvbj48Zm9vdGVyPjxzcGFuIGRhdGEtaGludD1cImNvbm5lY3Rpb25zXCI+Q2xpY2sgYW4gb3V0cHV0IHBvcnQsIHRoZW4gYW4gaW5wdXQgdG8gY29ubmVjdC4gU2hpZnQtY2xpY2sgcmVwbGFjZXMgYSBjb25uZWN0aW9uLjwvc3Bhbj48c3BhbiBkYXRhLWhpbnQ9XCJuYXZpZ2F0aW9uXCI+U2Nyb2xsIHRvIHpvb20gwrcgRHJhZyBlbXB0eSBzcGFjZSB0byBwYW48L3NwYW4+PC9mb290ZXI+PGRpYWxvZyBpZD1cIm9wZW4tZGlhbG9nXCI+PGgyPk9wZW4gc2F2ZWQgZG9jdW1lbnQ8L2gyPjxkaXYgaWQ9XCJzYXZlZC1saXN0XCI+PC9kaXY+PGJ1dHRvbiBpZD1cImNhbmNlbC1vcGVuXCI+Q2FuY2VsPC9idXR0b24+PC9kaWFsb2c+PGRpYWxvZyBpZD1cInJlY292ZXJ5XCI+PGgyPkRvY3VtZW50IHJldGFpbmVkPC9oMj48cCBpZD1cInJlY292ZXJ5LW1lc3NhZ2VcIj48L3A+PGJ1dHRvbiBpZD1cImV4cG9ydC1vcmlnaW5hbFwiPkV4cG9ydCBvcmlnaW5hbDwvYnV0dG9uPjxidXR0b24gaWQ9XCJjbG9zZS1yZWNvdmVyeVwiPkNsb3NlPC9idXR0b24+PC9kaWFsb2c+JztcbmNvbnN0IHN0YXRpY1RleHQgPSBbXG4gIFtcIi5icmFuZCBzbWFsbFwiLCBcInN1YnRpdGxlXCJdLFxuICBbXCIuaG9zdFwiLCBcImhvc3RGcmVlXCJdLFxuICBbXCJbZGF0YS1oaW50PWNvbm5lY3Rpb25zXVwiLCBcImNvbm5lY3Rpb25zXCJdLFxuICBbXCJbZGF0YS1oaW50PW5hdmlnYXRpb25dXCIsIFwibmF2aWdhdGlvblwiXSxcbiAgW1wiI29wZW4tZGlhbG9nIGgyXCIsIFwib3BlblRpdGxlXCJdLFxuICBbXCIjY2FuY2VsLW9wZW5cIiwgXCJjYW5jZWxcIl0sXG4gIFtcIiNyZWNvdmVyeSBoMlwiLCBcInJlY292ZXJ5VGl0bGVcIl0sXG4gIFtcIiNleHBvcnQtb3JpZ2luYWxcIiwgXCJvcmlnaW5hbFwiXSxcbiAgW1wiI2Nsb3NlLXJlY292ZXJ5XCIsIFwiY2xvc2VcIl0sXG5dIGFzIGNvbnN0O1xuY29uc3QgcmVuZGVyU2hlbGwgPSAoKSA9PiB7XG4gIGZvciAoY29uc3QgW3NlbGVjdG9yLCBrZXldIG9mIHN0YXRpY1RleHQpXG4gICAgYXBwLnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpIS50ZXh0Q29udGVudCA9IHRleHQoa2V5KTtcbiAgYXBwLnF1ZXJ5U2VsZWN0b3IoXCJuYXZcIikhLnNldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIiwgdGV4dChcImRvY3VtZW50QWN0aW9uc1wiKSk7XG59O1xucmVuZGVyU2hlbGwoKTtcbmxvY2FsZS5zdWJzY3JpYmUocmVuZGVyU2hlbGwpO1xubW91bnRCdWlsZEluZm8oYXBwLnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KFwiLmJyYW5kXCIpISk7XG5jb25zdCBvbGRNZXNzYWdlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcjxIVE1MRWxlbWVudD4oXCIjbWVzc2FnZVwiKSEsXG4gIG1lc3NhZ2UgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpLFxuICBzdGF0dXNCYXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpLFxuICBuYXYgPSBhcHAucXVlcnlTZWxlY3RvcihcIm5hdlwiKSEsXG4gIHNhdmVTdGF0ZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KFwiI3NhdmUtc3RhdGVcIikhO1xubWVzc2FnZS5pZCA9IFwibWVzc2FnZVwiO1xubWVzc2FnZS50eXBlID0gXCJidXR0b25cIjtcbm1lc3NhZ2UuYXJpYUxhYmVsID0gXCJSZWFkIGZ1bGwgYXBwbGljYXRpb24gc3RhdHVzXCI7XG5tZXNzYWdlLnNldEF0dHJpYnV0ZShcImFyaWEtaGFzcG9wdXBcIiwgXCJkaWFsb2dcIik7XG5zdGF0dXNCYXIuY2xhc3NOYW1lID0gXCJhcHBsaWNhdGlvbi1zdGF0dXNcIjtcbnN0YXR1c0Jhci5zZXRBdHRyaWJ1dGUoXCJyb2xlXCIsIFwic3RhdHVzXCIpO1xub2xkTWVzc2FnZS5yZXBsYWNlV2l0aChzdGF0dXNCYXIpO1xuc3RhdHVzQmFyLmFwcGVuZChtZXNzYWdlKTtcbmFwcC5xdWVyeVNlbGVjdG9yKFwiZm9vdGVyXCIpIS5hcHBlbmQoc3RhdHVzQmFyKTtcbmNvbnN0IHN0YXR1c1RleHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuc3RhdHVzVGV4dC5jbGFzc05hbWUgPSBcInN0YXR1cy1kZXRhaWxzLXRleHRcIjtcbnN0YXR1c1RleHQudGFiSW5kZXggPSAwO1xuc3RhdHVzVGV4dC5zZXRBdHRyaWJ1dGUoXCJyb2xlXCIsIFwicmVnaW9uXCIpO1xuc3RhdHVzVGV4dC5hcmlhTGFiZWwgPSBcIkZ1bGwgY3VycmVudCBhcHBsaWNhdGlvbiBzdGF0dXNcIjtcbmNvbnN0IHN0YXR1c1ZpZXcgPSBmbG9hdGluZ1N1cmZhY2Uoe1xuICBob3N0OiBhcHAsXG4gIHRyaWdnZXI6IG1lc3NhZ2UsXG4gIGNvbnRlbnQ6IHN0YXR1c1RleHQsXG4gIHRpdGxlOiBcIkFwcGxpY2F0aW9uIHN0YXR1cyBkZXRhaWxzXCIsXG4gIGNsb3NlTGFiZWw6IFwiQ2xvc2Ugc3RhdHVzIGRldGFpbHNcIixcbiAga2luZDogXCJhbmNob3JlZFwiLFxuICB3aWR0aDogNjgwLFxuICBtYXhIZWlnaHQ6IDQyMCxcbiAgYmVmb3JlT3BlbjogKCkgPT4gISFtZXNzYWdlLnRleHRDb250ZW50LFxuICBmYWxsYmFja0ZvY3VzOiAoKSA9PlxuICAgIG5hdi5xdWVyeVNlbGVjdG9yPEhUTUxCdXR0b25FbGVtZW50PihcImJ1dHRvbjpub3QoOmRpc2FibGVkKVwiKSxcbn0pO1xuY29uc3QgY2xvc2VTdGF0dXMgPSAoKSA9PiBzdGF0dXNWaWV3LmNsb3NlKCk7XG5tZXNzYWdlLm9uY2xpY2sgPSAoKSA9PiB7XG4gIHN0YXR1c1RleHQudGV4dENvbnRlbnQgPSBtZXNzYWdlLnRleHRDb250ZW50O1xuICBzdGF0dXNWaWV3LnRvZ2dsZSgpO1xufTtcbmNvbnN0IHNldE1lc3NhZ2UgPSAodGV4dDogc3RyaW5nKSA9PiB7XG4gIG1lc3NhZ2UudGV4dENvbnRlbnQgPSB0ZXh0O1xuICBtZXNzYWdlLmRpc2FibGVkID0gIXRleHQ7XG4gIHN0YXR1c1RleHQudGV4dENvbnRlbnQgPSB0ZXh0O1xuICBpZiAoIXRleHQpIGNsb3NlU3RhdHVzKCk7XG59O1xuc2V0TWVzc2FnZShcIlwiKTtcbmNvbnN0IGVycm9ycyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XG5jb25zdCBzdWNjZXNzID0gKHRleHQ6IHN0cmluZykgPT4ge1xuICBpZiAoIWVycm9ycy5zaXplKSBzZXRNZXNzYWdlKHRleHQpO1xufTtcbmNvbnN0IHJlbmRlckVycm9ycyA9ICgpID0+IHtcbiAgc2V0TWVzc2FnZShbLi4uZXJyb3JzLnZhbHVlcygpXS5qb2luKFwiIMK3IFwiKSk7XG4gIG1lc3NhZ2UuY2xhc3NMaXN0LnRvZ2dsZShcImVycm9yXCIsICEhZXJyb3JzLnNpemUpO1xuICBzdGF0dXNCYXIuc2V0QXR0cmlidXRlKFwicm9sZVwiLCBlcnJvcnMuc2l6ZSA/IFwiYWxlcnRcIiA6IFwic3RhdHVzXCIpO1xufTtcbmNvbnN0IHJlcG9ydCA9IChlcnJvcjogdW5rbm93biwga2V5ID0gXCJvcGVyYXRpb25cIikgPT4ge1xuICBlcnJvcnMuc2V0KGtleSwgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpKTtcbiAgcmVuZGVyRXJyb3JzKCk7XG59O1xuY29uc3QgYWN0aW9uID0gKFxuICBrZXk6IFBhcmFtZXRlcnM8dHlwZW9mIHNoZWxsVGV4dD5bMF0sXG4gIGZuOiAoKSA9PiB2b2lkIHwgUHJvbWlzZTx2b2lkPixcbikgPT4ge1xuICBjb25zdCBidXR0b24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpO1xuICBidXR0b24uZGF0YXNldC5hY3Rpb24gPSBrZXk7XG4gIGNvbnN0IHN5bWJvbDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICBuZXc6IFwiYWRkXCIsXG4gICAgc2F2ZTogXCJzYXZlXCIsXG4gICAgb3BlbjogXCJmb2xkZXJcIixcbiAgICBmaWxlOiBcImZvbGRlclwiLFxuICAgIGV4cG9ydDogXCJkb3dubG9hZFwiLFxuICAgIHBuZzogXCJpbWFnZVwiLFxuICAgIGdlbmVyYXRlOiBcImNvZGVcIixcbiAgICBzZWNvbmQ6IFwicGFuZWxzXCIsXG4gICAgbG9jazogXCJsb2NrXCIsXG4gIH07XG4gIGNvbnN0IHJlbmRlckFjdGlvbiA9ICgpID0+XG4gICAgYnV0dG9uLnJlcGxhY2VDaGlsZHJlbihcbiAgICAgIGljb24oc3ltYm9sW2tleV0gPz8gXCJmb2xkZXJcIiksXG4gICAgICBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSh0ZXh0KGtleSkpLFxuICAgICk7XG4gIHJlbmRlckFjdGlvbigpO1xuICBsb2NhbGUuc3Vic2NyaWJlKHJlbmRlckFjdGlvbik7XG4gIGJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBQcm9taXNlLnJlc29sdmUoZm4oKSlcbiAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgIGlmIChlcnJvcnMuZGVsZXRlKGtleSkpIHJlbmRlckVycm9ycygpO1xuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiByZXBvcnQoZXJyb3IsIGtleSkpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXBvcnQoZXJyb3IsIGtleSk7XG4gICAgfVxuICB9KTtcbiAgbmF2LmFwcGVuZChidXR0b24pO1xuICByZXR1cm4gYnV0dG9uO1xufTtcbmxldCB3b3Jrc3BhY2U6IFdvcmtzcGFjZSB8IG51bGwgPSBudWxsLFxuICByZW5kZXJlcjogUGFuZWxSZW5kZXJlciB8IG51bGwgPSBudWxsLFxuICBjYW52YXNDb3VudCA9IDA7XG5jb25zdCBmb290ZXIgPSBhcHAucXVlcnlTZWxlY3RvcjxIVE1MRWxlbWVudD4oXCJmb290ZXJcIikhO1xuY29uc3Qgb3V0cHV0VHJpZ2dlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiksXG4gIG91dHB1dCA9IGFwcC5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PihcIiNjb2RlXCIpITtcbm91dHB1dFRyaWdnZXIudHlwZSA9IFwiYnV0dG9uXCI7XG5vdXRwdXRUcmlnZ2VyLnRleHRDb250ZW50ID0gXCJTaGFkZXIgb3V0cHV0XCI7XG5mb290ZXIuYXBwZW5kKG91dHB1dFRyaWdnZXIpO1xub3V0cHV0LnRhYkluZGV4ID0gMDtcbmNvbnN0IG91dHB1dFZpZXcgPSBmbG9hdGluZ1N1cmZhY2Uoe1xuICBob3N0OiBhcHAsXG4gIHRyaWdnZXI6IG91dHB1dFRyaWdnZXIsXG4gIGNvbnRlbnQ6IG91dHB1dCxcbiAgdGl0bGU6IFwiU2hhZGVyIG91dHB1dCBhbmQgZGlhZ25vc3RpY3NcIixcbiAgY2xvc2VMYWJlbDogXCJDbG9zZSBzaGFkZXIgb3V0cHV0XCIsXG4gIGtpbmQ6IFwiYW5jaG9yZWRcIixcbiAgd2lkdGg6IDg2MCxcbiAgbWF4SGVpZ2h0OiA1NTAsXG4gIGFsaWduOiBcImVuZFwiLFxuICBkaXNtaXNzT3V0c2lkZTogZmFsc2UsXG59KTtcbm91dHB1dFRyaWdnZXIub25jbGljayA9ICgpID0+IG91dHB1dFZpZXcudG9nZ2xlKCk7XG5jb25zdCBob3ZlciA9IG1vdW50SG92ZXIoYXBwLCAoKSA9PiBhcHBsaWNhdGlvbi5idXN5IHx8IGFwcGxpY2F0aW9uLnNhdmluZyk7XG5mdW5jdGlvbiBidWlsZFdvcmtzcGFjZSgpIHtcbiAgaG92ZXIuaW52YWxpZGF0ZSgpO1xuICByZW5kZXJlcj8uZGlzcG9zZSgpO1xuICB3b3Jrc3BhY2U/LmRpc3Bvc2UoKTtcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjYW52YXNlc1wiKSEucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjaW5zcGVjdG9yXCIpIS5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjb2RlXCIpIS5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNhY3Rpb25zXCIpIS5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgd29ya3NwYWNlID0gbmV3IFdvcmtzcGFjZShhcHBsaWNhdGlvbik7XG4gIHdvcmtzcGFjZS5yZWdpc3RlcihjYW52YXNUeXBlKTtcbiAgd29ya3NwYWNlLnJlZ2lzdGVyKGluc3BlY3RvclR5cGUod2lkZ2V0cywgbG9jYWxlKSk7XG4gIHdvcmtzcGFjZS5yZWdpc3RlcihcbiAgICBhY3Rpb25zVHlwZShcbiAgICAgIGFwcGxpY2F0aW9uLmNhdGFsb2coKS5tYXAoKGl0ZW0pID0+XG4gICAgICAgIGl0ZW0ucmVmLm1vZHVsZUlkID09PSBGSVhFRF9WQUxVRVNfUElOLm1vZHVsZUlkICYmXG4gICAgICAgIGl0ZW0ucmVmLnR5cGVJZCA9PT0gXCJmbG9hdFwiXG4gICAgICAgICAgPyB7XG4gICAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICAgIHByZXNlbnRhdGlvbjoge1xuICAgICAgICAgICAgICAgIC4uLml0ZW0ucHJlc2VudGF0aW9uLFxuICAgICAgICAgICAgICAgIGxhYmVsOiB7XG4gICAgICAgICAgICAgICAgICAuLi5pdGVtLnByZXNlbnRhdGlvbi5sYWJlbCxcbiAgICAgICAgICAgICAgICAgIGtleTogXCJmbG9hdC5hdXRob3JpbmdcIixcbiAgICAgICAgICAgICAgICAgIGZhbGxiYWNrOiBcIkZsb2F0IChmaXhlZClcIixcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfVxuICAgICAgICAgIDogaXRlbSxcbiAgICAgICksXG4gICAgICAoKSA9PiAoe1xuICAgICAgICB1bmRvOiBhcHBsaWNhdGlvbi5jYW5VbmRvLFxuICAgICAgICByZWRvOiBhcHBsaWNhdGlvbi5jYW5SZWRvLFxuICAgICAgICBlZGl0aW5nOiAhYXBwbGljYXRpb24ucmVhZG9ubHkgJiYgIWFwcGxpY2F0aW9uLmJ1c3ksXG4gICAgICB9KSxcbiAgICApLFxuICApO1xuICB3b3Jrc3BhY2UucmVnaXN0ZXIoXG4gICAgY29kZVR5cGUoKCkgPT4gKHtcbiAgICAgIGNvbXBpbGF0aW9uOiBhcHBsaWNhdGlvbi5jb21waWxhdGlvbixcbiAgICAgIHNuYXBzaG90OiBhcHBsaWNhdGlvbi5zbmFwc2hvdCxcbiAgICB9KSksXG4gICk7XG4gIGNhbnZhc0NvdW50ID0gMDtcbiAgd29ya3NwYWNlLm9wZW4oe1xuICAgIGlkOiBcImFjdGlvbnNcIixcbiAgICB0eXBlSWQ6IFwiZ3JhcGUucGFuZWwuYWN0aW9uc1wiLFxuICAgIHZpZXdTdGF0ZVZlcnNpb246IDEsXG4gICAgc3RhdGU6IHt9LFxuICAgIHBhbmVJZDogXCJhY3Rpb25zXCIsXG4gICAgaGlkZGVuOiBmYWxzZSxcbiAgfSk7XG4gIHdvcmtzcGFjZS5vcGVuKHtcbiAgICBpZDogXCJpbnNwZWN0b3JcIixcbiAgICB0eXBlSWQ6IFwiZ3JhcGUucGFuZWwuaW5zcGVjdG9yXCIsXG4gICAgdmlld1N0YXRlVmVyc2lvbjogMSxcbiAgICBzdGF0ZToge30sXG4gICAgcGFuZUlkOiBcImluc3BlY3RvclwiLFxuICAgIGhpZGRlbjogZmFsc2UsXG4gIH0pO1xuICB3b3Jrc3BhY2Uub3Blbih7XG4gICAgaWQ6IFwiY29kZVwiLFxuICAgIHR5cGVJZDogXCJncmFwZS5wYW5lbC5jb2RlXCIsXG4gICAgdmlld1N0YXRlVmVyc2lvbjogMSxcbiAgICBzdGF0ZToge30sXG4gICAgcGFuZUlkOiBcImNvZGVcIixcbiAgICBoaWRkZW46IGZhbHNlLFxuICB9KTtcbiAgYWRkQ2FudmFzKCk7XG4gIHJlbmRlcmVyID0gbmV3IFBhbmVsUmVuZGVyZXIoXG4gICAgd29ya3NwYWNlLFxuICAgIGxvY2FsZSxcbiAgICAocGFuZSwgaWQpID0+ICh7XG4gICAgICBwcm90b2NvbDogXCJncmFwZS5kb20udjFcIixcbiAgICAgIHRhcmdldDogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQocGFuZSkhLFxuICAgIH0pLFxuICAgIGZlZWRiYWNrLFxuICApO1xufVxuZnVuY3Rpb24gYWRkQ2FudmFzKCkge1xuICBjb25zdCBjb250ZXh0ID0gYXBwbGljYXRpb24uY29udGV4dCgpLFxuICAgIGlkID0gXCJjYW52YXMtXCIgKyArK2NhbnZhc0NvdW50O1xuICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2VjdGlvblwiKTtcbiAgY29udGFpbmVyLmlkID0gaWQ7XG4gIGNvbnRhaW5lci5jbGFzc05hbWUgPSBcImNhbnZhcy1wYW5lXCI7XG4gIGNvbnN0IGxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgbGFiZWwuY2xhc3NOYW1lID0gXCJwYW5lLXRpdGxlXCI7XG4gIGxhYmVsLnRleHRDb250ZW50ID0gdGV4dChcImNhbnZhc1wiLCB7IG51bWJlcjogY2FudmFzQ291bnQgfSk7XG4gIGNvbnRhaW5lci5hcHBlbmQobGFiZWwpO1xuICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NhbnZhc2VzXCIpIS5hcHBlbmQoY29udGFpbmVyKTtcbiAgd29ya3NwYWNlIS5vcGVuKHtcbiAgICBpZCxcbiAgICB0eXBlSWQ6IGNhbnZhc1R5cGUudHlwZUlkLFxuICAgIHZpZXdTdGF0ZVZlcnNpb246IDEsXG4gICAgc3RhdGU6IHt9LFxuICAgIHBhbmVJZDogaWQsXG4gICAgaGlkZGVuOiBmYWxzZSxcbiAgICBjb250ZXh0SWQ6IGNvbnRleHQuaWQsXG4gIH0pO1xuICB3b3Jrc3BhY2UhLmFjdGl2YXRlKGlkKTtcbn1cbmFwcGxpY2F0aW9uLmdyYW50KGNhbnZhc1R5cGUudHlwZUlkLCBjYW52YXNDb21tYW5kcyk7XG5hcHBsaWNhdGlvbi5ncmFudChcImdyYXBlLnBhbmVsLmFjdGlvbnNcIiwgW1xuICBcImdyYXBlLm5vZGUuYWRkXCIsXG4gIFwiZ3JhcGUubm9kZS5kZWxldGVcIixcbiAgXCJncmFwZS51bmRvXCIsXG4gIFwiZ3JhcGUucmVkb1wiLFxuXSk7XG5hcHBsaWNhdGlvbi5ncmFudChcImdyYXBlLnBhbmVsLmluc3BlY3RvclwiLCBbXG4gIFwiZ3JhcGUuZWRnZS5kaXNjb25uZWN0XCIsXG4gIFwiZ3JhcGUubm9kZS5yZW5hbWVcIixcbl0pO1xuY29uc3QgcmVwbGFjaW5nID0gKCkgPT4ge1xuICBpZiAoYXBwbGljYXRpb24uYnVzeSkgdGhyb3cgRXJyb3IodGV4dChcImdlc3R1cmVCdXN5XCIpKTtcbiAgaWYgKHdvcmtzcGFjZT8ucmVjb3JkcygpLnNvbWUoKHIpID0+IHIuaW5zdGFuY2UgJiYgIXIuaW5zdGFuY2UuY2FuQ2xvc2UoKSkpXG4gICAgdGhyb3cgRXJyb3IodGV4dChcImRyYWZ0QnVzeVwiKSk7XG4gIHJldHVybiAhYXBwbGljYXRpb24uZGlydHkgfHwgY29uZmlybSh0ZXh0KFwiZGlzY2FyZFwiKSk7XG59O1xuLy8gRGlzcG9zZSByb3V0ZWQgcHJlc2VudGF0aW9uIGJlZm9yZSByZXBsYWNpbmcgZG9jdW1lbnQgbGlmZXRpbWVzOyB0aGUgbmV3IGRvY3VtZW50IGdldHMgZnJlc2ggY29udGV4dHMuXG5mdW5jdGlvbiBwcmVwYXJlUmVwbGFjZSgpIHtcbiAgcmVuZGVyZXI/LmRpc3Bvc2UoKTtcbiAgcmVuZGVyZXIgPSBudWxsO1xuICB3b3Jrc3BhY2U/LmRpc3Bvc2UoKTtcbiAgd29ya3NwYWNlID0gbnVsbDtcbn1cbmFjdGlvbihcIm5ld1wiLCAoKSA9PiB7XG4gIGlmICghcmVwbGFjaW5nKCkpIHJldHVybjtcbiAgcHJlcGFyZVJlcGxhY2UoKTtcbiAgYXBwbGljYXRpb24ubmV3RG9jdW1lbnQoKTtcbiAgYnVpbGRXb3Jrc3BhY2UoKTtcbn0pO1xuY29uc3QgdXBncmFkZUJ1dHRvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIik7XG51cGdyYWRlQnV0dG9uLnRleHRDb250ZW50ID0gXCJVcGdyYWRlIHN1YmdyYXBoIG93bmVyc1wiO1xudXBncmFkZUJ1dHRvbi5vbmNsaWNrID0gKCkgPT4ge1xuICB0cnkge1xuICAgIGlmICghcmVwbGFjaW5nKCkpIHJldHVybjtcbiAgICBwcmVwYXJlUmVwbGFjZSgpO1xuICAgIGFwcGxpY2F0aW9uLnVwZ3JhZGVPd25lcnMoKTtcbiAgICBidWlsZFdvcmtzcGFjZSgpO1xuICAgIHNldE1lc3NhZ2UoXG4gICAgICBcIlN1YmdyYXBoIG93bmVycyB1cGdyYWRlZCBleHBsaWNpdGx5OyBleGlzdGluZyBkZWZpbml0aW9ucyByZW1haW4gZXhwYW5kZWQuIFNhdmUgdG8gcmV0YWluIHRoZSB1cGdyYWRlZCBkb2N1bWVudC5cIixcbiAgICApO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJlcG9ydChlcnJvcik7XG4gIH1cbn07XG5uYXYuYXBwZW5kKHVwZ3JhZGVCdXR0b24pO1xuY29uc3Qgc2F2ZUJ1dHRvbiA9IGFjdGlvbihcInNhdmVcIiwgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBhcHBsaWNhdGlvbi5zYXZlKCk7XG4gIHN1Y2Nlc3ModGV4dChcInN0b3JlZFwiKSk7XG59KTtcbmFjdGlvbihcIm9wZW5cIiwgYXN5bmMgKCkgPT4ge1xuICBjb25zdCBsaXN0ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNzYXZlZC1saXN0XCIpITtcbiAgbGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgZm9yIChjb25zdCBlbnRyeSBvZiBhd2FpdCBhcHBsaWNhdGlvbi5zYXZlZERvY3VtZW50cygpKSB7XG4gICAgY29uc3QgYiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIik7XG4gICAgYi50ZXh0Q29udGVudCA9IGVudHJ5Lm5hbWU7XG4gICAgYi5kYXRhc2V0LmRvY3VtZW50S2V5ID0gZW50cnkua2V5O1xuICAgIGIub25jbGljayA9ICgpID0+IHtcbiAgICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFyZXBsYWNpbmcoKSkgcmV0dXJuO1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhcHBsaWNhdGlvbi5yZW9wZW4oZW50cnkua2V5KTtcbiAgICAgICAgaWYgKHJlc3VsdC5zdGF0dXMgPT09IFwiZWRpdGFibGVcIikge1xuICAgICAgICAgIGJ1aWxkV29ya3NwYWNlKCk7XG4gICAgICAgICAgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjb3Blbi1kaWFsb2dcIikgYXMgSFRNTERpYWxvZ0VsZW1lbnQpLmNsb3NlKCk7XG4gICAgICAgIH0gZWxzZSByZWNvdmVyeShyZXN1bHQucmF3LCByZXN1bHQucmVhc29uKTtcbiAgICAgIH0pKCkuY2F0Y2gocmVwb3J0KTtcbiAgICB9O1xuICAgIGxpc3QuYXBwZW5kKGIpO1xuICB9XG4gIGlmICghbGlzdC5jaGlsZE5vZGVzLmxlbmd0aCkgbGlzdC50ZXh0Q29udGVudCA9IHRleHQoXCJub0RvY3VtZW50c1wiKTtcbiAgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjb3Blbi1kaWFsb2dcIikgYXMgSFRNTERpYWxvZ0VsZW1lbnQpLnNob3dNb2RhbCgpO1xufSk7XG5hY3Rpb24oXCJleHBvcnRcIiwgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBhcHBsaWNhdGlvbi5kb3dubG9hZCgpO1xuICBzdWNjZXNzKHRleHQoXCJleHBvcnRlZFwiKSk7XG59KTtcbmNvbnN0IHBuZ0RpYWxvZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaWFsb2dcIik7XG5jb25zdCBwbmdUaXRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJoMlwiKSxcbiAgcG5nSW1hZ2UgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW1nXCIpLFxuICBwbmdEb3dubG9hZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiksXG4gIHBuZ0Nsb3NlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcbnBuZ1RpdGxlLnRleHRDb250ZW50ID0gdGV4dChcInBuZ1RpdGxlXCIpO1xucG5nRG93bmxvYWQudGV4dENvbnRlbnQgPSB0ZXh0KFwicG5nRG93bmxvYWRcIik7XG5wbmdDbG9zZS50ZXh0Q29udGVudCA9IHRleHQoXCJjYW5jZWxcIik7XG5wbmdEaWFsb2cuc3R5bGUud2lkdGggPSBcIm1pbigxMTAwcHgsIDkwdncpXCI7XG5wbmdJbWFnZS5hbHQgPSB0ZXh0KFwicG5nVGl0bGVcIik7XG5wbmdJbWFnZS5zdHlsZS5tYXhXaWR0aCA9IFwiMTAwJVwiO1xucG5nSW1hZ2Uuc3R5bGUubWF4SGVpZ2h0ID0gXCI2NXZoXCI7XG5wbmdJbWFnZS5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xucG5nSW1hZ2Uuc3R5bGUubWFyZ2luID0gXCIwIGF1dG8gMTZweFwiO1xucG5nRGlhbG9nLmFwcGVuZChwbmdUaXRsZSwgcG5nSW1hZ2UsIHBuZ0Rvd25sb2FkLCBwbmdDbG9zZSk7XG5hcHAuYXBwZW5kKHBuZ0RpYWxvZyk7XG5sZXQgcG5nVGlja2V0ID0gMCxcbiAgcG5nVVJMID0gXCJcIixcbiAgcG5nQnl0ZXM6IFVpbnQ4QXJyYXkgfCBudWxsID0gbnVsbCxcbiAgcG5nTmFtZSA9IFwiXCI7XG5jb25zdCBjYW5jZWxQTkcgPSAoKSA9PiB7XG4gIHBuZ1RpY2tldCsrO1xuICBwbmdCeXRlcyA9IG51bGw7XG4gIGlmIChwbmdVUkwpIFVSTC5yZXZva2VPYmplY3RVUkwocG5nVVJMKTtcbiAgcG5nVVJMID0gXCJcIjtcbiAgcG5nSW1hZ2UucmVtb3ZlQXR0cmlidXRlKFwic3JjXCIpO1xuICBwbmdEaWFsb2cuY2xvc2UoKTtcbn07XG5wbmdDbG9zZS5vbmNsaWNrID0gY2FuY2VsUE5HO1xucG5nRGlhbG9nLmFkZEV2ZW50TGlzdGVuZXIoXCJjYW5jZWxcIiwgKGV2ZW50KSA9PiB7XG4gIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gIGNhbmNlbFBORygpO1xufSk7XG5wbmdEb3dubG9hZC5vbmNsaWNrID0gKCkgPT4ge1xuICBpZiAocG5nQnl0ZXMpXG4gICAgdm9pZCBkb3dubG9hZEJ5dGVzKHBuZ05hbWUsIHBuZ0J5dGVzLnNsaWNlKCkuYnVmZmVyKS5jYXRjaChyZXBvcnQpO1xufTtcbmFjdGlvbihcInBuZ1wiLCBhc3luYyAoKSA9PiB7XG4gIGNhbmNlbFBORygpO1xuICBjb25zdCB0aWNrZXQgPSBwbmdUaWNrZXQsXG4gICAgc25hcHNob3QgPSBhcHBsaWNhdGlvbi5zbmFwc2hvdDtcbiAgY29uc3QgcGFuZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY2FudmFzLXBhbmVcIik7XG4gIGNvbnN0IGxheW91dCA9IG5ldyBNYXA8c3RyaW5nLCB7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH0+KCk7XG4gIHBhbmU/LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KFwiLm5vZGVbZGF0YS1ub2RlXVwiKS5mb3JFYWNoKChub2RlKSA9PlxuICAgIGxheW91dC5zZXQobm9kZS5kYXRhc2V0Lm5vZGUhLCB7XG4gICAgICB3aWR0aDogbm9kZS5vZmZzZXRXaWR0aCxcbiAgICAgIGhlaWdodDogbm9kZS5vZmZzZXRIZWlnaHQsXG4gICAgfSksXG4gICk7XG4gIGNvbnN0IHN0YWdlID0gc25hcHNob3QuZG9jdW1lbnQuZ3JhcGguc3RhZ2VzLmZpbmQoKHMpID0+XG4gICAgcy5uZXR3b3JrLm5vZGVzLnNvbWUoKG4pID0+IGxheW91dC5oYXMobi5pZCkpLFxuICApO1xuICBpZiAoIXN0YWdlKSB0aHJvdyBFcnJvcihcIlBOR19MQVlPVVRfTUlTU0lOR1wiKTtcbiAgcG5nRG93bmxvYWQuZGlzYWJsZWQgPSB0cnVlO1xuICBwbmdEaWFsb2cuc2hvd01vZGFsKCk7XG4gIHRyeSB7XG4gICAgY29uc3QgYnl0ZXMgPSBhd2FpdCByZW5kZXJEb2N1bWVudFBORyhzbmFwc2hvdC5kb2N1bWVudCwgc3RhZ2UuaWQsIGxheW91dCk7XG4gICAgaWYgKHRpY2tldCAhPT0gcG5nVGlja2V0KSByZXR1cm47XG4gICAgcG5nQnl0ZXMgPSBieXRlcztcbiAgICBwbmdOYW1lID0gYCR7c25hcHNob3QuZG9jdW1lbnQuZ3JhcGgubmFtZX0tJHtzbmFwc2hvdC5kb2N1bWVudC5ncmFwaC5raW5kLmtpbmRJZH0tJHtzdGFnZS5rZXl9LnBuZ2A7XG4gICAgcG5nVVJMID0gVVJMLmNyZWF0ZU9iamVjdFVSTChcbiAgICAgIG5ldyBCbG9iKFtieXRlcy5zbGljZSgpLmJ1ZmZlcl0sIHsgdHlwZTogXCJpbWFnZS9wbmdcIiB9KSxcbiAgICApO1xuICAgIHBuZ0ltYWdlLnNyYyA9IHBuZ1VSTDtcbiAgICBwbmdEb3dubG9hZC5kaXNhYmxlZCA9IGZhbHNlO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGlmICh0aWNrZXQgPT09IHBuZ1RpY2tldCkge1xuICAgICAgY2FuY2VsUE5HKCk7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cbn0pO1xuY29uc3QgaW5wdXQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW5wdXRcIik7XG5pbnB1dC50eXBlID0gXCJmaWxlXCI7XG5pbnB1dC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIsIFwiT3BlbiBkb2N1bWVudCBmaWxlXCIpO1xuaW5wdXQuYWNjZXB0ID0gXCIuanNvbiwuZ3JhcGUuanNvbiwucG5nLGFwcGxpY2F0aW9uL2pzb24saW1hZ2UvcG5nXCI7XG5pbnB1dC5oaWRkZW4gPSB0cnVlO1xuYXBwLmFwcGVuZChpbnB1dCk7XG5hY3Rpb24oXCJmaWxlXCIsICgpID0+IHtcbiAgaW5wdXQuY2xpY2soKTtcbn0pO1xuaW5wdXQuYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCAoKSA9PiB7XG4gIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBmaWxlID0gaW5wdXQuZmlsZXM/LlswXTtcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcbiAgICBjbG9zZVJldmlldygpO1xuICAgIGNvbnN0IHRpY2tldCA9IHJldmlld1RpY2tldDtcbiAgICBjb25zdCBiYXNlID0gYXBwbGljYXRpb24uc25hcHNob3Q7XG4gICAgcmVjb3ZlcnkoZmlsZSwgXCJSRUFESU5HX0lOUFVUXCIpO1xuICAgIGxldCBieXRlczogQXJyYXlCdWZmZXI7XG4gICAgdHJ5IHtcbiAgICAgIGJ5dGVzID0gYXdhaXQgZmlsZS5hcnJheUJ1ZmZlcigpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgaWYgKHRpY2tldCA9PT0gcmV2aWV3VGlja2V0KSByZWNvdmVyeShmaWxlLCBcIkZJTEVfUkVBRF9GQUlMRURcIik7XG4gICAgICBpbnB1dC52YWx1ZSA9IFwiXCI7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0aWNrZXQgIT09IHJldmlld1RpY2tldCkgcmV0dXJuO1xuICAgIGlmIChcbiAgICAgIGJhc2UubG9hZElkICE9PSBhcHBsaWNhdGlvbi5zbmFwc2hvdC5sb2FkSWQgfHxcbiAgICAgIGJhc2UucmV2aXNpb24gIT09IGFwcGxpY2F0aW9uLnNuYXBzaG90LnJldmlzaW9uXG4gICAgKSB7XG4gICAgICByZWNvdmVyeShieXRlcywgXCJPUEVOX1NVUEVSU0VERURcIik7XG4gICAgICBpbnB1dC52YWx1ZSA9IFwiXCI7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCByYXc6IHN0cmluZztcbiAgICB0cnkge1xuICAgICAgcmF3ID0gZGVjb2RlSW5wdXQobmV3IFVpbnQ4QXJyYXkoYnl0ZXMpLCBmaWxlLm5hbWUpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZWNvdmVyeShieXRlcywgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpKTtcbiAgICAgIGlucHV0LnZhbHVlID0gXCJcIjtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY3VycmVudFJldmlldyA9IGFwcGxpY2F0aW9uLmluc3BlY3RUZXh0KHJhdyk7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZWNvdmVyeSBoMlwiKSEudGV4dENvbnRlbnQgPSB0ZXh0KFwicmV2aWV3VGl0bGVcIik7XG4gICAgcmVjb3ZlcnkoYnl0ZXMsIGN1cnJlbnRSZXZpZXcuc3RhdHVzICsgXCI6IFwiICsgY3VycmVudFJldmlldy5yZWFzb24pO1xuICAgIHJldmlld0RldGFpbHMudGV4dENvbnRlbnQgPSBKU09OLnN0cmluZ2lmeShcbiAgICAgIHtcbiAgICAgICAgZGlhZ25vc3RpY3M6IGN1cnJlbnRSZXZpZXcuZGlhZ25vc3RpY3MsXG4gICAgICAgIHJlcGFpcnM6IGN1cnJlbnRSZXZpZXcucmVwYWlycyxcbiAgICAgICAgcHJvdmVuYW5jZTogY3VycmVudFJldmlldy5wcm92ZW5hbmNlLFxuICAgICAgICB1bmtub3duUGF0aHM6XG4gICAgICAgICAgY3VycmVudFJldmlldy5yZWFkLnN0YXR1cyA9PT0gXCJyZWNvdmVyeS1yZWFkb25seVwiXG4gICAgICAgICAgICA/IGN1cnJlbnRSZXZpZXcucmVhZC51bmtub3duUGF0aHNcbiAgICAgICAgICAgIDogW10sXG4gICAgICAgIGNhbmRpZGF0ZTogY3VycmVudFJldmlldy5jYW5kaWRhdGUsXG4gICAgICB9LFxuICAgICAgbnVsbCxcbiAgICAgIDIsXG4gICAgKTtcbiAgICByYXdQcmV2aWV3LnRleHRDb250ZW50ID0gcmF3LnNsaWNlKDAsIDEyMDAwKTtcbiAgICBsb2FkQnV0dG9uLmhpZGRlbiA9XG4gICAgICBjdXJyZW50UmV2aWV3LnJlYWQuc3RhdHVzICE9PSBcImVkaXRhYmxlXCIgfHxcbiAgICAgICFjdXJyZW50UmV2aWV3LmRvY3VtZW50IHx8XG4gICAgICBjdXJyZW50UmV2aWV3LnJlYXNvbiA9PT0gXCJORVRXT1JLX1NJWkVcIjtcbiAgICByZWZyZXNoUmVwbGFjZW1lbnQoKTtcbiAgICBpbnB1dC52YWx1ZSA9IFwiXCI7XG4gIH0pKCkuY2F0Y2gocmVwb3J0KTtcbn0pO1xuYWN0aW9uKFwiZ2VuZXJhdGVcIiwgKCkgPT4ge1xuICBjb25zdCByZXN1bHQgPSBhcHBsaWNhdGlvbi5nZW5lcmF0ZSgpO1xuICBpZiAocmVzdWx0LnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIpXG4gICAgdGhyb3cgRXJyb3IoXG4gICAgICByZXN1bHQuZGlhZ25vc3RpY3MubWFwKChkKSA9PiBkLmNvZGUgKyBcIjogXCIgKyBkLm1lc3NhZ2UpLmpvaW4oXCIgwrcgXCIpLFxuICAgICk7XG59KTtcbmFjdGlvbihcInNlY29uZFwiLCAoKSA9PiB7XG4gIGFkZENhbnZhcygpO1xufSk7XG5jb25zdCBsb2NrQnV0dG9uID0gYWN0aW9uKFwibG9ja1wiLCAoKSA9PlxuICBhcHBsaWNhdGlvbi5zZXRSZWFkb25seSghYXBwbGljYXRpb24ucmVhZG9ubHkpLFxuKTtcbmxvY2tCdXR0b24uc2V0QXR0cmlidXRlKFwiYXJpYS1jaGVja2VkXCIsIFwiZmFsc2VcIik7XG5sZXQgb3JpZ2luYWw6IHN0cmluZyB8IEFycmF5QnVmZmVyIHwgQmxvYiA9IFwiXCI7XG5sZXQgY3VycmVudFJldmlldzogRG9jdW1lbnRJbnNwZWN0aW9uIHwgbnVsbCA9IG51bGwsXG4gIHJldmlld1RpY2tldCA9IDA7XG5jb25zdCByZXZpZXdEaWFsb2cgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxEaWFsb2dFbGVtZW50PihcIiNyZWNvdmVyeVwiKSE7XG5yZXZpZXdEaWFsb2cuc3R5bGUud2lkdGggPSBcIm1pbig5MDBweCwgOTB2dylcIjtcbmNvbnN0IHJldmlld0RldGFpbHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwicHJlXCIpLFxuICByYXdQcmV2aWV3ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInByZVwiKSxcbiAgZXhwbGFuYXRpb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwicFwiKSxcbiAgcmVwbGFjZW1lbnRNZXNzYWdlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInBcIiksXG4gIGFjY2VwdEJ1dHRvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiksXG4gIGxvYWRCdXR0b24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpO1xucmV2aWV3RGV0YWlscy5zZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIsIHRleHQoXCJyZXZpZXdEZXRhaWxzXCIpKTtcbnJhd1ByZXZpZXcuc2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiLCB0ZXh0KFwib3JpZ2luYWxQcmV2aWV3XCIpKTtcbnJldmlld0RldGFpbHMuc3R5bGUubWF4SGVpZ2h0ID0gXCIzMHZoXCI7XG5yYXdQcmV2aWV3LnN0eWxlLm1heEhlaWdodCA9IFwiMTV2aFwiO1xucmV2aWV3RGV0YWlscy5zdHlsZS5vdmVyZmxvdyA9IHJhd1ByZXZpZXcuc3R5bGUub3ZlcmZsb3cgPSBcImF1dG9cIjtcbmV4cGxhbmF0aW9uLnRleHRDb250ZW50ID0gdGV4dChcImxvYWRFeHBsYW5hdGlvblwiKTtcbnJlcGxhY2VtZW50TWVzc2FnZS5pZCA9IFwicmVwbGFjZW1lbnQtbWVzc2FnZVwiO1xucmVwbGFjZW1lbnRNZXNzYWdlLnNldEF0dHJpYnV0ZShcInJvbGVcIiwgXCJzdGF0dXNcIik7XG5hY2NlcHRCdXR0b24udGV4dENvbnRlbnQgPSB0ZXh0KFwiYWNjZXB0SW1wb3J0XCIpO1xubG9hZEJ1dHRvbi50ZXh0Q29udGVudCA9IHRleHQoXCJvcGVuUHJlc2VydmVkXCIpO1xuYWNjZXB0QnV0dG9uLmhpZGRlbiA9IGxvYWRCdXR0b24uaGlkZGVuID0gdHJ1ZTtcbnJldmlld0RpYWxvZy5hcHBlbmQoXG4gIGV4cGxhbmF0aW9uLFxuICByZXZpZXdEZXRhaWxzLFxuICByYXdQcmV2aWV3LFxuICByZXBsYWNlbWVudE1lc3NhZ2UsXG4gIGFjY2VwdEJ1dHRvbixcbiAgbG9hZEJ1dHRvbixcbik7XG5mdW5jdGlvbiByZWZyZXNoUmVwbGFjZW1lbnQoKSB7XG4gIGlmICghY3VycmVudFJldmlldykge1xuICAgIHJlcGxhY2VtZW50TWVzc2FnZS50ZXh0Q29udGVudCA9IFwiXCI7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGVsaWdpYmlsaXR5ID0gYXBwbGljYXRpb24ucmVwbGFjZW1lbnRFbGlnaWJpbGl0eShjdXJyZW50UmV2aWV3KTtcbiAgYWNjZXB0QnV0dG9uLmhpZGRlbiA9ICFjdXJyZW50UmV2aWV3LmNhbmRpZGF0ZTtcbiAgYWNjZXB0QnV0dG9uLmRpc2FibGVkID0gIWVsaWdpYmlsaXR5LmF2YWlsYWJsZTtcbiAgY29uc3QgY29kZSA9IGVsaWdpYmlsaXR5LmF2YWlsYWJsZSA/IG51bGwgOiBlbGlnaWJpbGl0eS5jb2RlO1xuICByZXBsYWNlbWVudE1lc3NhZ2UudGV4dENvbnRlbnQgPSAhY3VycmVudFJldmlldy5jYW5kaWRhdGVcbiAgICA/IFwiXCJcbiAgICA6IGNvZGUgPT09IG51bGxcbiAgICAgID8gdGV4dChcInJlcGxhY2VSZWFkeVwiKVxuICAgICAgOiBjb2RlID09PSBcIklNUE9SVF9ERUZJTklUSU9OU1wiXG4gICAgICAgID8gdGV4dChcInJlcGxhY2VEZWZpbml0aW9uc1wiKVxuICAgICAgICA6IGNvZGUgPT09IFwiSU1QT1JUX1NUQUxFXCIgfHwgY29kZSA9PT0gXCJSRVZJRVdfQ0xPU0VEXCJcbiAgICAgICAgICA/IHRleHQoXCJyZXBsYWNlU3RhbGVcIiwgeyBjb2RlIH0pXG4gICAgICAgICAgOiBjb2RlID09PSBcIklNUE9SVF9SRUFET05MWVwiXG4gICAgICAgICAgICA/IHRleHQoXCJyZXBsYWNlUmVhZG9ubHlcIilcbiAgICAgICAgICAgIDogY29kZSA9PT0gXCJISVNUT1JZX0JVU1lcIlxuICAgICAgICAgICAgICA/IHRleHQoXCJyZXBsYWNlQnVzeVwiKVxuICAgICAgICAgICAgICA6IHRleHQoXCJyZXBsYWNlVW5hdmFpbGFibGVcIiwgeyBjb2RlIH0pO1xuICBsb2FkQnV0dG9uLmRpc2FibGVkID1cbiAgICBhcHBsaWNhdGlvbi5yZWFkb25seSB8fFxuICAgIGFwcGxpY2F0aW9uLmJ1c3kgfHxcbiAgICBjb2RlID09PSBcIklNUE9SVF9TVEFMRVwiIHx8XG4gICAgY29kZSA9PT0gXCJSRVZJRVdfQ0xPU0VEXCI7XG59XG5mdW5jdGlvbiBjbG9zZVJldmlldygpIHtcbiAgcmV2aWV3VGlja2V0Kys7XG4gIGlmIChjdXJyZW50UmV2aWV3KSBhcHBsaWNhdGlvbi5jYW5jZWxSZXZpZXcoY3VycmVudFJldmlldyk7XG4gIGN1cnJlbnRSZXZpZXcgPSBudWxsO1xuICByZXZpZXdEZXRhaWxzLnRleHRDb250ZW50ID0gcmF3UHJldmlldy50ZXh0Q29udGVudCA9IFwiXCI7XG4gIHJlcGxhY2VtZW50TWVzc2FnZS50ZXh0Q29udGVudCA9IFwiXCI7XG4gIGFjY2VwdEJ1dHRvbi5oaWRkZW4gPSBsb2FkQnV0dG9uLmhpZGRlbiA9IHRydWU7XG4gIHJldmlld0RpYWxvZy5jbG9zZSgpO1xuICBpbnB1dC52YWx1ZSA9IFwiXCI7XG59XG5yZXZpZXdEaWFsb2cuYWRkRXZlbnRMaXN0ZW5lcihcImNhbmNlbFwiLCAoZXZlbnQpID0+IHtcbiAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgY2xvc2VSZXZpZXcoKTtcbn0pO1xuYWNjZXB0QnV0dG9uLm9uY2xpY2sgPSAoKSA9PiB7XG4gIHRyeSB7XG4gICAgaWYgKHdvcmtzcGFjZT8ucmVjb3JkcygpLnNvbWUoKHIpID0+IHIuaW5zdGFuY2UgJiYgIXIuaW5zdGFuY2UuY2FuQ2xvc2UoKSkpXG4gICAgICB0aHJvdyBFcnJvcih0ZXh0KFwiZHJhZnRCdXN5XCIpKTtcbiAgICBpZiAoY3VycmVudFJldmlldykgYXBwbGljYXRpb24uYWNjZXB0UmV2aWV3KGN1cnJlbnRSZXZpZXcpO1xuICAgIGNsb3NlUmV2aWV3KCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZWNvdmVyeS1tZXNzYWdlXCIpIS50ZXh0Q29udGVudCA9XG4gICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcik7XG4gICAgcmVmcmVzaFJlcGxhY2VtZW50KCk7XG4gIH1cbn07XG5sb2FkQnV0dG9uLm9uY2xpY2sgPSAoKSA9PiB7XG4gIHRyeSB7XG4gICAgaWYgKCFjdXJyZW50UmV2aWV3IHx8ICFyZXBsYWNpbmcoKSkgcmV0dXJuO1xuICAgIGFwcGxpY2F0aW9uLm9wZW5SZXZpZXdlZChjdXJyZW50UmV2aWV3KTtcbiAgICBidWlsZFdvcmtzcGFjZSgpO1xuICAgIGNsb3NlUmV2aWV3KCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZWNvdmVyeS1tZXNzYWdlXCIpIS50ZXh0Q29udGVudCA9XG4gICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcik7XG4gIH1cbn07XG5mdW5jdGlvbiByZWNvdmVyeShyYXc6IHN0cmluZyB8IEFycmF5QnVmZmVyIHwgQmxvYiwgcmVhc29uOiBzdHJpbmcpIHtcbiAgb3JpZ2luYWwgPSByYXc7XG4gIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjcmVjb3ZlcnktbWVzc2FnZVwiKSEudGV4dENvbnRlbnQgPSB0ZXh0KFwicmVjb3ZlcnlcIiwge1xuICAgIHJlYXNvbixcbiAgfSk7XG4gIGlmICghcmV2aWV3RGlhbG9nLm9wZW4pIHJldmlld0RpYWxvZy5zaG93TW9kYWwoKTtcbn1cbmRvY3VtZW50XG4gIC5xdWVyeVNlbGVjdG9yKFwiI2V4cG9ydC1vcmlnaW5hbFwiKSFcbiAgLmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgXCJjbGlja1wiLFxuICAgICgpID0+IHZvaWQgZG93bmxvYWRCeXRlcyhcInJlY292ZXJ5LW9yaWdpbmFsLmpzb25cIiwgb3JpZ2luYWwpLFxuICApO1xuZG9jdW1lbnRcbiAgLnF1ZXJ5U2VsZWN0b3IoXCIjY2xvc2UtcmVjb3ZlcnlcIikhXG4gIC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgY2xvc2VSZXZpZXcpO1xuZG9jdW1lbnRcbiAgLnF1ZXJ5U2VsZWN0b3IoXCIjY2FuY2VsLW9wZW5cIikhXG4gIC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT5cbiAgICAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNvcGVuLWRpYWxvZ1wiKSBhcyBIVE1MRGlhbG9nRWxlbWVudCkuY2xvc2UoKSxcbiAgKTtcbmFwcGxpY2F0aW9uLnN1YnNjcmliZSgoKSA9PiB7XG4gIGhvdmVyLmludmFsaWRhdGUoKTtcbiAgcmVmcmVzaFJlcGxhY2VtZW50KCk7XG4gIHNhdmVTdGF0ZS50ZXh0Q29udGVudCA9IGFwcGxpY2F0aW9uLnNhdmluZ1xuICAgID8gdGV4dChcInNhdmluZ1wiKVxuICAgIDogYXBwbGljYXRpb24uZGlydHlcbiAgICAgID8gdGV4dChcImRpcnR5XCIpXG4gICAgICA6IHRleHQoXCJzYXZlZFwiKTtcbiAgc2F2ZUJ1dHRvbi5kaXNhYmxlZCA9IGFwcGxpY2F0aW9uLnNhdmluZztcbiAgbG9ja0J1dHRvbi5zZXRBdHRyaWJ1dGUoXCJhcmlhLWNoZWNrZWRcIiwgU3RyaW5nKGFwcGxpY2F0aW9uLnJlYWRvbmx5KSk7XG59KTtcbmFwcGxpY2F0aW9uLm5ld0RvY3VtZW50KCk7XG5idWlsZFdvcmtzcGFjZSgpO1xubW91bnRQZXJzb25hbChcbiAgbmF2LFxuICBhcHBsaWNhdGlvbixcbiAgKCkgPT4ge1xuICAgIGNvbnN0IGlkID0gd29ya3NwYWNlPy5yZWNvcmRzKCkuZmluZCgocikgPT4gci5zYXZlZC5pZCA9PT0gXCJpbnNwZWN0b3JcIilcbiAgICAgID8udXBkYXRlLnRhcmdldD8uc2NvcGUuY29udGV4dElkO1xuICAgIGlmICghaWQpIHRocm93IEVycm9yKFwiU2VsZWN0IGEgQ2FudmFzIGZpcnN0LlwiKTtcbiAgICByZXR1cm4gYXBwbGljYXRpb24uY29udGV4dChpZCk7XG4gIH0sXG4gIG5ldyBQZXJzb25hbExpYnJhcnkoXG4gICAgbmV3IEJyb3dzZXJMaWJyYXJ5U3RvcmUoKSxcbiAgICBkZWZpbml0aW9ucy5waW4oZGVmaW5pdGlvbnMucGlucygpKSxcbiAgICBmdW5jdGlvblByb2ZpbGUsXG4gICAgcHJvYmVEZWZpbml0aW9ucyxcbiAgKSxcbiAgKGVycm9yLCBvcGVyYXRpb24pID0+IHtcbiAgICBjb25zdCBrZXkgPSBcInBlcnNvbmFsOlwiICsgb3BlcmF0aW9uO1xuICAgIGlmIChlcnJvciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAoZXJyb3JzLmRlbGV0ZShrZXkpKSByZW5kZXJFcnJvcnMoKTtcbiAgICB9IGVsc2UgcmVwb3J0KGVycm9yLCBrZXkpO1xuICB9LFxuKTtcblxuLy8gRXhpc3RpbmcgZG9jdW1lbnQgY29tbWFuZHMga2VlcCB0aGVpciBvd24gaGFuZGxlcnMgYW5kIGd1YXJkczsgb25seSB0aGVpclxuLy8gcHJlc2VudGF0aW9uIG1vdmVzIGludG8gdGhlIHNoYXJlZCBvd25lZCBkaXNjbG9zdXJlLlxuY29uc3QgbWVudVRyaWdnZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpLFxuICBtZW51Q29udGVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksXG4gIGhpbnRzVHJpZ2dlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiksXG4gIGhpbnRzQ29udGVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG5tZW51VHJpZ2dlci50eXBlID0gXCJidXR0b25cIjtcbm1lbnVUcmlnZ2VyLnRleHRDb250ZW50ID0gXCJQcm9qZWN0IGFjdGlvbnNcIjtcbm1lbnVUcmlnZ2VyLmNsYXNzTmFtZSA9IFwicHJvamVjdC1hY3Rpb25zXCI7XG5tZW51Q29udGVudC5jbGFzc05hbWUgPSBcImZ1bmN0aW9uLWFjdGlvbnNcIjtcbm1lbnVDb250ZW50LnRhYkluZGV4ID0gLTE7XG5jb25zdCBkb2N1bWVudEdyb3VwID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSxcbiAgd29ya3NwYWNlR3JvdXAgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuZm9yIChjb25zdCBbZ3JvdXAsIGxhYmVsXSBvZiBbXG4gIFtkb2N1bWVudEdyb3VwLCBcIkRvY3VtZW50cyBhbmQgbGlicmFyeVwiXSxcbiAgW3dvcmtzcGFjZUdyb3VwLCBcIldvcmtzcGFjZVwiXSxcbl0gYXMgY29uc3QpIHtcbiAgZ3JvdXAuc2V0QXR0cmlidXRlKFwicm9sZVwiLCBcImdyb3VwXCIpO1xuICBncm91cC5hcmlhTGFiZWwgPSBsYWJlbDtcbiAgbWVudUNvbnRlbnQuYXBwZW5kKGdyb3VwKTtcbn1cbmZvciAoY29uc3QgY2hpbGQgb2YgQXJyYXkuZnJvbShuYXYuY2hpbGRyZW4pKSB7XG4gIGNvbnN0IGtleSA9IChjaGlsZCBhcyBIVE1MRWxlbWVudCkuZGF0YXNldC5hY3Rpb247XG4gIGlmICghKGNoaWxkIGluc3RhbmNlb2YgSFRNTEJ1dHRvbkVsZW1lbnQpKSBhcHAuYXBwZW5kKGNoaWxkKTtcbiAgZWxzZSBpZiAoa2V5ICE9PSBcInNhdmVcIiAmJiBrZXkgIT09IFwiZ2VuZXJhdGVcIikge1xuICAgIGNoaWxkLnNldEF0dHJpYnV0ZShcbiAgICAgIFwicm9sZVwiLFxuICAgICAga2V5ID09PSBcImxvY2tcIiA/IFwibWVudWl0ZW1jaGVja2JveFwiIDogXCJtZW51aXRlbVwiLFxuICAgICk7XG4gICAgKGtleSA9PT0gXCJzZWNvbmRcIiB8fCBrZXkgPT09IFwibG9ja1wiXG4gICAgICA/IHdvcmtzcGFjZUdyb3VwXG4gICAgICA6IGRvY3VtZW50R3JvdXBcbiAgICApLmFwcGVuZChjaGlsZCk7XG4gIH1cbn1cbmZvb3Rlci5wcmVwZW5kKG1lbnVUcmlnZ2VyKTtcbmNvbnN0IHByb2plY3RNZW51ID0gZmxvYXRpbmdTdXJmYWNlKHtcbiAgaG9zdDogYXBwLFxuICB0cmlnZ2VyOiBtZW51VHJpZ2dlcixcbiAgY29udGVudDogbWVudUNvbnRlbnQsXG4gIHRpdGxlOiBcIlByb2plY3QgYWN0aW9uc1wiLFxuICBjbG9zZUxhYmVsOiBcIkNsb3NlIHByb2plY3QgYWN0aW9uc1wiLFxuICBraW5kOiBcIm1lbnVcIixcbiAgd2lkdGg6IDMxMCxcbiAgbWF4SGVpZ2h0OiA1MjAsXG59KTtcbm1lbnVUcmlnZ2VyLm9uY2xpY2sgPSAoKSA9PiBwcm9qZWN0TWVudS50b2dnbGUoKTtcbm1lbnVDb250ZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZXZlbnQpID0+IHtcbiAgY29uc3QgYWN0aW9uID0gKGV2ZW50LnRhcmdldCBhcyBFbGVtZW50KS5jbG9zZXN0PEhUTUxCdXR0b25FbGVtZW50PihcImJ1dHRvblwiKVxuICAgID8uZGF0YXNldC5hY3Rpb247XG4gIC8vIERpYWxvZy1vcGVuaW5nIGNhbGxlcnMgcmV0YWluIHRoZWlyIHZpc2libGUgb3BlbmVyIHVudGlsIHRoZWlyIG93biBDbG9zZS5cbiAgaWYgKGFjdGlvbiAmJiBbXCJuZXdcIiwgXCJleHBvcnRcIiwgXCJmaWxlXCIsIFwic2Vjb25kXCIsIFwibG9ja1wiXS5pbmNsdWRlcyhhY3Rpb24pKVxuICAgIHByb2plY3RNZW51LmNsb3NlKGZhbHNlKTtcbn0pO1xuaGludHNUcmlnZ2VyLnR5cGUgPSBcImJ1dHRvblwiO1xuaGludHNUcmlnZ2VyLnRleHRDb250ZW50ID0gXCJIaW50c1wiO1xuaGludHNDb250ZW50LnRhYkluZGV4ID0gMDtcbmZvciAoY29uc3QgaGludCBvZiBBcnJheS5mcm9tKGZvb3Rlci5xdWVyeVNlbGVjdG9yQWxsKFwiOnNjb3BlID4gc3BhblwiKSkpXG4gIGhpbnRzQ29udGVudC5hcHBlbmQoaGludCk7XG5jb25zdCBpbnNwZWN0SGludCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuaW5zcGVjdEhpbnQudGV4dENvbnRlbnQgPVxuICBcIkYyIMK3IFJlYWQgdGhlIGZvY3VzZWQgb2JqZWN0IGluZm9ybWF0aW9uIChyZWFkLW9ubHkpLiBDbG9zZSBvciBFc2NhcGUgcmV0dXJucyBmb2N1cy5cIjtcbmhpbnRzQ29udGVudC5hcHBlbmQoaW5zcGVjdEhpbnQpO1xuZm9vdGVyLmFwcGVuZChoaW50c1RyaWdnZXIpO1xuY29uc3QgaGludHNWaWV3ID0gZmxvYXRpbmdTdXJmYWNlKHtcbiAgaG9zdDogYXBwLFxuICB0cmlnZ2VyOiBoaW50c1RyaWdnZXIsXG4gIGNvbnRlbnQ6IGhpbnRzQ29udGVudCxcbiAgdGl0bGU6IFwiV29ya3NwYWNlIGhpbnRzXCIsXG4gIGNsb3NlTGFiZWw6IFwiQ2xvc2UgaGludHNcIixcbiAga2luZDogXCJhbmNob3JlZFwiLFxuICB3aWR0aDogMzcwLFxuICBtYXhIZWlnaHQ6IDMwMCxcbiAgYWxpZ246IFwiZW5kXCIsXG59KTtcbmhpbnRzVHJpZ2dlci5vbmNsaWNrID0gKCkgPT4gaGludHNWaWV3LnRvZ2dsZSgpO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLFlBQVk7QUFDckIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxzQkFBc0I7QUFDL0I7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHdCQUF3QjtBQUNqQztBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsT0FDSztBQUNQLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsMkJBQTJCO0FBQ3BDLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMscUJBQXFCO0FBQzlCO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLFdBQVcsbUJBQW1CLHFCQUFxQjtBQUM1RCxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLFlBQVksZ0JBQWdCO0FBQ3JDO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLHlCQUF5QjtBQUVsQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHlCQUF5QjtBQUNsQztBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHNCQUFzQjtBQUMvQjtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLGVBQWUscUJBQXFCO0FBQzdDLFNBQVMsYUFBYSxtQkFBbUI7QUFDekMsU0FBUyxVQUFVLGdCQUFnQjtBQUNuQztBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxPQUNLO0FBRVAsTUFBTSxjQUFjLElBQUksWUFBWTtBQUNwQyxPQUFPLFFBQVEsQ0FBQyxNQUFNLFlBQVksY0FBYyxDQUFDLENBQUM7QUFDbEQsWUFBWSxTQUFTLFVBQVU7QUFDL0IsWUFBWSxTQUFTLFdBQVc7QUFDaEMsWUFBWSxTQUFTLGFBQWE7QUFDbEMsWUFBWSxTQUFTLFlBQVk7QUFDakMsWUFBWSxTQUFTLGNBQWM7QUFDbkMsWUFBWSxTQUFTLGdCQUFnQjtBQUNyQyxZQUFZLFNBQVMsa0JBQWtCO0FBQ3ZDLFlBQVksU0FBUyxVQUFVO0FBQy9CLFlBQVksYUFBYSxTQUFTO0FBQ2xDLFlBQVksU0FBUyxtQkFBbUI7QUFDeEMsWUFBWSxTQUFTLGlCQUFpQjtBQUN0QyxZQUFZLGFBQWEsZ0JBQWdCO0FBQ3pDLE1BQU0sU0FBUyxJQUFJLGFBQWE7QUFDaEMsT0FBTyxlQUFlLG1CQUFtQixhQUFhO0FBQ3RELFdBQVcsZ0JBQWdCO0FBQUEsRUFDekI7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRjtBQUNFLFNBQU8sZUFBZSxhQUFhLGNBQWMsYUFBYSxRQUFRO0FBQ3hFLE1BQU0sT0FBTyxDQUNYLEtBQ0EsV0FDRyxPQUFPLFFBQVEsVUFBVSxLQUFLLE1BQU0sQ0FBQyxFQUFFO0FBQzVDLE1BQU0sV0FBVyxnQkFBZ0IsTUFBTTtBQUN2QyxNQUFNLFVBQVUsSUFBSSxlQUFlLFFBQVE7QUFDM0MsUUFBUSxTQUFTLFlBQVksQ0FBQyxNQUFNLEVBQUUsS0FBSyxTQUFTLE1BQU07QUFDMUQsUUFBUSxTQUFTLGNBQWMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxTQUFTLFFBQVE7QUFDOUQsUUFBUSxTQUFTLGNBQWMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxTQUFTLFFBQVE7QUFDOUQsUUFBUTtBQUFBLEVBQ047QUFBQSxFQUNBLENBQUMsTUFDQyxFQUFFLEtBQUssYUFBYSxXQUFXLHlCQUMvQixNQUFNLFFBQVEsRUFBRSxLQUFLO0FBQ3pCO0FBQ0EsTUFBTSxjQUFjLElBQUk7QUFBQSxFQUN0QjtBQUFBLEVBQ0EsZ0JBQWdCO0FBQUEsRUFDaEIsaUJBQWlCO0FBQUEsRUFDakI7QUFBQSxFQUNBLElBQUksZUFBZTtBQUFBLEVBQ25CO0FBQUEsRUFDQTtBQUNGO0FBQ0EsTUFBTSxNQUFNLFNBQVMsY0FBMkIsTUFBTTtBQUN0RCxJQUFJLFlBQ0Y7QUFDRixNQUFNLGFBQWE7QUFBQSxFQUNqQixDQUFDLGdCQUFnQixVQUFVO0FBQUEsRUFDM0IsQ0FBQyxTQUFTLFVBQVU7QUFBQSxFQUNwQixDQUFDLDJCQUEyQixhQUFhO0FBQUEsRUFDekMsQ0FBQywwQkFBMEIsWUFBWTtBQUFBLEVBQ3ZDLENBQUMsbUJBQW1CLFdBQVc7QUFBQSxFQUMvQixDQUFDLGdCQUFnQixRQUFRO0FBQUEsRUFDekIsQ0FBQyxnQkFBZ0IsZUFBZTtBQUFBLEVBQ2hDLENBQUMsb0JBQW9CLFVBQVU7QUFBQSxFQUMvQixDQUFDLG1CQUFtQixPQUFPO0FBQzdCO0FBQ0EsTUFBTSxjQUFjLE1BQU07QUFDeEIsYUFBVyxDQUFDLFVBQVUsR0FBRyxLQUFLO0FBQzVCLFFBQUksY0FBYyxRQUFRLEVBQUcsY0FBYyxLQUFLLEdBQUc7QUFDckQsTUFBSSxjQUFjLEtBQUssRUFBRyxhQUFhLGNBQWMsS0FBSyxpQkFBaUIsQ0FBQztBQUM5RTtBQUNBLFlBQVk7QUFDWixPQUFPLFVBQVUsV0FBVztBQUM1QixlQUFlLElBQUksY0FBMkIsUUFBUSxDQUFFO0FBQ3hELE1BQU0sYUFBYSxTQUFTLGNBQTJCLFVBQVUsR0FDL0QsVUFBVSxTQUFTLGNBQWMsUUFBUSxHQUN6QyxZQUFZLFNBQVMsY0FBYyxLQUFLLEdBQ3hDLE1BQU0sSUFBSSxjQUFjLEtBQUssR0FDN0IsWUFBWSxTQUFTLGNBQTJCLGFBQWE7QUFDL0QsUUFBUSxLQUFLO0FBQ2IsUUFBUSxPQUFPO0FBQ2YsUUFBUSxZQUFZO0FBQ3BCLFFBQVEsYUFBYSxpQkFBaUIsUUFBUTtBQUM5QyxVQUFVLFlBQVk7QUFDdEIsVUFBVSxhQUFhLFFBQVEsUUFBUTtBQUN2QyxXQUFXLFlBQVksU0FBUztBQUNoQyxVQUFVLE9BQU8sT0FBTztBQUN4QixJQUFJLGNBQWMsUUFBUSxFQUFHLE9BQU8sU0FBUztBQUM3QyxNQUFNLGFBQWEsU0FBUyxjQUFjLEtBQUs7QUFDL0MsV0FBVyxZQUFZO0FBQ3ZCLFdBQVcsV0FBVztBQUN0QixXQUFXLGFBQWEsUUFBUSxRQUFRO0FBQ3hDLFdBQVcsWUFBWTtBQUN2QixNQUFNLGFBQWEsZ0JBQWdCO0FBQUEsRUFDakMsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsU0FBUztBQUFBLEVBQ1QsT0FBTztBQUFBLEVBQ1AsWUFBWTtBQUFBLEVBQ1osTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsWUFBWSxNQUFNLENBQUMsQ0FBQyxRQUFRO0FBQUEsRUFDNUIsZUFBZSxNQUNiLElBQUksY0FBaUMsdUJBQXVCO0FBQ2hFLENBQUM7QUFDRCxNQUFNLGNBQWMsTUFBTSxXQUFXLE1BQU07QUFDM0MsUUFBUSxVQUFVLE1BQU07QUFDdEIsYUFBVyxjQUFjLFFBQVE7QUFDakMsYUFBVyxPQUFPO0FBQ3BCO0FBQ0EsTUFBTSxhQUFhLENBQUNBLFVBQWlCO0FBQ25DLFVBQVEsY0FBY0E7QUFDdEIsVUFBUSxXQUFXLENBQUNBO0FBQ3BCLGFBQVcsY0FBY0E7QUFDekIsTUFBSSxDQUFDQSxNQUFNLGFBQVk7QUFDekI7QUFDQSxXQUFXLEVBQUU7QUFDYixNQUFNLFNBQVMsb0JBQUksSUFBb0I7QUFDdkMsTUFBTSxVQUFVLENBQUNBLFVBQWlCO0FBQ2hDLE1BQUksQ0FBQyxPQUFPLEtBQU0sWUFBV0EsS0FBSTtBQUNuQztBQUNBLE1BQU0sZUFBZSxNQUFNO0FBQ3pCLGFBQVcsQ0FBQyxHQUFHLE9BQU8sT0FBTyxDQUFDLEVBQUUsS0FBSyxLQUFLLENBQUM7QUFDM0MsVUFBUSxVQUFVLE9BQU8sU0FBUyxDQUFDLENBQUMsT0FBTyxJQUFJO0FBQy9DLFlBQVUsYUFBYSxRQUFRLE9BQU8sT0FBTyxVQUFVLFFBQVE7QUFDakU7QUFDQSxNQUFNLFNBQVMsQ0FBQyxPQUFnQixNQUFNLGdCQUFnQjtBQUNwRCxTQUFPLElBQUksS0FBSyxpQkFBaUIsUUFBUSxNQUFNLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFDdEUsZUFBYTtBQUNmO0FBQ0EsTUFBTSxTQUFTLENBQ2IsS0FDQSxPQUNHO0FBQ0gsUUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0FBQzlDLFNBQU8sUUFBUSxTQUFTO0FBQ3hCLFFBQU0sU0FBaUM7QUFBQSxJQUNyQyxLQUFLO0FBQUEsSUFDTCxNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsSUFDUixLQUFLO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixRQUFRO0FBQUEsSUFDUixNQUFNO0FBQUEsRUFDUjtBQUNBLFFBQU0sZUFBZSxNQUNuQixPQUFPO0FBQUEsSUFDTCxLQUFLLE9BQU8sR0FBRyxLQUFLLFFBQVE7QUFBQSxJQUM1QixTQUFTLGVBQWUsS0FBSyxHQUFHLENBQUM7QUFBQSxFQUNuQztBQUNGLGVBQWE7QUFDYixTQUFPLFVBQVUsWUFBWTtBQUM3QixTQUFPLGlCQUFpQixTQUFTLE1BQU07QUFDckMsUUFBSTtBQUNGLGNBQVEsUUFBUSxHQUFHLENBQUMsRUFDakIsS0FBSyxNQUFNO0FBQ1YsWUFBSSxPQUFPLE9BQU8sR0FBRyxFQUFHLGNBQWE7QUFBQSxNQUN2QyxDQUFDLEVBQ0EsTUFBTSxDQUFDLFVBQVUsT0FBTyxPQUFPLEdBQUcsQ0FBQztBQUFBLElBQ3hDLFNBQVMsT0FBTztBQUNkLGFBQU8sT0FBTyxHQUFHO0FBQUEsSUFDbkI7QUFBQSxFQUNGLENBQUM7QUFDRCxNQUFJLE9BQU8sTUFBTTtBQUNqQixTQUFPO0FBQ1Q7QUFDQSxJQUFJLFlBQThCLE1BQ2hDLFdBQWlDLE1BQ2pDLGNBQWM7QUFDaEIsTUFBTSxTQUFTLElBQUksY0FBMkIsUUFBUTtBQUN0RCxNQUFNLGdCQUFnQixTQUFTLGNBQWMsUUFBUSxHQUNuRCxTQUFTLElBQUksY0FBMkIsT0FBTztBQUNqRCxjQUFjLE9BQU87QUFDckIsY0FBYyxjQUFjO0FBQzVCLE9BQU8sT0FBTyxhQUFhO0FBQzNCLE9BQU8sV0FBVztBQUNsQixNQUFNLGFBQWEsZ0JBQWdCO0FBQUEsRUFDakMsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsU0FBUztBQUFBLEVBQ1QsT0FBTztBQUFBLEVBQ1AsWUFBWTtBQUFBLEVBQ1osTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZ0JBQWdCO0FBQ2xCLENBQUM7QUFDRCxjQUFjLFVBQVUsTUFBTSxXQUFXLE9BQU87QUFDaEQsTUFBTSxRQUFRLFdBQVcsS0FBSyxNQUFNLFlBQVksUUFBUSxZQUFZLE1BQU07QUFDMUUsU0FBUyxpQkFBaUI7QUFDeEIsUUFBTSxXQUFXO0FBQ2pCLFlBQVUsUUFBUTtBQUNsQixhQUFXLFFBQVE7QUFDbkIsV0FBUyxjQUFjLFdBQVcsRUFBRyxnQkFBZ0I7QUFDckQsV0FBUyxjQUFjLFlBQVksRUFBRyxnQkFBZ0I7QUFDdEQsV0FBUyxjQUFjLE9BQU8sRUFBRyxnQkFBZ0I7QUFDakQsV0FBUyxjQUFjLFVBQVUsRUFBRyxnQkFBZ0I7QUFDcEQsY0FBWSxJQUFJLFVBQVUsV0FBVztBQUNyQyxZQUFVLFNBQVMsVUFBVTtBQUM3QixZQUFVLFNBQVMsY0FBYyxTQUFTLE1BQU0sQ0FBQztBQUNqRCxZQUFVO0FBQUEsSUFDUjtBQUFBLE1BQ0UsWUFBWSxRQUFRLEVBQUU7QUFBQSxRQUFJLENBQUMsU0FDekIsS0FBSyxJQUFJLGFBQWEsaUJBQWlCLFlBQ3ZDLEtBQUssSUFBSSxXQUFXLFVBQ2hCO0FBQUEsVUFDRSxHQUFHO0FBQUEsVUFDSCxjQUFjO0FBQUEsWUFDWixHQUFHLEtBQUs7QUFBQSxZQUNSLE9BQU87QUFBQSxjQUNMLEdBQUcsS0FBSyxhQUFhO0FBQUEsY0FDckIsS0FBSztBQUFBLGNBQ0wsVUFBVTtBQUFBLFlBQ1o7QUFBQSxVQUNGO0FBQUEsUUFDRixJQUNBO0FBQUEsTUFDTjtBQUFBLE1BQ0EsT0FBTztBQUFBLFFBQ0wsTUFBTSxZQUFZO0FBQUEsUUFDbEIsTUFBTSxZQUFZO0FBQUEsUUFDbEIsU0FBUyxDQUFDLFlBQVksWUFBWSxDQUFDLFlBQVk7QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsWUFBVTtBQUFBLElBQ1IsU0FBUyxPQUFPO0FBQUEsTUFDZCxhQUFhLFlBQVk7QUFBQSxNQUN6QixVQUFVLFlBQVk7QUFBQSxJQUN4QixFQUFFO0FBQUEsRUFDSjtBQUNBLGdCQUFjO0FBQ2QsWUFBVSxLQUFLO0FBQUEsSUFDYixJQUFJO0FBQUEsSUFDSixRQUFRO0FBQUEsSUFDUixrQkFBa0I7QUFBQSxJQUNsQixPQUFPLENBQUM7QUFBQSxJQUNSLFFBQVE7QUFBQSxJQUNSLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDRCxZQUFVLEtBQUs7QUFBQSxJQUNiLElBQUk7QUFBQSxJQUNKLFFBQVE7QUFBQSxJQUNSLGtCQUFrQjtBQUFBLElBQ2xCLE9BQU8sQ0FBQztBQUFBLElBQ1IsUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELFlBQVUsS0FBSztBQUFBLElBQ2IsSUFBSTtBQUFBLElBQ0osUUFBUTtBQUFBLElBQ1Isa0JBQWtCO0FBQUEsSUFDbEIsT0FBTyxDQUFDO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixRQUFRO0FBQUEsRUFDVixDQUFDO0FBQ0QsWUFBVTtBQUNWLGFBQVcsSUFBSTtBQUFBLElBQ2I7QUFBQSxJQUNBO0FBQUEsSUFDQSxDQUFDLE1BQU0sUUFBUTtBQUFBLE1BQ2IsVUFBVTtBQUFBLE1BQ1YsUUFBUSxTQUFTLGVBQWUsSUFBSTtBQUFBLElBQ3RDO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsWUFBWTtBQUNuQixRQUFNLFVBQVUsWUFBWSxRQUFRLEdBQ2xDLEtBQUssWUFBWSxFQUFFO0FBQ3JCLFFBQU0sWUFBWSxTQUFTLGNBQWMsU0FBUztBQUNsRCxZQUFVLEtBQUs7QUFDZixZQUFVLFlBQVk7QUFDdEIsUUFBTSxRQUFRLFNBQVMsY0FBYyxLQUFLO0FBQzFDLFFBQU0sWUFBWTtBQUNsQixRQUFNLGNBQWMsS0FBSyxVQUFVLEVBQUUsUUFBUSxZQUFZLENBQUM7QUFDMUQsWUFBVSxPQUFPLEtBQUs7QUFDdEIsV0FBUyxjQUFjLFdBQVcsRUFBRyxPQUFPLFNBQVM7QUFDckQsWUFBVyxLQUFLO0FBQUEsSUFDZDtBQUFBLElBQ0EsUUFBUSxXQUFXO0FBQUEsSUFDbkIsa0JBQWtCO0FBQUEsSUFDbEIsT0FBTyxDQUFDO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixXQUFXLFFBQVE7QUFBQSxFQUNyQixDQUFDO0FBQ0QsWUFBVyxTQUFTLEVBQUU7QUFDeEI7QUFDQSxZQUFZLE1BQU0sV0FBVyxRQUFRLGNBQWM7QUFDbkQsWUFBWSxNQUFNLHVCQUF1QjtBQUFBLEVBQ3ZDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUNELFlBQVksTUFBTSx5QkFBeUI7QUFBQSxFQUN6QztBQUFBLEVBQ0E7QUFDRixDQUFDO0FBQ0QsTUFBTSxZQUFZLE1BQU07QUFDdEIsTUFBSSxZQUFZLEtBQU0sT0FBTSxNQUFNLEtBQUssYUFBYSxDQUFDO0FBQ3JELE1BQUksV0FBVyxRQUFRLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxTQUFTLFNBQVMsQ0FBQztBQUN2RSxVQUFNLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFDL0IsU0FBTyxDQUFDLFlBQVksU0FBUyxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQ3REO0FBRUEsU0FBUyxpQkFBaUI7QUFDeEIsWUFBVSxRQUFRO0FBQ2xCLGFBQVc7QUFDWCxhQUFXLFFBQVE7QUFDbkIsY0FBWTtBQUNkO0FBQ0EsT0FBTyxPQUFPLE1BQU07QUFDbEIsTUFBSSxDQUFDLFVBQVUsRUFBRztBQUNsQixpQkFBZTtBQUNmLGNBQVksWUFBWTtBQUN4QixpQkFBZTtBQUNqQixDQUFDO0FBQ0QsTUFBTSxnQkFBZ0IsU0FBUyxjQUFjLFFBQVE7QUFDckQsY0FBYyxjQUFjO0FBQzVCLGNBQWMsVUFBVSxNQUFNO0FBQzVCLE1BQUk7QUFDRixRQUFJLENBQUMsVUFBVSxFQUFHO0FBQ2xCLG1CQUFlO0FBQ2YsZ0JBQVksY0FBYztBQUMxQixtQkFBZTtBQUNmO0FBQUEsTUFDRTtBQUFBLElBQ0Y7QUFBQSxFQUNGLFNBQVMsT0FBTztBQUNkLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDRjtBQUNBLElBQUksT0FBTyxhQUFhO0FBQ3hCLE1BQU0sYUFBYSxPQUFPLFFBQVEsWUFBWTtBQUM1QyxRQUFNLFlBQVksS0FBSztBQUN2QixVQUFRLEtBQUssUUFBUSxDQUFDO0FBQ3hCLENBQUM7QUFDRCxPQUFPLFFBQVEsWUFBWTtBQUN6QixRQUFNLE9BQU8sU0FBUyxjQUFjLGFBQWE7QUFDakQsT0FBSyxnQkFBZ0I7QUFDckIsYUFBVyxTQUFTLE1BQU0sWUFBWSxlQUFlLEdBQUc7QUFDdEQsVUFBTSxJQUFJLFNBQVMsY0FBYyxRQUFRO0FBQ3pDLE1BQUUsY0FBYyxNQUFNO0FBQ3RCLE1BQUUsUUFBUSxjQUFjLE1BQU07QUFDOUIsTUFBRSxVQUFVLE1BQU07QUFDaEIsWUFBTSxZQUFZO0FBQ2hCLFlBQUksQ0FBQyxVQUFVLEVBQUc7QUFDbEIsY0FBTSxTQUFTLE1BQU0sWUFBWSxPQUFPLE1BQU0sR0FBRztBQUNqRCxZQUFJLE9BQU8sV0FBVyxZQUFZO0FBQ2hDLHlCQUFlO0FBQ2YsVUFBQyxTQUFTLGNBQWMsY0FBYyxFQUF3QixNQUFNO0FBQUEsUUFDdEUsTUFBTyxVQUFTLE9BQU8sS0FBSyxPQUFPLE1BQU07QUFBQSxNQUMzQyxHQUFHLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFDbkI7QUFDQSxTQUFLLE9BQU8sQ0FBQztBQUFBLEVBQ2Y7QUFDQSxNQUFJLENBQUMsS0FBSyxXQUFXLE9BQVEsTUFBSyxjQUFjLEtBQUssYUFBYTtBQUNsRSxFQUFDLFNBQVMsY0FBYyxjQUFjLEVBQXdCLFVBQVU7QUFDMUUsQ0FBQztBQUNELE9BQU8sVUFBVSxZQUFZO0FBQzNCLFFBQU0sWUFBWSxTQUFTO0FBQzNCLFVBQVEsS0FBSyxVQUFVLENBQUM7QUFDMUIsQ0FBQztBQUNELE1BQU0sWUFBWSxTQUFTLGNBQWMsUUFBUTtBQUNqRCxNQUFNLFdBQVcsU0FBUyxjQUFjLElBQUksR0FDMUMsV0FBVyxTQUFTLGNBQWMsS0FBSyxHQUN2QyxjQUFjLFNBQVMsY0FBYyxRQUFRLEdBQzdDLFdBQVcsU0FBUyxjQUFjLFFBQVE7QUFDNUMsU0FBUyxjQUFjLEtBQUssVUFBVTtBQUN0QyxZQUFZLGNBQWMsS0FBSyxhQUFhO0FBQzVDLFNBQVMsY0FBYyxLQUFLLFFBQVE7QUFDcEMsVUFBVSxNQUFNLFFBQVE7QUFDeEIsU0FBUyxNQUFNLEtBQUssVUFBVTtBQUM5QixTQUFTLE1BQU0sV0FBVztBQUMxQixTQUFTLE1BQU0sWUFBWTtBQUMzQixTQUFTLE1BQU0sVUFBVTtBQUN6QixTQUFTLE1BQU0sU0FBUztBQUN4QixVQUFVLE9BQU8sVUFBVSxVQUFVLGFBQWEsUUFBUTtBQUMxRCxJQUFJLE9BQU8sU0FBUztBQUNwQixJQUFJLFlBQVksR0FDZCxTQUFTLElBQ1QsV0FBOEIsTUFDOUIsVUFBVTtBQUNaLE1BQU0sWUFBWSxNQUFNO0FBQ3RCO0FBQ0EsYUFBVztBQUNYLE1BQUksT0FBUSxLQUFJLGdCQUFnQixNQUFNO0FBQ3RDLFdBQVM7QUFDVCxXQUFTLGdCQUFnQixLQUFLO0FBQzlCLFlBQVUsTUFBTTtBQUNsQjtBQUNBLFNBQVMsVUFBVTtBQUNuQixVQUFVLGlCQUFpQixVQUFVLENBQUMsVUFBVTtBQUM5QyxRQUFNLGVBQWU7QUFDckIsWUFBVTtBQUNaLENBQUM7QUFDRCxZQUFZLFVBQVUsTUFBTTtBQUMxQixNQUFJO0FBQ0YsU0FBSyxjQUFjLFNBQVMsU0FBUyxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sTUFBTTtBQUNyRTtBQUNBLE9BQU8sT0FBTyxZQUFZO0FBQ3hCLFlBQVU7QUFDVixRQUFNLFNBQVMsV0FDYixXQUFXLFlBQVk7QUFDekIsUUFBTSxPQUFPLFNBQVMsY0FBYyxjQUFjO0FBQ2xELFFBQU0sU0FBUyxvQkFBSSxJQUErQztBQUNsRSxRQUFNLGlCQUE4QixrQkFBa0IsRUFBRTtBQUFBLElBQVEsQ0FBQyxTQUMvRCxPQUFPLElBQUksS0FBSyxRQUFRLE1BQU87QUFBQSxNQUM3QixPQUFPLEtBQUs7QUFBQSxNQUNaLFFBQVEsS0FBSztBQUFBLElBQ2YsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLFFBQVEsU0FBUyxTQUFTLE1BQU0sT0FBTztBQUFBLElBQUssQ0FBQyxNQUNqRCxFQUFFLFFBQVEsTUFBTSxLQUFLLENBQUMsTUFBTSxPQUFPLElBQUksRUFBRSxFQUFFLENBQUM7QUFBQSxFQUM5QztBQUNBLE1BQUksQ0FBQyxNQUFPLE9BQU0sTUFBTSxvQkFBb0I7QUFDNUMsY0FBWSxXQUFXO0FBQ3ZCLFlBQVUsVUFBVTtBQUNwQixNQUFJO0FBQ0YsVUFBTSxRQUFRLE1BQU0sa0JBQWtCLFNBQVMsVUFBVSxNQUFNLElBQUksTUFBTTtBQUN6RSxRQUFJLFdBQVcsVUFBVztBQUMxQixlQUFXO0FBQ1gsY0FBVSxHQUFHLFNBQVMsU0FBUyxNQUFNLElBQUksSUFBSSxTQUFTLFNBQVMsTUFBTSxLQUFLLE1BQU0sSUFBSSxNQUFNLEdBQUc7QUFDN0YsYUFBUyxJQUFJO0FBQUEsTUFDWCxJQUFJLEtBQUssQ0FBQyxNQUFNLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUFBLElBQ3hEO0FBQ0EsYUFBUyxNQUFNO0FBQ2YsZ0JBQVksV0FBVztBQUFBLEVBQ3pCLFNBQVMsT0FBTztBQUNkLFFBQUksV0FBVyxXQUFXO0FBQ3hCLGdCQUFVO0FBQ1YsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELE1BQU0sUUFBUSxTQUFTLGNBQWMsT0FBTztBQUM1QyxNQUFNLE9BQU87QUFDYixNQUFNLGFBQWEsY0FBYyxvQkFBb0I7QUFDckQsTUFBTSxTQUFTO0FBQ2YsTUFBTSxTQUFTO0FBQ2YsSUFBSSxPQUFPLEtBQUs7QUFDaEIsT0FBTyxRQUFRLE1BQU07QUFDbkIsUUFBTSxNQUFNO0FBQ2QsQ0FBQztBQUNELE1BQU0saUJBQWlCLFVBQVUsTUFBTTtBQUNyQyxRQUFNLFlBQVk7QUFDaEIsVUFBTSxPQUFPLE1BQU0sUUFBUSxDQUFDO0FBQzVCLFFBQUksQ0FBQyxLQUFNO0FBQ1gsZ0JBQVk7QUFDWixVQUFNLFNBQVM7QUFDZixVQUFNLE9BQU8sWUFBWTtBQUN6QixhQUFTLE1BQU0sZUFBZTtBQUM5QixRQUFJO0FBQ0osUUFBSTtBQUNGLGNBQVEsTUFBTSxLQUFLLFlBQVk7QUFBQSxJQUNqQyxRQUFRO0FBQ04sVUFBSSxXQUFXLGFBQWMsVUFBUyxNQUFNLGtCQUFrQjtBQUM5RCxZQUFNLFFBQVE7QUFDZDtBQUFBLElBQ0Y7QUFDQSxRQUFJLFdBQVcsYUFBYztBQUM3QixRQUNFLEtBQUssV0FBVyxZQUFZLFNBQVMsVUFDckMsS0FBSyxhQUFhLFlBQVksU0FBUyxVQUN2QztBQUNBLGVBQVMsT0FBTyxpQkFBaUI7QUFDakMsWUFBTSxRQUFRO0FBQ2Q7QUFBQSxJQUNGO0FBQ0EsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLFlBQVksSUFBSSxXQUFXLEtBQUssR0FBRyxLQUFLLElBQUk7QUFBQSxJQUNwRCxTQUFTLE9BQU87QUFDZCxlQUFTLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxVQUFVLE9BQU8sS0FBSyxDQUFDO0FBQ3RFLFlBQU0sUUFBUTtBQUNkO0FBQUEsSUFDRjtBQUNBLG9CQUFnQixZQUFZLFlBQVksR0FBRztBQUMzQyxhQUFTLGNBQWMsY0FBYyxFQUFHLGNBQWMsS0FBSyxhQUFhO0FBQ3hFLGFBQVMsT0FBTyxjQUFjLFNBQVMsT0FBTyxjQUFjLE1BQU07QUFDbEUsa0JBQWMsY0FBYyxLQUFLO0FBQUEsTUFDL0I7QUFBQSxRQUNFLGFBQWEsY0FBYztBQUFBLFFBQzNCLFNBQVMsY0FBYztBQUFBLFFBQ3ZCLFlBQVksY0FBYztBQUFBLFFBQzFCLGNBQ0UsY0FBYyxLQUFLLFdBQVcsc0JBQzFCLGNBQWMsS0FBSyxlQUNuQixDQUFDO0FBQUEsUUFDUCxXQUFXLGNBQWM7QUFBQSxNQUMzQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLGVBQVcsY0FBYyxJQUFJLE1BQU0sR0FBRyxJQUFLO0FBQzNDLGVBQVcsU0FDVCxjQUFjLEtBQUssV0FBVyxjQUM5QixDQUFDLGNBQWMsWUFDZixjQUFjLFdBQVc7QUFDM0IsdUJBQW1CO0FBQ25CLFVBQU0sUUFBUTtBQUFBLEVBQ2hCLEdBQUcsRUFBRSxNQUFNLE1BQU07QUFDbkIsQ0FBQztBQUNELE9BQU8sWUFBWSxNQUFNO0FBQ3ZCLFFBQU0sU0FBUyxZQUFZLFNBQVM7QUFDcEMsTUFBSSxPQUFPLFdBQVc7QUFDcEIsVUFBTTtBQUFBLE1BQ0osT0FBTyxZQUFZLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssS0FBSztBQUFBLElBQ3JFO0FBQ0osQ0FBQztBQUNELE9BQU8sVUFBVSxNQUFNO0FBQ3JCLFlBQVU7QUFDWixDQUFDO0FBQ0QsTUFBTSxhQUFhO0FBQUEsRUFBTztBQUFBLEVBQVEsTUFDaEMsWUFBWSxZQUFZLENBQUMsWUFBWSxRQUFRO0FBQy9DO0FBQ0EsV0FBVyxhQUFhLGdCQUFnQixPQUFPO0FBQy9DLElBQUksV0FBd0M7QUFDNUMsSUFBSSxnQkFBMkMsTUFDN0MsZUFBZTtBQUNqQixNQUFNLGVBQWUsU0FBUyxjQUFpQyxXQUFXO0FBQzFFLGFBQWEsTUFBTSxRQUFRO0FBQzNCLE1BQU0sZ0JBQWdCLFNBQVMsY0FBYyxLQUFLLEdBQ2hELGFBQWEsU0FBUyxjQUFjLEtBQUssR0FDekMsY0FBYyxTQUFTLGNBQWMsR0FBRyxHQUN4QyxxQkFBcUIsU0FBUyxjQUFjLEdBQUcsR0FDL0MsZUFBZSxTQUFTLGNBQWMsUUFBUSxHQUM5QyxhQUFhLFNBQVMsY0FBYyxRQUFRO0FBQzlDLGNBQWMsYUFBYSxjQUFjLEtBQUssZUFBZSxDQUFDO0FBQzlELFdBQVcsYUFBYSxjQUFjLEtBQUssaUJBQWlCLENBQUM7QUFDN0QsY0FBYyxNQUFNLFlBQVk7QUFDaEMsV0FBVyxNQUFNLFlBQVk7QUFDN0IsY0FBYyxNQUFNLFdBQVcsV0FBVyxNQUFNLFdBQVc7QUFDM0QsWUFBWSxjQUFjLEtBQUssaUJBQWlCO0FBQ2hELG1CQUFtQixLQUFLO0FBQ3hCLG1CQUFtQixhQUFhLFFBQVEsUUFBUTtBQUNoRCxhQUFhLGNBQWMsS0FBSyxjQUFjO0FBQzlDLFdBQVcsY0FBYyxLQUFLLGVBQWU7QUFDN0MsYUFBYSxTQUFTLFdBQVcsU0FBUztBQUMxQyxhQUFhO0FBQUEsRUFDWDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQjtBQUM1QixNQUFJLENBQUMsZUFBZTtBQUNsQix1QkFBbUIsY0FBYztBQUNqQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLGNBQWMsWUFBWSx1QkFBdUIsYUFBYTtBQUNwRSxlQUFhLFNBQVMsQ0FBQyxjQUFjO0FBQ3JDLGVBQWEsV0FBVyxDQUFDLFlBQVk7QUFDckMsUUFBTSxPQUFPLFlBQVksWUFBWSxPQUFPLFlBQVk7QUFDeEQscUJBQW1CLGNBQWMsQ0FBQyxjQUFjLFlBQzVDLEtBQ0EsU0FBUyxPQUNQLEtBQUssY0FBYyxJQUNuQixTQUFTLHVCQUNQLEtBQUssb0JBQW9CLElBQ3pCLFNBQVMsa0JBQWtCLFNBQVMsa0JBQ2xDLEtBQUssZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLElBQzdCLFNBQVMsb0JBQ1AsS0FBSyxpQkFBaUIsSUFDdEIsU0FBUyxpQkFDUCxLQUFLLGFBQWEsSUFDbEIsS0FBSyxzQkFBc0IsRUFBRSxLQUFLLENBQUM7QUFDakQsYUFBVyxXQUNULFlBQVksWUFDWixZQUFZLFFBQ1osU0FBUyxrQkFDVCxTQUFTO0FBQ2I7QUFDQSxTQUFTLGNBQWM7QUFDckI7QUFDQSxNQUFJLGNBQWUsYUFBWSxhQUFhLGFBQWE7QUFDekQsa0JBQWdCO0FBQ2hCLGdCQUFjLGNBQWMsV0FBVyxjQUFjO0FBQ3JELHFCQUFtQixjQUFjO0FBQ2pDLGVBQWEsU0FBUyxXQUFXLFNBQVM7QUFDMUMsZUFBYSxNQUFNO0FBQ25CLFFBQU0sUUFBUTtBQUNoQjtBQUNBLGFBQWEsaUJBQWlCLFVBQVUsQ0FBQyxVQUFVO0FBQ2pELFFBQU0sZUFBZTtBQUNyQixjQUFZO0FBQ2QsQ0FBQztBQUNELGFBQWEsVUFBVSxNQUFNO0FBQzNCLE1BQUk7QUFDRixRQUFJLFdBQVcsUUFBUSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLEVBQUUsU0FBUyxTQUFTLENBQUM7QUFDdkUsWUFBTSxNQUFNLEtBQUssV0FBVyxDQUFDO0FBQy9CLFFBQUksY0FBZSxhQUFZLGFBQWEsYUFBYTtBQUN6RCxnQkFBWTtBQUFBLEVBQ2QsU0FBUyxPQUFPO0FBQ2QsYUFBUyxjQUFjLG1CQUFtQixFQUFHLGNBQzNDLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxPQUFPLEtBQUs7QUFDdkQsdUJBQW1CO0FBQUEsRUFDckI7QUFDRjtBQUNBLFdBQVcsVUFBVSxNQUFNO0FBQ3pCLE1BQUk7QUFDRixRQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxFQUFHO0FBQ3BDLGdCQUFZLGFBQWEsYUFBYTtBQUN0QyxtQkFBZTtBQUNmLGdCQUFZO0FBQUEsRUFDZCxTQUFTLE9BQU87QUFDZCxhQUFTLGNBQWMsbUJBQW1CLEVBQUcsY0FDM0MsaUJBQWlCLFFBQVEsTUFBTSxVQUFVLE9BQU8sS0FBSztBQUFBLEVBQ3pEO0FBQ0Y7QUFDQSxTQUFTLFNBQVMsS0FBa0MsUUFBZ0I7QUFDbEUsYUFBVztBQUNYLFdBQVMsY0FBYyxtQkFBbUIsRUFBRyxjQUFjLEtBQUssWUFBWTtBQUFBLElBQzFFO0FBQUEsRUFDRixDQUFDO0FBQ0QsTUFBSSxDQUFDLGFBQWEsS0FBTSxjQUFhLFVBQVU7QUFDakQ7QUFDQSxTQUNHLGNBQWMsa0JBQWtCLEVBQ2hDO0FBQUEsRUFDQztBQUFBLEVBQ0EsTUFBTSxLQUFLLGNBQWMsMEJBQTBCLFFBQVE7QUFDN0Q7QUFDRixTQUNHLGNBQWMsaUJBQWlCLEVBQy9CLGlCQUFpQixTQUFTLFdBQVc7QUFDeEMsU0FDRyxjQUFjLGNBQWMsRUFDNUI7QUFBQSxFQUFpQjtBQUFBLEVBQVMsTUFDeEIsU0FBUyxjQUFjLGNBQWMsRUFBd0IsTUFBTTtBQUN0RTtBQUNGLFlBQVksVUFBVSxNQUFNO0FBQzFCLFFBQU0sV0FBVztBQUNqQixxQkFBbUI7QUFDbkIsWUFBVSxjQUFjLFlBQVksU0FDaEMsS0FBSyxRQUFRLElBQ2IsWUFBWSxRQUNWLEtBQUssT0FBTyxJQUNaLEtBQUssT0FBTztBQUNsQixhQUFXLFdBQVcsWUFBWTtBQUNsQyxhQUFXLGFBQWEsZ0JBQWdCLE9BQU8sWUFBWSxRQUFRLENBQUM7QUFDdEUsQ0FBQztBQUNELFlBQVksWUFBWTtBQUN4QixlQUFlO0FBQ2Y7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0EsTUFBTTtBQUNKLFVBQU0sS0FBSyxXQUFXLFFBQVEsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sT0FBTyxXQUFXLEdBQ2xFLE9BQU8sUUFBUSxNQUFNO0FBQ3pCLFFBQUksQ0FBQyxHQUFJLE9BQU0sTUFBTSx3QkFBd0I7QUFDN0MsV0FBTyxZQUFZLFFBQVEsRUFBRTtBQUFBLEVBQy9CO0FBQUEsRUFDQSxJQUFJO0FBQUEsSUFDRixJQUFJLG9CQUFvQjtBQUFBLElBQ3hCLFlBQVksSUFBSSxZQUFZLEtBQUssQ0FBQztBQUFBLElBQ2xDO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLENBQUMsT0FBTyxjQUFjO0FBQ3BCLFVBQU0sTUFBTSxjQUFjO0FBQzFCLFFBQUksVUFBVSxRQUFXO0FBQ3ZCLFVBQUksT0FBTyxPQUFPLEdBQUcsRUFBRyxjQUFhO0FBQUEsSUFDdkMsTUFBTyxRQUFPLE9BQU8sR0FBRztBQUFBLEVBQzFCO0FBQ0Y7QUFJQSxNQUFNLGNBQWMsU0FBUyxjQUFjLFFBQVEsR0FDakQsY0FBYyxTQUFTLGNBQWMsS0FBSyxHQUMxQyxlQUFlLFNBQVMsY0FBYyxRQUFRLEdBQzlDLGVBQWUsU0FBUyxjQUFjLEtBQUs7QUFDN0MsWUFBWSxPQUFPO0FBQ25CLFlBQVksY0FBYztBQUMxQixZQUFZLFlBQVk7QUFDeEIsWUFBWSxZQUFZO0FBQ3hCLFlBQVksV0FBVztBQUN2QixNQUFNLGdCQUFnQixTQUFTLGNBQWMsS0FBSyxHQUNoRCxpQkFBaUIsU0FBUyxjQUFjLEtBQUs7QUFDL0MsV0FBVyxDQUFDLE9BQU8sS0FBSyxLQUFLO0FBQUEsRUFDM0IsQ0FBQyxlQUFlLHVCQUF1QjtBQUFBLEVBQ3ZDLENBQUMsZ0JBQWdCLFdBQVc7QUFDOUIsR0FBWTtBQUNWLFFBQU0sYUFBYSxRQUFRLE9BQU87QUFDbEMsUUFBTSxZQUFZO0FBQ2xCLGNBQVksT0FBTyxLQUFLO0FBQzFCO0FBQ0EsV0FBVyxTQUFTLE1BQU0sS0FBSyxJQUFJLFFBQVEsR0FBRztBQUM1QyxRQUFNLE1BQU8sTUFBc0IsUUFBUTtBQUMzQyxNQUFJLEVBQUUsaUJBQWlCLG1CQUFvQixLQUFJLE9BQU8sS0FBSztBQUFBLFdBQ2xELFFBQVEsVUFBVSxRQUFRLFlBQVk7QUFDN0MsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBLFFBQVEsU0FBUyxxQkFBcUI7QUFBQSxJQUN4QztBQUNBLEtBQUMsUUFBUSxZQUFZLFFBQVEsU0FDekIsaUJBQ0EsZUFDRixPQUFPLEtBQUs7QUFBQSxFQUNoQjtBQUNGO0FBQ0EsT0FBTyxRQUFRLFdBQVc7QUFDMUIsTUFBTSxjQUFjLGdCQUFnQjtBQUFBLEVBQ2xDLE1BQU07QUFBQSxFQUNOLFNBQVM7QUFBQSxFQUNULFNBQVM7QUFBQSxFQUNULE9BQU87QUFBQSxFQUNQLFlBQVk7QUFBQSxFQUNaLE1BQU07QUFBQSxFQUNOLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFDYixDQUFDO0FBQ0QsWUFBWSxVQUFVLE1BQU0sWUFBWSxPQUFPO0FBQy9DLFlBQVksaUJBQWlCLFNBQVMsQ0FBQyxVQUFVO0FBQy9DLFFBQU1DLFVBQVUsTUFBTSxPQUFtQixRQUEyQixRQUFRLEdBQ3hFLFFBQVE7QUFFWixNQUFJQSxXQUFVLENBQUMsT0FBTyxVQUFVLFFBQVEsVUFBVSxNQUFNLEVBQUUsU0FBU0EsT0FBTTtBQUN2RSxnQkFBWSxNQUFNLEtBQUs7QUFDM0IsQ0FBQztBQUNELGFBQWEsT0FBTztBQUNwQixhQUFhLGNBQWM7QUFDM0IsYUFBYSxXQUFXO0FBQ3hCLFdBQVcsUUFBUSxNQUFNLEtBQUssT0FBTyxpQkFBaUIsZUFBZSxDQUFDO0FBQ3BFLGVBQWEsT0FBTyxJQUFJO0FBQzFCLE1BQU0sY0FBYyxTQUFTLGNBQWMsTUFBTTtBQUNqRCxZQUFZLGNBQ1Y7QUFDRixhQUFhLE9BQU8sV0FBVztBQUMvQixPQUFPLE9BQU8sWUFBWTtBQUMxQixNQUFNLFlBQVksZ0JBQWdCO0FBQUEsRUFDaEMsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsU0FBUztBQUFBLEVBQ1QsT0FBTztBQUFBLEVBQ1AsWUFBWTtBQUFBLEVBQ1osTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUNULENBQUM7QUFDRCxhQUFhLFVBQVUsTUFBTSxVQUFVLE9BQU87IiwibmFtZXMiOlsidGV4dCIsImFjdGlvbiJdfQ==