import { floatingSurface } from "/src/ui/floating.ts";
const entries = /* @__PURE__ */ new WeakMap(), owners = /* @__PURE__ */ new Set(), invalidations = /* @__PURE__ */ new Set();
export function invalidateHover(target) {
  if (typeof Element !== "undefined" && target instanceof Element)
    for (const invalidate of invalidations) {
      try {
        invalidate(target);
      } catch {
      }
    }
}
export function hoverOwner(target, scope, blocked = () => null) {
  if (!(target instanceof Element))
    return { set: () => {
    }, invalidate: () => {
    } };
  const root = target;
  const owner = { root, live: true, blocked };
  owners.add(owner);
  scope.own(() => {
    owner.live = false;
    owners.delete(owner);
    invalidateHover(root);
  });
  return {
    set(target2, read) {
      if (!(target2 instanceof Element)) return;
      const element = target2;
      if (!owner.live || !root.contains(element)) return;
      invalidateHover(element);
      entries.set(element, { owner, read });
    },
    invalidate: () => invalidateHover(root)
  };
}
export function mountHover(root, busy) {
  const cleanups = [];
  const release = () => {
    for (const cleanup of cleanups.splice(0).reverse()) {
      try {
        cleanup();
      } catch {
      }
    }
  };
  try {
    const content = document.createElement("pre");
    content.className = "status-details-text";
    content.tabIndex = 0;
    content.setAttribute("role", "region");
    content.ariaLabel = "Current object data";
    let active = null, disposed = false;
    const listen = (target, type, callback, capture = false) => {
      target.addEventListener(type, callback, capture);
      cleanups.push(() => target.removeEventListener(type, callback, capture));
    };
    const visible = (element) => element.isConnected && element.getClientRects().length > 0 && getComputedStyle(element).visibility !== "hidden";
    const valid = () => active && root.contains(active.element) && visible(active.element) && (!active.entry || active.entry.owner.live && active.entry.owner.root.contains(active.element) && entries.get(active.element) === active.entry);
    const details = floatingSurface({
      host: root,
      content,
      title: "Object information",
      closeLabel: "Close object details",
      kind: "modal",
      width: 680,
      maxHeight: 700,
      closed: () => {
        active = null;
        content.textContent = "";
      }
    });
    cleanups.push(() => details.dispose());
    details.surface.classList.add("hover-details", "hover-owned-surface");
    const clear = () => {
      active = null;
      content.textContent = "";
      try {
        details.close(false);
      } catch {
      }
    };
    const invalidated = (element) => {
      if (active && (element === active.element || element.contains(active.element)))
        clear();
    };
    invalidations.add(invalidated);
    cleanups.push(() => invalidations.delete(invalidated));
    const resolve = (target) => {
      let panel = null;
      for (let e = target; e && root.contains(e); e = e.parentElement) {
        const entry = entries.get(e);
        if (!entry || !entry.owner.live || !entry.owner.root.contains(e))
          continue;
        if (e === entry.owner.root && e.hasAttribute("data-hover-panel"))
          panel ??= { element: e, entry };
        else return { element: e, entry };
      }
      const control = target.closest("button,input,select,textarea,summary,a");
      return control && root.contains(control) ? { element: control, entry: null } : panel;
    };
    const fallback = (element) => ({
      kind: "UI control",
      name: element.getAttribute("aria-label") || element.getAttribute("title") || element.textContent?.trim().slice(0, 100) || element.tagName,
      identity: element.id || "未提供",
      state: element.disabled ? "UI-only · disabled" : "UI-only · available",
      data: {
        modelData: "未提供",
        role: element.getAttribute("role") || element.tagName.toLowerCase()
      }
    });
    listen(root, "keydown", (event) => {
      const e = event;
      if (disposed || e.key !== "F2" || e.isComposing || e.repeat || e.defaultPrevented || details.surface.open)
        return;
      const focused = document.activeElement;
      if (!(focused instanceof Element) || !root.contains(focused) || focused.closest(".hover-owned-surface"))
        return;
      try {
        if (busy()) return;
        for (const owner of owners) {
          if (!owner.live || !root.contains(owner.root) || !visible(owner.root))
            continue;
          const reason = owner.blocked();
          if (reason && reason.kind !== "draft") return;
        }
        const target = resolve(focused);
        if (!target || !visible(target.element)) return;
        active = target;
        let info;
        try {
          info = target.entry ? target.entry.read() : fallback(target.element);
        } catch {
          info = {
            kind: "Object",
            name: "未提供",
            identity: "未提供",
            state: "Unavailable",
            data: { reason: "Owner data unavailable" }
          };
        }
        if (!valid()) {
          clear();
          return;
        }
        content.textContent = info.kind + ": " + info.name + "\nIdentity: " + info.identity + "\nState: " + info.state + "\n\n" + (info.data === void 0 ? "未提供" : JSON.stringify(info.data, null, 2));
        if (!valid() || disposed) {
          clear();
          return;
        }
        if (details.open()) e.preventDefault();
      } catch {
        clear();
      }
    });
    listen(root, "input", () => clear());
    listen(root, "compositionstart", () => clear());
    listen(
      root,
      "pointerdown",
      (e) => {
        if (!e.target?.closest(".hover-owned-surface")) clear();
      },
      true
    );
    listen(window, "blur", () => clear());
    listen(document, "visibilitychange", () => {
      if (document.hidden) clear();
    });
    const observer = new MutationObserver(() => {
      if (active && !valid()) clear();
    });
    observer.observe(root, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["hidden", "style", "class"]
    });
    cleanups.push(() => observer.disconnect());
    return {
      invalidate: clear,
      dispose: () => {
        if (disposed) return;
        disposed = true;
        clear();
        release();
      }
    };
  } catch {
    release();
    return { invalidate: () => {
    }, dispose: () => {
    } };
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvdmVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGZsb2F0aW5nU3VyZmFjZSB9IGZyb20gXCIuL2Zsb2F0aW5nLnRzXCI7XG5pbXBvcnQgdHlwZSB7XG4gIEhvdmVyQmxvY2ssXG4gIE1vdW50U2NvcGUsXG4gIEhvdmVySW5mbyxcbiAgSG92ZXJSZWFkVmlldyxcbn0gZnJvbSBcIi4uL3Nkay92aWV3LW1vdW50LnRzXCI7XG50eXBlIE93bmVyID0geyByb290OiBFbGVtZW50OyBsaXZlOiBib29sZWFuOyBibG9ja2VkOiAoKSA9PiBIb3ZlckJsb2NrIHwgbnVsbCB9O1xudHlwZSBFbnRyeSA9IHsgb3duZXI6IE93bmVyOyByZWFkOiAoKSA9PiBIb3ZlckluZm8gfTtcbmNvbnN0IGVudHJpZXMgPSBuZXcgV2Vha01hcDxFbGVtZW50LCBFbnRyeT4oKSxcbiAgb3duZXJzID0gbmV3IFNldDxPd25lcj4oKSxcbiAgaW52YWxpZGF0aW9ucyA9IG5ldyBTZXQ8KHJvb3Q6IEVsZW1lbnQpID0+IHZvaWQ+KCk7XG5leHBvcnQgZnVuY3Rpb24gaW52YWxpZGF0ZUhvdmVyKHRhcmdldDogdW5rbm93bik6IHZvaWQge1xuICBpZiAodHlwZW9mIEVsZW1lbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgdGFyZ2V0IGluc3RhbmNlb2YgRWxlbWVudClcbiAgICBmb3IgKGNvbnN0IGludmFsaWRhdGUgb2YgaW52YWxpZGF0aW9ucykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgaW52YWxpZGF0ZSh0YXJnZXQpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8qIE9wdGlvbmFsIGluc3BlY3Rpb24gY2Fubm90IGludGVycnVwdCBwdWJsaWNhdGlvbiBvciB0ZWFyZG93bi4gKi9cbiAgICAgIH1cbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gaG92ZXJPd25lcihcbiAgdGFyZ2V0OiB1bmtub3duLFxuICBzY29wZTogUGljazxNb3VudFNjb3BlLCBcIm93blwiPixcbiAgYmxvY2tlZDogKCkgPT4gSG92ZXJCbG9jayB8IG51bGwgPSAoKSA9PiBudWxsLFxuKTogSG92ZXJSZWFkVmlldyB7XG4gIGlmICghKHRhcmdldCBpbnN0YW5jZW9mIEVsZW1lbnQpKVxuICAgIHJldHVybiB7IHNldDogKCkgPT4ge30sIGludmFsaWRhdGU6ICgpID0+IHt9IH07XG4gIGNvbnN0IHJvb3QgPSB0YXJnZXQ7XG4gIGNvbnN0IG93bmVyOiBPd25lciA9IHsgcm9vdCwgbGl2ZTogdHJ1ZSwgYmxvY2tlZCB9O1xuICBvd25lcnMuYWRkKG93bmVyKTtcbiAgc2NvcGUub3duKCgpID0+IHtcbiAgICBvd25lci5saXZlID0gZmFsc2U7XG4gICAgb3duZXJzLmRlbGV0ZShvd25lcik7XG4gICAgaW52YWxpZGF0ZUhvdmVyKHJvb3QpO1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBzZXQodGFyZ2V0OiB1bmtub3duLCByZWFkOiAoKSA9PiBIb3ZlckluZm8pIHtcbiAgICAgIGlmICghKHRhcmdldCBpbnN0YW5jZW9mIEVsZW1lbnQpKSByZXR1cm47XG4gICAgICBjb25zdCBlbGVtZW50ID0gdGFyZ2V0O1xuICAgICAgaWYgKCFvd25lci5saXZlIHx8ICFyb290LmNvbnRhaW5zKGVsZW1lbnQpKSByZXR1cm47XG4gICAgICBpbnZhbGlkYXRlSG92ZXIoZWxlbWVudCk7XG4gICAgICBlbnRyaWVzLnNldChlbGVtZW50LCB7IG93bmVyLCByZWFkIH0pO1xuICAgIH0sXG4gICAgaW52YWxpZGF0ZTogKCkgPT4gaW52YWxpZGF0ZUhvdmVyKHJvb3QpLFxuICB9O1xufVxuLyoqIE9wdGlvbmFsIHNoZWxsIGluc3BlY3Rpb246IG93bmVyIGRhdGEgaXMgcmVhZCBvbmx5IG9uIGFuIGV4cGxpY2l0IEYyIHJlcXVlc3QuICovXG5leHBvcnQgZnVuY3Rpb24gbW91bnRIb3Zlcihyb290OiBIVE1MRWxlbWVudCwgYnVzeTogKCkgPT4gYm9vbGVhbikge1xuICBjb25zdCBjbGVhbnVwczogKCgpID0+IHZvaWQpW10gPSBbXTtcbiAgY29uc3QgcmVsZWFzZSA9ICgpID0+IHtcbiAgICBmb3IgKGNvbnN0IGNsZWFudXAgb2YgY2xlYW51cHMuc3BsaWNlKDApLnJldmVyc2UoKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY2xlYW51cCgpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8qIENvbnRpbnVlIHJlbGVhc2luZyB0aGlzIG9wdGlvbmFsIGhlbHBlci4gKi9cbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIHRyeSB7XG4gICAgY29uc3QgY29udGVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJwcmVcIik7XG4gICAgY29udGVudC5jbGFzc05hbWUgPSBcInN0YXR1cy1kZXRhaWxzLXRleHRcIjtcbiAgICBjb250ZW50LnRhYkluZGV4ID0gMDtcbiAgICBjb250ZW50LnNldEF0dHJpYnV0ZShcInJvbGVcIiwgXCJyZWdpb25cIik7XG4gICAgY29udGVudC5hcmlhTGFiZWwgPSBcIkN1cnJlbnQgb2JqZWN0IGRhdGFcIjtcbiAgICBsZXQgYWN0aXZlOiB7IGVsZW1lbnQ6IEVsZW1lbnQ7IGVudHJ5OiBFbnRyeSB8IG51bGwgfSB8IG51bGwgPSBudWxsLFxuICAgICAgZGlzcG9zZWQgPSBmYWxzZTtcbiAgICBjb25zdCBsaXN0ZW4gPSAoXG4gICAgICB0YXJnZXQ6IEV2ZW50VGFyZ2V0LFxuICAgICAgdHlwZTogc3RyaW5nLFxuICAgICAgY2FsbGJhY2s6IEV2ZW50TGlzdGVuZXIsXG4gICAgICBjYXB0dXJlID0gZmFsc2UsXG4gICAgKSA9PiB7XG4gICAgICB0YXJnZXQuYWRkRXZlbnRMaXN0ZW5lcih0eXBlLCBjYWxsYmFjaywgY2FwdHVyZSk7XG4gICAgICBjbGVhbnVwcy5wdXNoKCgpID0+IHRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKHR5cGUsIGNhbGxiYWNrLCBjYXB0dXJlKSk7XG4gICAgfTtcbiAgICBjb25zdCB2aXNpYmxlID0gKGVsZW1lbnQ6IEVsZW1lbnQpID0+XG4gICAgICBlbGVtZW50LmlzQ29ubmVjdGVkICYmXG4gICAgICBlbGVtZW50LmdldENsaWVudFJlY3RzKCkubGVuZ3RoID4gMCAmJlxuICAgICAgZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KS52aXNpYmlsaXR5ICE9PSBcImhpZGRlblwiO1xuICAgIGNvbnN0IHZhbGlkID0gKCkgPT5cbiAgICAgIGFjdGl2ZSAmJlxuICAgICAgcm9vdC5jb250YWlucyhhY3RpdmUuZWxlbWVudCkgJiZcbiAgICAgIHZpc2libGUoYWN0aXZlLmVsZW1lbnQpICYmXG4gICAgICAoIWFjdGl2ZS5lbnRyeSB8fFxuICAgICAgICAoYWN0aXZlLmVudHJ5Lm93bmVyLmxpdmUgJiZcbiAgICAgICAgICBhY3RpdmUuZW50cnkub3duZXIucm9vdC5jb250YWlucyhhY3RpdmUuZWxlbWVudCkgJiZcbiAgICAgICAgICBlbnRyaWVzLmdldChhY3RpdmUuZWxlbWVudCkgPT09IGFjdGl2ZS5lbnRyeSkpO1xuICAgIGNvbnN0IGRldGFpbHMgPSBmbG9hdGluZ1N1cmZhY2Uoe1xuICAgICAgaG9zdDogcm9vdCxcbiAgICAgIGNvbnRlbnQsXG4gICAgICB0aXRsZTogXCJPYmplY3QgaW5mb3JtYXRpb25cIixcbiAgICAgIGNsb3NlTGFiZWw6IFwiQ2xvc2Ugb2JqZWN0IGRldGFpbHNcIixcbiAgICAgIGtpbmQ6IFwibW9kYWxcIixcbiAgICAgIHdpZHRoOiA2ODAsXG4gICAgICBtYXhIZWlnaHQ6IDcwMCxcbiAgICAgIGNsb3NlZDogKCkgPT4ge1xuICAgICAgICBhY3RpdmUgPSBudWxsO1xuICAgICAgICBjb250ZW50LnRleHRDb250ZW50ID0gXCJcIjtcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgY2xlYW51cHMucHVzaCgoKSA9PiBkZXRhaWxzLmRpc3Bvc2UoKSk7XG4gICAgZGV0YWlscy5zdXJmYWNlLmNsYXNzTGlzdC5hZGQoXCJob3Zlci1kZXRhaWxzXCIsIFwiaG92ZXItb3duZWQtc3VyZmFjZVwiKTtcbiAgICBjb25zdCBjbGVhciA9ICgpID0+IHtcbiAgICAgIGFjdGl2ZSA9IG51bGw7XG4gICAgICBjb250ZW50LnRleHRDb250ZW50ID0gXCJcIjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGRldGFpbHMuY2xvc2UoZmFsc2UpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8qIE5ldmVyIGZhaWwgY29yZSBwdWJsaWNhdGlvbi4gKi9cbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGludmFsaWRhdGVkID0gKGVsZW1lbnQ6IEVsZW1lbnQpID0+IHtcbiAgICAgIGlmIChcbiAgICAgICAgYWN0aXZlICYmXG4gICAgICAgIChlbGVtZW50ID09PSBhY3RpdmUuZWxlbWVudCB8fCBlbGVtZW50LmNvbnRhaW5zKGFjdGl2ZS5lbGVtZW50KSlcbiAgICAgIClcbiAgICAgICAgY2xlYXIoKTtcbiAgICB9O1xuICAgIGludmFsaWRhdGlvbnMuYWRkKGludmFsaWRhdGVkKTtcbiAgICBjbGVhbnVwcy5wdXNoKCgpID0+IGludmFsaWRhdGlvbnMuZGVsZXRlKGludmFsaWRhdGVkKSk7XG4gICAgY29uc3QgcmVzb2x2ZSA9ICh0YXJnZXQ6IEVsZW1lbnQpID0+IHtcbiAgICAgIGxldCBwYW5lbDogeyBlbGVtZW50OiBFbGVtZW50OyBlbnRyeTogRW50cnkgfSB8IG51bGwgPSBudWxsO1xuICAgICAgZm9yIChcbiAgICAgICAgbGV0IGU6IEVsZW1lbnQgfCBudWxsID0gdGFyZ2V0O1xuICAgICAgICBlICYmIHJvb3QuY29udGFpbnMoZSk7XG4gICAgICAgIGUgPSBlLnBhcmVudEVsZW1lbnRcbiAgICAgICkge1xuICAgICAgICBjb25zdCBlbnRyeSA9IGVudHJpZXMuZ2V0KGUpO1xuICAgICAgICBpZiAoIWVudHJ5IHx8ICFlbnRyeS5vd25lci5saXZlIHx8ICFlbnRyeS5vd25lci5yb290LmNvbnRhaW5zKGUpKVxuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICBpZiAoZSA9PT0gZW50cnkub3duZXIucm9vdCAmJiBlLmhhc0F0dHJpYnV0ZShcImRhdGEtaG92ZXItcGFuZWxcIikpXG4gICAgICAgICAgcGFuZWwgPz89IHsgZWxlbWVudDogZSwgZW50cnkgfTtcbiAgICAgICAgZWxzZSByZXR1cm4geyBlbGVtZW50OiBlLCBlbnRyeSB9O1xuICAgICAgfVxuICAgICAgY29uc3QgY29udHJvbCA9IHRhcmdldC5jbG9zZXN0KFwiYnV0dG9uLGlucHV0LHNlbGVjdCx0ZXh0YXJlYSxzdW1tYXJ5LGFcIik7XG4gICAgICByZXR1cm4gY29udHJvbCAmJiByb290LmNvbnRhaW5zKGNvbnRyb2wpXG4gICAgICAgID8geyBlbGVtZW50OiBjb250cm9sLCBlbnRyeTogbnVsbCB9XG4gICAgICAgIDogcGFuZWw7XG4gICAgfTtcbiAgICBjb25zdCBmYWxsYmFjayA9IChlbGVtZW50OiBFbGVtZW50KTogSG92ZXJJbmZvID0+ICh7XG4gICAgICBraW5kOiBcIlVJIGNvbnRyb2xcIixcbiAgICAgIG5hbWU6XG4gICAgICAgIGVsZW1lbnQuZ2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiKSB8fFxuICAgICAgICBlbGVtZW50LmdldEF0dHJpYnV0ZShcInRpdGxlXCIpIHx8XG4gICAgICAgIGVsZW1lbnQudGV4dENvbnRlbnQ/LnRyaW0oKS5zbGljZSgwLCAxMDApIHx8XG4gICAgICAgIGVsZW1lbnQudGFnTmFtZSxcbiAgICAgIGlkZW50aXR5OiBlbGVtZW50LmlkIHx8IFwi5pyq5o+Q5L6bXCIsXG4gICAgICBzdGF0ZTogKGVsZW1lbnQgYXMgSFRNTEJ1dHRvbkVsZW1lbnQpLmRpc2FibGVkXG4gICAgICAgID8gXCJVSS1vbmx5IMK3IGRpc2FibGVkXCJcbiAgICAgICAgOiBcIlVJLW9ubHkgwrcgYXZhaWxhYmxlXCIsXG4gICAgICBkYXRhOiB7XG4gICAgICAgIG1vZGVsRGF0YTogXCLmnKrmj5DkvptcIixcbiAgICAgICAgcm9sZTogZWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJyb2xlXCIpIHx8IGVsZW1lbnQudGFnTmFtZS50b0xvd2VyQ2FzZSgpLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICAvLyBObyBwb2ludGVyL2ZvY3VzIHJlYWRlciwgdGltZXIgb3IgcHJlZmVyZW5jZS4gRXhpc3RpbmcgbmF0aXZlIHRpdGxlcyByZW1haW4gdW50b3VjaGVkLlxuICAgIGxpc3Rlbihyb290LCBcImtleWRvd25cIiwgKGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCBlID0gZXZlbnQgYXMgS2V5Ym9hcmRFdmVudDtcbiAgICAgIGlmIChcbiAgICAgICAgZGlzcG9zZWQgfHxcbiAgICAgICAgZS5rZXkgIT09IFwiRjJcIiB8fFxuICAgICAgICBlLmlzQ29tcG9zaW5nIHx8XG4gICAgICAgIGUucmVwZWF0IHx8XG4gICAgICAgIGUuZGVmYXVsdFByZXZlbnRlZCB8fFxuICAgICAgICBkZXRhaWxzLnN1cmZhY2Uub3BlblxuICAgICAgKVxuICAgICAgICByZXR1cm47XG4gICAgICBjb25zdCBmb2N1c2VkID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgICAgIGlmIChcbiAgICAgICAgIShmb2N1c2VkIGluc3RhbmNlb2YgRWxlbWVudCkgfHxcbiAgICAgICAgIXJvb3QuY29udGFpbnMoZm9jdXNlZCkgfHxcbiAgICAgICAgZm9jdXNlZC5jbG9zZXN0KFwiLmhvdmVyLW93bmVkLXN1cmZhY2VcIilcbiAgICAgIClcbiAgICAgICAgcmV0dXJuO1xuICAgICAgdHJ5IHtcbiAgICAgICAgaWYgKGJ1c3koKSkgcmV0dXJuO1xuICAgICAgICBmb3IgKGNvbnN0IG93bmVyIG9mIG93bmVycykge1xuICAgICAgICAgIGlmICghb3duZXIubGl2ZSB8fCAhcm9vdC5jb250YWlucyhvd25lci5yb290KSB8fCAhdmlzaWJsZShvd25lci5yb290KSlcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIGNvbnN0IHJlYXNvbiA9IG93bmVyLmJsb2NrZWQoKTtcbiAgICAgICAgICBpZiAocmVhc29uICYmIHJlYXNvbi5raW5kICE9PSBcImRyYWZ0XCIpIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0YXJnZXQgPSByZXNvbHZlKGZvY3VzZWQpO1xuICAgICAgICBpZiAoIXRhcmdldCB8fCAhdmlzaWJsZSh0YXJnZXQuZWxlbWVudCkpIHJldHVybjtcbiAgICAgICAgYWN0aXZlID0gdGFyZ2V0O1xuICAgICAgICBsZXQgaW5mbzogSG92ZXJJbmZvO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGluZm8gPSB0YXJnZXQuZW50cnkgPyB0YXJnZXQuZW50cnkucmVhZCgpIDogZmFsbGJhY2sodGFyZ2V0LmVsZW1lbnQpO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICBpbmZvID0ge1xuICAgICAgICAgICAga2luZDogXCJPYmplY3RcIixcbiAgICAgICAgICAgIG5hbWU6IFwi5pyq5o+Q5L6bXCIsXG4gICAgICAgICAgICBpZGVudGl0eTogXCLmnKrmj5DkvptcIixcbiAgICAgICAgICAgIHN0YXRlOiBcIlVuYXZhaWxhYmxlXCIsXG4gICAgICAgICAgICBkYXRhOiB7IHJlYXNvbjogXCJPd25lciBkYXRhIHVuYXZhaWxhYmxlXCIgfSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIC8vIEFuIG93bmVyIGludmFsaWRhdGlvbiBkdXJpbmcgcmVhZCBjYW5ub3QgcmV2aXZlIGEgcmV2b2tlZCBwcm9qZWN0aW9uLlxuICAgICAgICBpZiAoIXZhbGlkKCkpIHtcbiAgICAgICAgICBjbGVhcigpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb250ZW50LnRleHRDb250ZW50ID1cbiAgICAgICAgICBpbmZvLmtpbmQgK1xuICAgICAgICAgIFwiOiBcIiArXG4gICAgICAgICAgaW5mby5uYW1lICtcbiAgICAgICAgICBcIlxcbklkZW50aXR5OiBcIiArXG4gICAgICAgICAgaW5mby5pZGVudGl0eSArXG4gICAgICAgICAgXCJcXG5TdGF0ZTogXCIgK1xuICAgICAgICAgIGluZm8uc3RhdGUgK1xuICAgICAgICAgIFwiXFxuXFxuXCIgK1xuICAgICAgICAgIChpbmZvLmRhdGEgPT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgPyBcIuacquaPkOS+m1wiXG4gICAgICAgICAgICA6IEpTT04uc3RyaW5naWZ5KGluZm8uZGF0YSwgbnVsbCwgMikpO1xuICAgICAgICBpZiAoIXZhbGlkKCkgfHwgZGlzcG9zZWQpIHtcbiAgICAgICAgICBjbGVhcigpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZGV0YWlscy5vcGVuKCkpIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBjbGVhcigpO1xuICAgICAgfSAvLyBGYWlsZWQgZ3VhcmRzL3NlcmlhbGl6YXRpb24vcHJlc2VudGF0aW9uIHJlbWFpbiBsb2NhbCB0byBpbnNwZWN0aW9uLlxuICAgIH0pO1xuICAgIGxpc3Rlbihyb290LCBcImlucHV0XCIsICgpID0+IGNsZWFyKCkpO1xuICAgIGxpc3Rlbihyb290LCBcImNvbXBvc2l0aW9uc3RhcnRcIiwgKCkgPT4gY2xlYXIoKSk7XG4gICAgbGlzdGVuKFxuICAgICAgcm9vdCxcbiAgICAgIFwicG9pbnRlcmRvd25cIixcbiAgICAgIChlKSA9PiB7XG4gICAgICAgIGlmICghKGUudGFyZ2V0IGFzIEVsZW1lbnQpPy5jbG9zZXN0KFwiLmhvdmVyLW93bmVkLXN1cmZhY2VcIikpIGNsZWFyKCk7XG4gICAgICB9LFxuICAgICAgdHJ1ZSxcbiAgICApO1xuICAgIGxpc3Rlbih3aW5kb3csIFwiYmx1clwiLCAoKSA9PiBjbGVhcigpKTtcbiAgICBsaXN0ZW4oZG9jdW1lbnQsIFwidmlzaWJpbGl0eWNoYW5nZVwiLCAoKSA9PiB7XG4gICAgICBpZiAoZG9jdW1lbnQuaGlkZGVuKSBjbGVhcigpO1xuICAgIH0pO1xuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgaWYgKGFjdGl2ZSAmJiAhdmFsaWQoKSkgY2xlYXIoKTtcbiAgICB9KTtcbiAgICBvYnNlcnZlci5vYnNlcnZlKHJvb3QsIHtcbiAgICAgIGNoaWxkTGlzdDogdHJ1ZSxcbiAgICAgIHN1YnRyZWU6IHRydWUsXG4gICAgICBhdHRyaWJ1dGVzOiB0cnVlLFxuICAgICAgYXR0cmlidXRlRmlsdGVyOiBbXCJoaWRkZW5cIiwgXCJzdHlsZVwiLCBcImNsYXNzXCJdLFxuICAgIH0pO1xuICAgIGNsZWFudXBzLnB1c2goKCkgPT4gb2JzZXJ2ZXIuZGlzY29ubmVjdCgpKTtcbiAgICByZXR1cm4ge1xuICAgICAgaW52YWxpZGF0ZTogY2xlYXIsXG4gICAgICBkaXNwb3NlOiAoKSA9PiB7XG4gICAgICAgIGlmIChkaXNwb3NlZCkgcmV0dXJuO1xuICAgICAgICBkaXNwb3NlZCA9IHRydWU7XG4gICAgICAgIGNsZWFyKCk7XG4gICAgICAgIHJlbGVhc2UoKTtcbiAgICAgIH0sXG4gICAgfTtcbiAgfSBjYXRjaCB7XG4gICAgcmVsZWFzZSgpO1xuICAgIHJldHVybiB7IGludmFsaWRhdGU6ICgpID0+IHt9LCBkaXNwb3NlOiAoKSA9PiB7fSB9O1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsdUJBQXVCO0FBU2hDLE1BQU0sVUFBVSxvQkFBSSxRQUF3QixHQUMxQyxTQUFTLG9CQUFJLElBQVcsR0FDeEIsZ0JBQWdCLG9CQUFJLElBQTZCO0FBQzVDLGdCQUFTLGdCQUFnQixRQUF1QjtBQUNyRCxNQUFJLE9BQU8sWUFBWSxlQUFlLGtCQUFrQjtBQUN0RCxlQUFXLGNBQWMsZUFBZTtBQUN0QyxVQUFJO0FBQ0YsbUJBQVcsTUFBTTtBQUFBLE1BQ25CLFFBQVE7QUFBQSxNQUVSO0FBQUEsSUFDRjtBQUNKO0FBQ08sZ0JBQVMsV0FDZCxRQUNBLE9BQ0EsVUFBbUMsTUFBTSxNQUMxQjtBQUNmLE1BQUksRUFBRSxrQkFBa0I7QUFDdEIsV0FBTyxFQUFFLEtBQUssTUFBTTtBQUFBLElBQUMsR0FBRyxZQUFZLE1BQU07QUFBQSxJQUFDLEVBQUU7QUFDL0MsUUFBTSxPQUFPO0FBQ2IsUUFBTSxRQUFlLEVBQUUsTUFBTSxNQUFNLE1BQU0sUUFBUTtBQUNqRCxTQUFPLElBQUksS0FBSztBQUNoQixRQUFNLElBQUksTUFBTTtBQUNkLFVBQU0sT0FBTztBQUNiLFdBQU8sT0FBTyxLQUFLO0FBQ25CLG9CQUFnQixJQUFJO0FBQUEsRUFDdEIsQ0FBQztBQUNELFNBQU87QUFBQSxJQUNMLElBQUlBLFNBQWlCLE1BQXVCO0FBQzFDLFVBQUksRUFBRUEsbUJBQWtCLFNBQVU7QUFDbEMsWUFBTSxVQUFVQTtBQUNoQixVQUFJLENBQUMsTUFBTSxRQUFRLENBQUMsS0FBSyxTQUFTLE9BQU8sRUFBRztBQUM1QyxzQkFBZ0IsT0FBTztBQUN2QixjQUFRLElBQUksU0FBUyxFQUFFLE9BQU8sS0FBSyxDQUFDO0FBQUEsSUFDdEM7QUFBQSxJQUNBLFlBQVksTUFBTSxnQkFBZ0IsSUFBSTtBQUFBLEVBQ3hDO0FBQ0Y7QUFFTyxnQkFBUyxXQUFXLE1BQW1CLE1BQXFCO0FBQ2pFLFFBQU0sV0FBMkIsQ0FBQztBQUNsQyxRQUFNLFVBQVUsTUFBTTtBQUNwQixlQUFXLFdBQVcsU0FBUyxPQUFPLENBQUMsRUFBRSxRQUFRLEdBQUc7QUFDbEQsVUFBSTtBQUNGLGdCQUFRO0FBQUEsTUFDVixRQUFRO0FBQUEsTUFFUjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sVUFBVSxTQUFTLGNBQWMsS0FBSztBQUM1QyxZQUFRLFlBQVk7QUFDcEIsWUFBUSxXQUFXO0FBQ25CLFlBQVEsYUFBYSxRQUFRLFFBQVE7QUFDckMsWUFBUSxZQUFZO0FBQ3BCLFFBQUksU0FBMkQsTUFDN0QsV0FBVztBQUNiLFVBQU0sU0FBUyxDQUNiLFFBQ0EsTUFDQSxVQUNBLFVBQVUsVUFDUDtBQUNILGFBQU8saUJBQWlCLE1BQU0sVUFBVSxPQUFPO0FBQy9DLGVBQVMsS0FBSyxNQUFNLE9BQU8sb0JBQW9CLE1BQU0sVUFBVSxPQUFPLENBQUM7QUFBQSxJQUN6RTtBQUNBLFVBQU0sVUFBVSxDQUFDLFlBQ2YsUUFBUSxlQUNSLFFBQVEsZUFBZSxFQUFFLFNBQVMsS0FDbEMsaUJBQWlCLE9BQU8sRUFBRSxlQUFlO0FBQzNDLFVBQU0sUUFBUSxNQUNaLFVBQ0EsS0FBSyxTQUFTLE9BQU8sT0FBTyxLQUM1QixRQUFRLE9BQU8sT0FBTyxNQUNyQixDQUFDLE9BQU8sU0FDTixPQUFPLE1BQU0sTUFBTSxRQUNsQixPQUFPLE1BQU0sTUFBTSxLQUFLLFNBQVMsT0FBTyxPQUFPLEtBQy9DLFFBQVEsSUFBSSxPQUFPLE9BQU8sTUFBTSxPQUFPO0FBQzdDLFVBQU0sVUFBVSxnQkFBZ0I7QUFBQSxNQUM5QixNQUFNO0FBQUEsTUFDTjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBWTtBQUFBLE1BQ1osTUFBTTtBQUFBLE1BQ04sT0FBTztBQUFBLE1BQ1AsV0FBVztBQUFBLE1BQ1gsUUFBUSxNQUFNO0FBQ1osaUJBQVM7QUFDVCxnQkFBUSxjQUFjO0FBQUEsTUFDeEI7QUFBQSxJQUNGLENBQUM7QUFDRCxhQUFTLEtBQUssTUFBTSxRQUFRLFFBQVEsQ0FBQztBQUNyQyxZQUFRLFFBQVEsVUFBVSxJQUFJLGlCQUFpQixxQkFBcUI7QUFDcEUsVUFBTSxRQUFRLE1BQU07QUFDbEIsZUFBUztBQUNULGNBQVEsY0FBYztBQUN0QixVQUFJO0FBQ0YsZ0JBQVEsTUFBTSxLQUFLO0FBQUEsTUFDckIsUUFBUTtBQUFBLE1BRVI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxjQUFjLENBQUMsWUFBcUI7QUFDeEMsVUFDRSxXQUNDLFlBQVksT0FBTyxXQUFXLFFBQVEsU0FBUyxPQUFPLE9BQU87QUFFOUQsY0FBTTtBQUFBLElBQ1Y7QUFDQSxrQkFBYyxJQUFJLFdBQVc7QUFDN0IsYUFBUyxLQUFLLE1BQU0sY0FBYyxPQUFPLFdBQVcsQ0FBQztBQUNyRCxVQUFNLFVBQVUsQ0FBQyxXQUFvQjtBQUNuQyxVQUFJLFFBQW1EO0FBQ3ZELGVBQ00sSUFBb0IsUUFDeEIsS0FBSyxLQUFLLFNBQVMsQ0FBQyxHQUNwQixJQUFJLEVBQUUsZUFDTjtBQUNBLGNBQU0sUUFBUSxRQUFRLElBQUksQ0FBQztBQUMzQixZQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sTUFBTSxRQUFRLENBQUMsTUFBTSxNQUFNLEtBQUssU0FBUyxDQUFDO0FBQzdEO0FBQ0YsWUFBSSxNQUFNLE1BQU0sTUFBTSxRQUFRLEVBQUUsYUFBYSxrQkFBa0I7QUFDN0Qsb0JBQVUsRUFBRSxTQUFTLEdBQUcsTUFBTTtBQUFBLFlBQzNCLFFBQU8sRUFBRSxTQUFTLEdBQUcsTUFBTTtBQUFBLE1BQ2xDO0FBQ0EsWUFBTSxVQUFVLE9BQU8sUUFBUSx3Q0FBd0M7QUFDdkUsYUFBTyxXQUFXLEtBQUssU0FBUyxPQUFPLElBQ25DLEVBQUUsU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUNoQztBQUFBLElBQ047QUFDQSxVQUFNLFdBQVcsQ0FBQyxhQUFpQztBQUFBLE1BQ2pELE1BQU07QUFBQSxNQUNOLE1BQ0UsUUFBUSxhQUFhLFlBQVksS0FDakMsUUFBUSxhQUFhLE9BQU8sS0FDNUIsUUFBUSxhQUFhLEtBQUssRUFBRSxNQUFNLEdBQUcsR0FBRyxLQUN4QyxRQUFRO0FBQUEsTUFDVixVQUFVLFFBQVEsTUFBTTtBQUFBLE1BQ3hCLE9BQVEsUUFBOEIsV0FDbEMsdUJBQ0E7QUFBQSxNQUNKLE1BQU07QUFBQSxRQUNKLFdBQVc7QUFBQSxRQUNYLE1BQU0sUUFBUSxhQUFhLE1BQU0sS0FBSyxRQUFRLFFBQVEsWUFBWTtBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUVBLFdBQU8sTUFBTSxXQUFXLENBQUMsVUFBVTtBQUNqQyxZQUFNLElBQUk7QUFDVixVQUNFLFlBQ0EsRUFBRSxRQUFRLFFBQ1YsRUFBRSxlQUNGLEVBQUUsVUFDRixFQUFFLG9CQUNGLFFBQVEsUUFBUTtBQUVoQjtBQUNGLFlBQU0sVUFBVSxTQUFTO0FBQ3pCLFVBQ0UsRUFBRSxtQkFBbUIsWUFDckIsQ0FBQyxLQUFLLFNBQVMsT0FBTyxLQUN0QixRQUFRLFFBQVEsc0JBQXNCO0FBRXRDO0FBQ0YsVUFBSTtBQUNGLFlBQUksS0FBSyxFQUFHO0FBQ1osbUJBQVcsU0FBUyxRQUFRO0FBQzFCLGNBQUksQ0FBQyxNQUFNLFFBQVEsQ0FBQyxLQUFLLFNBQVMsTUFBTSxJQUFJLEtBQUssQ0FBQyxRQUFRLE1BQU0sSUFBSTtBQUNsRTtBQUNGLGdCQUFNLFNBQVMsTUFBTSxRQUFRO0FBQzdCLGNBQUksVUFBVSxPQUFPLFNBQVMsUUFBUztBQUFBLFFBQ3pDO0FBQ0EsY0FBTSxTQUFTLFFBQVEsT0FBTztBQUM5QixZQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsT0FBTyxPQUFPLEVBQUc7QUFDekMsaUJBQVM7QUFDVCxZQUFJO0FBQ0osWUFBSTtBQUNGLGlCQUFPLE9BQU8sUUFBUSxPQUFPLE1BQU0sS0FBSyxJQUFJLFNBQVMsT0FBTyxPQUFPO0FBQUEsUUFDckUsUUFBUTtBQUNOLGlCQUFPO0FBQUEsWUFDTCxNQUFNO0FBQUEsWUFDTixNQUFNO0FBQUEsWUFDTixVQUFVO0FBQUEsWUFDVixPQUFPO0FBQUEsWUFDUCxNQUFNLEVBQUUsUUFBUSx5QkFBeUI7QUFBQSxVQUMzQztBQUFBLFFBQ0Y7QUFFQSxZQUFJLENBQUMsTUFBTSxHQUFHO0FBQ1osZ0JBQU07QUFDTjtBQUFBLFFBQ0Y7QUFDQSxnQkFBUSxjQUNOLEtBQUssT0FDTCxPQUNBLEtBQUssT0FDTCxpQkFDQSxLQUFLLFdBQ0wsY0FDQSxLQUFLLFFBQ0wsVUFDQyxLQUFLLFNBQVMsU0FDWCxRQUNBLEtBQUssVUFBVSxLQUFLLE1BQU0sTUFBTSxDQUFDO0FBQ3ZDLFlBQUksQ0FBQyxNQUFNLEtBQUssVUFBVTtBQUN4QixnQkFBTTtBQUNOO0FBQUEsUUFDRjtBQUNBLFlBQUksUUFBUSxLQUFLLEVBQUcsR0FBRSxlQUFlO0FBQUEsTUFDdkMsUUFBUTtBQUNOLGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRixDQUFDO0FBQ0QsV0FBTyxNQUFNLFNBQVMsTUFBTSxNQUFNLENBQUM7QUFDbkMsV0FBTyxNQUFNLG9CQUFvQixNQUFNLE1BQU0sQ0FBQztBQUM5QztBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQSxDQUFDLE1BQU07QUFDTCxZQUFJLENBQUUsRUFBRSxRQUFvQixRQUFRLHNCQUFzQixFQUFHLE9BQU07QUFBQSxNQUNyRTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxRQUFRLFFBQVEsTUFBTSxNQUFNLENBQUM7QUFDcEMsV0FBTyxVQUFVLG9CQUFvQixNQUFNO0FBQ3pDLFVBQUksU0FBUyxPQUFRLE9BQU07QUFBQSxJQUM3QixDQUFDO0FBQ0QsVUFBTSxXQUFXLElBQUksaUJBQWlCLE1BQU07QUFDMUMsVUFBSSxVQUFVLENBQUMsTUFBTSxFQUFHLE9BQU07QUFBQSxJQUNoQyxDQUFDO0FBQ0QsYUFBUyxRQUFRLE1BQU07QUFBQSxNQUNyQixXQUFXO0FBQUEsTUFDWCxTQUFTO0FBQUEsTUFDVCxZQUFZO0FBQUEsTUFDWixpQkFBaUIsQ0FBQyxVQUFVLFNBQVMsT0FBTztBQUFBLElBQzlDLENBQUM7QUFDRCxhQUFTLEtBQUssTUFBTSxTQUFTLFdBQVcsQ0FBQztBQUN6QyxXQUFPO0FBQUEsTUFDTCxZQUFZO0FBQUEsTUFDWixTQUFTLE1BQU07QUFDYixZQUFJLFNBQVU7QUFDZCxtQkFBVztBQUNYLGNBQU07QUFDTixnQkFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsRUFDRixRQUFRO0FBQ04sWUFBUTtBQUNSLFdBQU8sRUFBRSxZQUFZLE1BQU07QUFBQSxJQUFDLEdBQUcsU0FBUyxNQUFNO0FBQUEsSUFBQyxFQUFFO0FBQUEsRUFDbkQ7QUFDRjsiLCJuYW1lcyI6WyJ0YXJnZXQiXX0=