import { zeroOutputModule, zeroGraphKinds, zeroImageKind, zeroSources, zeroOutputText } from "/src/modules/image-zero.ts";
import { floatingSurface } from "/src/ui/floating.ts";
import { mountBuildInfo } from "/apps/web/build-info.ts";
import { icon } from "/src/features/node-browser.ts";
import { mountHover } from "/src/ui/hover.ts";
import { currentSources } from "/src/modules/sources-current.ts";
import {
  fixedValues,
  FIXED_VALUES_PIN
} from "/src/modules/fixed-values.ts";
import { vectorWidget } from "/src/features/vector-control.ts";
import { browserIdentity } from "/src/adapters/browser/identity.ts";
import { functionNetworks } from "/src/modules/function-networks.ts";
import {
  functionOperations,
  functionProfile
} from "/src/modules/function-operations.ts";
import { networkModule } from "/src/modules/networks.ts";
import { probeDefinitions } from "/src/modules/package-probe.ts";
import { extentModule } from "/src/modules/extents.ts";
import { BrowserLibraryStore } from "/src/adapters/browser/library.ts";
import { PersonalLibrary } from "/src/application/personal.ts";
import { mountPersonal } from "/apps/web/personal.ts";
import {
  currentOutputModule,
  currentGraphKinds,
  currentImageKind,
  currentOutputText
} from "/src/modules/image-current.ts";
import { shellText, shellPresentation, shellDefaults } from "/apps/web/shell-copy.ts";
import { Definitions } from "/src/definitions/registry.ts";
import { basicNodes, nodeText } from "/src/modules/nodes.ts";
import {
  graphKinds,
  imageKind,
  stages,
  esProfile
} from "/src/modules/image.ts";
import { EditorApplication } from "/src/application/editor.ts";
import { decodeInput } from "/src/persistence/png.ts";
import { renderDocumentPNG } from "/src/adapters/browser/png.ts";
import {
  BrowserStorage,
  browserOutput,
  downloadBytes
} from "/src/adapters/browser/storage.ts";
import { browserFeedback } from "/src/adapters/browser/presentation.ts";
import { Localization } from "/src/localization/service.ts";
import { Workspace } from "/src/ui/workspace.ts";
import { PanelRenderer } from "/src/ui/mount.ts";
import { WidgetRegistry } from "/src/ui/widgets.ts";
import {
  canvasType,
  canvasCommands,
  canvasText
} from "/src/features/canvas.ts";
import { inspectorType, inspectorText } from "/src/features/inspector.ts";
import { actionsType, actionsText } from "/src/features/actions.ts";
import { codeType, codeText } from "/src/features/code.ts";
import {
  jsonWidget,
  numberWidget,
  choiceWidget,
  controlsText
} from "/src/features/controls.ts";
const definitions = new Definitions();
stages.forEach((s) => definitions.registerStage(s));
definitions.register(basicNodes);
definitions.register(fixedValues);
definitions.register(networkModule);
definitions.register(extentModule);
definitions.register(currentSources);
definitions.register(functionNetworks);
definitions.register(functionOperations);
definitions.register(graphKinds);
definitions.registerKind(imageKind);
definitions.register(currentOutputModule);
definitions.register(currentGraphKinds);
definitions.registerKind(currentImageKind);
definitions.register(zeroOutputModule);
definitions.register(zeroGraphKinds);
definitions.registerKind(zeroImageKind);
definitions.register(zeroSources);
const locale = new Localization();
locale.registerModule(shellPresentation, shellDefaults);
for (const contribution of [
  nodeText,
  currentOutputText,
  zeroOutputText,
  canvasText,
  inspectorText,
  actionsText,
  codeText,
  controlsText
])
  locale.registerModule(contribution.presentation, contribution.defaults);
const text = (key, params) => locale.resolve(shellText(key, params)).text;
const feedback = browserFeedback(locale);
const widgets = new WidgetRegistry(feedback);
widgets.register(jsonWidget, (p) => p.spec.type === "json");
widgets.register(numberWidget, (p) => p.spec.type === "number");
widgets.register(choiceWidget, (p) => p.spec.type === "choice");
widgets.register(
  vectorWidget,
  (p) => p.spec.presentation.widget === "grape.widget.vector" && Array.isArray(p.value)
);
const application = new EditorApplication(
  definitions,
  browserIdentity(),
  zeroImageKind.ref,
  functionProfile,
  new BrowserStorage(),
  browserOutput,
  probeDefinitions
);
const app = document.querySelector("#app");
app.innerHTML = '<header><div class="brand"><svg class="grape-mark" viewBox="0 0 64 64" width="28" height="28" aria-hidden="true"><circle cx="20" cy="23" r="11" fill="#bfa5f4"/><circle cx="44" cy="23" r="11" fill="#a98be2"/><circle cx="32" cy="44" r="11" fill="#b499ef"/></svg> Grape <small>SHADER WORKSPACE</small></div><nav aria-label="Document actions"></nav><div class="status"><span id="save-state"></span><span class="host">Host-free</span></div></header><div id="message" role="status"></div><div id="actions"></div><main><section id="canvases"></section><aside id="inspector"></aside></main><section id="code"></section><footer><span data-hint="connections">Click an output port, then an input to connect. Shift-click replaces a connection.</span><span data-hint="navigation">Scroll to zoom · Drag empty space to pan</span></footer><dialog id="open-dialog"><h2>Open saved document</h2><div id="saved-list"></div><button id="cancel-open">Cancel</button></dialog><dialog id="recovery"><h2>Document retained</h2><p id="recovery-message"></p><button id="export-original">Export original</button><button id="close-recovery">Close</button></dialog>';
const staticText = [
  [".brand small", "subtitle"],
  [".host", "hostFree"],
  ["[data-hint=connections]", "connections"],
  ["[data-hint=navigation]", "navigation"],
  ["#open-dialog h2", "openTitle"],
  ["#cancel-open", "cancel"],
  ["#recovery h2", "recoveryTitle"],
  ["#export-original", "original"],
  ["#close-recovery", "close"]
];
const renderShell = () => {
  for (const [selector, key] of staticText)
    app.querySelector(selector).textContent = text(key);
  app.querySelector("nav").setAttribute("aria-label", text("documentActions"));
};
renderShell();
locale.subscribe(renderShell);
mountBuildInfo(app.querySelector(".brand"));
const oldMessage = document.querySelector("#message"), message = document.createElement("button"), statusBar = document.createElement("div"), nav = app.querySelector("nav"), saveState = document.querySelector("#save-state");
message.id = "message";
message.type = "button";
message.ariaLabel = "Read full application status";
message.setAttribute("aria-haspopup", "dialog");
statusBar.className = "application-status";
statusBar.setAttribute("role", "status");
oldMessage.replaceWith(statusBar);
statusBar.append(message);
app.querySelector("footer").append(statusBar);
const statusText = document.createElement("div");
statusText.className = "status-details-text";
statusText.tabIndex = 0;
statusText.setAttribute("role", "region");
statusText.ariaLabel = "Full current application status";
const statusView = floatingSurface({
  host: app,
  trigger: message,
  content: statusText,
  title: "Application status details",
  closeLabel: "Close status details",
  kind: "anchored",
  width: 680,
  maxHeight: 420,
  beforeOpen: () => !!message.textContent,
  fallbackFocus: () => nav.querySelector("button:not(:disabled)")
});
const closeStatus = () => statusView.close();
message.onclick = () => {
  statusText.textContent = message.textContent;
  statusView.toggle();
};
const setMessage = (text2) => {
  message.textContent = text2;
  message.disabled = !text2;
  statusText.textContent = text2;
  if (!text2) closeStatus();
};
setMessage("");
const errors = /* @__PURE__ */ new Map();
const success = (text2) => {
  if (!errors.size) setMessage(text2);
};
const renderErrors = () => {
  setMessage([...errors.values()].join(" · "));
  message.classList.toggle("error", !!errors.size);
  statusBar.setAttribute("role", errors.size ? "alert" : "status");
};
const report = (error, key = "operation") => {
  errors.set(key, error instanceof Error ? error.message : String(error));
  renderErrors();
};
const action = (key, fn) => {
  const button = document.createElement("button");
  button.dataset.action = key;
  const symbol = {
    new: "add",
    save: "save",
    open: "folder",
    file: "folder",
    export: "download",
    png: "image",
    generate: "code",
    second: "panels",
    lock: "lock"
  };
  const renderAction = () => button.replaceChildren(
    icon(symbol[key] ?? "folder"),
    document.createTextNode(text(key))
  );
  renderAction();
  locale.subscribe(renderAction);
  button.addEventListener("click", () => {
    try {
      Promise.resolve(fn()).then(() => {
        if (errors.delete(key)) renderErrors();
      }).catch((error) => report(error, key));
    } catch (error) {
      report(error, key);
    }
  });
  nav.append(button);
  return button;
};
let workspace = null, renderer = null, canvasCount = 0;
const footer = app.querySelector("footer");
const outputTrigger = document.createElement("button"), output = app.querySelector("#code");
outputTrigger.type = "button";
outputTrigger.textContent = "Shader output";
footer.append(outputTrigger);
output.tabIndex = 0;
const outputView = floatingSurface({
  host: app,
  trigger: outputTrigger,
  content: output,
  title: "Shader output and diagnostics",
  closeLabel: "Close shader output",
  kind: "anchored",
  width: 860,
  maxHeight: 550,
  align: "end",
  dismissOutside: false
});
outputTrigger.onclick = () => outputView.toggle();
const hover = mountHover(app, () => application.busy || application.saving);
function buildWorkspace() {
  hover.invalidate();
  renderer?.dispose();
  workspace?.dispose();
  document.querySelector("#canvases").replaceChildren();
  document.querySelector("#inspector").replaceChildren();
  document.querySelector("#code").replaceChildren();
  document.querySelector("#actions").replaceChildren();
  workspace = new Workspace(application);
  workspace.register(canvasType);
  workspace.register(inspectorType(widgets, locale));
  workspace.register(
    actionsType(
      application.catalog().map(
        (item) => item.ref.moduleId === FIXED_VALUES_PIN.moduleId && item.ref.typeId === "float" ? {
          ...item,
          presentation: {
            ...item.presentation,
            label: {
              ...item.presentation.label,
              key: "float.authoring",
              fallback: "Float (fixed)"
            }
          }
        } : item
      ),
      () => ({
        undo: application.canUndo,
        redo: application.canRedo,
        editing: !application.readonly && !application.busy
      })
    )
  );
  workspace.register(
    codeType(() => ({
      compilation: application.compilation,
      snapshot: application.snapshot
    }))
  );
  canvasCount = 0;
  workspace.open({
    id: "actions",
    typeId: "grape.panel.actions",
    viewStateVersion: 1,
    state: {},
    paneId: "actions",
    hidden: false
  });
  workspace.open({
    id: "inspector",
    typeId: "grape.panel.inspector",
    viewStateVersion: 1,
    state: {},
    paneId: "inspector",
    hidden: false
  });
  workspace.open({
    id: "code",
    typeId: "grape.panel.code",
    viewStateVersion: 1,
    state: {},
    paneId: "code",
    hidden: false
  });
  addCanvas();
  renderer = new PanelRenderer(
    workspace,
    locale,
    (pane, id) => ({
      protocol: "grape.dom.v1",
      target: document.getElementById(pane)
    }),
    feedback
  );
}
function addCanvas() {
  const context = application.context(), id = "canvas-" + ++canvasCount;
  const container = document.createElement("section");
  container.id = id;
  container.className = "canvas-pane";
  const label = document.createElement("div");
  label.className = "pane-title";
  label.textContent = text("canvas", { number: canvasCount });
  container.append(label);
  document.querySelector("#canvases").append(container);
  workspace.open({
    id,
    typeId: canvasType.typeId,
    viewStateVersion: 1,
    state: {},
    paneId: id,
    hidden: false,
    contextId: context.id
  });
  workspace.activate(id);
}
application.grant(canvasType.typeId, canvasCommands);
application.grant("grape.panel.actions", [
  "grape.node.add",
  "grape.node.delete",
  "grape.undo",
  "grape.redo"
]);
application.grant("grape.panel.inspector", [
  "grape.edge.disconnect",
  "grape.node.rename"
]);
const replacing = () => {
  if (application.busy) throw Error(text("gestureBusy"));
  if (workspace?.records().some((r) => r.instance && !r.instance.canClose()))
    throw Error(text("draftBusy"));
  return !application.dirty || confirm(text("discard"));
};
function prepareReplace() {
  renderer?.dispose();
  renderer = null;
  workspace?.dispose();
  workspace = null;
}
action("new", () => {
  if (!replacing()) return;
  prepareReplace();
  application.newDocument();
  buildWorkspace();
});
const upgradeButton = document.createElement("button");
upgradeButton.textContent = "Upgrade subgraph owners";
upgradeButton.onclick = () => {
  try {
    if (!replacing()) return;
    prepareReplace();
    application.upgradeOwners();
    buildWorkspace();
    setMessage(
      "Subgraph owners upgraded explicitly; existing definitions remain expanded. Save to retain the upgraded document."
    );
  } catch (error) {
    report(error);
  }
};
nav.append(upgradeButton);
const imageUpgrade = document.createElement("button");
imageUpgrade.textContent = "Upgrade Image Output";
imageUpgrade.onclick = () => {
  try {
    if (!replacing()) return;
    prepareReplace();
    application.upgradeGraphKind(zeroImageKind.ref);
    buildWorkspace();
    setMessage("Image Output and compatible image source owners explicitly upgraded to 0.3.0 in a new session. Unconnected color is transparent zero. Save to retain this version.");
  } catch (error) {
    report(error);
  }
};
nav.append(imageUpgrade);
const saveButton = action("save", async () => {
  await application.save();
  success(text("stored"));
});
action("open", async () => {
  const list = document.querySelector("#saved-list");
  list.replaceChildren();
  for (const entry of await application.savedDocuments()) {
    const b = document.createElement("button");
    b.textContent = entry.name;
    b.dataset.documentKey = entry.key;
    b.onclick = () => {
      void (async () => {
        if (!replacing()) return;
        const result = await application.reopen(entry.key);
        if (result.status === "editable") {
          buildWorkspace();
          document.querySelector("#open-dialog").close();
        } else recovery(result.raw, result.reason);
      })().catch(report);
    };
    list.append(b);
  }
  if (!list.childNodes.length) list.textContent = text("noDocuments");
  document.querySelector("#open-dialog").showModal();
});
action("export", async () => {
  await application.download();
  success(text("exported"));
});
const pngDialog = document.createElement("dialog");
const pngTitle = document.createElement("h2"), pngImage = document.createElement("img"), pngDownload = document.createElement("button"), pngClose = document.createElement("button");
pngTitle.textContent = text("pngTitle");
pngDownload.textContent = text("pngDownload");
pngClose.textContent = text("cancel");
pngDialog.style.width = "min(1100px, 90vw)";
pngImage.alt = text("pngTitle");
pngImage.style.maxWidth = "100%";
pngImage.style.maxHeight = "65vh";
pngImage.style.display = "block";
pngImage.style.margin = "0 auto 16px";
pngDialog.append(pngTitle, pngImage, pngDownload, pngClose);
app.append(pngDialog);
let pngTicket = 0, pngURL = "", pngBytes = null, pngName = "";
const cancelPNG = () => {
  pngTicket++;
  pngBytes = null;
  if (pngURL) URL.revokeObjectURL(pngURL);
  pngURL = "";
  pngImage.removeAttribute("src");
  pngDialog.close();
};
pngClose.onclick = cancelPNG;
pngDialog.addEventListener("cancel", (event) => {
  event.preventDefault();
  cancelPNG();
});
pngDownload.onclick = () => {
  if (pngBytes)
    void downloadBytes(pngName, pngBytes.slice().buffer).catch(report);
};
action("png", async () => {
  cancelPNG();
  const ticket = pngTicket, snapshot = application.snapshot;
  const pane = document.querySelector(".canvas-pane");
  const layout = /* @__PURE__ */ new Map();
  pane?.querySelectorAll(".node[data-node]").forEach(
    (node) => layout.set(node.dataset.node, {
      width: node.offsetWidth,
      height: node.offsetHeight
    })
  );
  const stage = snapshot.document.graph.stages.find(
    (s) => s.network.nodes.some((n) => layout.has(n.id))
  );
  if (!stage) throw Error("PNG_LAYOUT_MISSING");
  pngDownload.disabled = true;
  pngDialog.showModal();
  try {
    const bytes = await renderDocumentPNG(snapshot.document, stage.id, layout);
    if (ticket !== pngTicket) return;
    pngBytes = bytes;
    pngName = `${snapshot.document.graph.name}-${snapshot.document.graph.kind.kindId}-${stage.key}.png`;
    pngURL = URL.createObjectURL(
      new Blob([bytes.slice().buffer], { type: "image/png" })
    );
    pngImage.src = pngURL;
    pngDownload.disabled = false;
  } catch (error) {
    if (ticket === pngTicket) {
      cancelPNG();
      throw error;
    }
  }
});
const input = document.createElement("input");
input.type = "file";
input.setAttribute("aria-label", "Open document file");
input.accept = ".json,.grape.json,.png,application/json,image/png";
input.hidden = true;
app.append(input);
action("file", () => {
  input.click();
});
input.addEventListener("change", () => {
  void (async () => {
    const file = input.files?.[0];
    if (!file) return;
    closeReview();
    const ticket = reviewTicket;
    const base = application.snapshot;
    recovery(file, "READING_INPUT");
    let bytes;
    try {
      bytes = await file.arrayBuffer();
    } catch {
      if (ticket === reviewTicket) recovery(file, "FILE_READ_FAILED");
      input.value = "";
      return;
    }
    if (ticket !== reviewTicket) return;
    if (base.loadId !== application.snapshot.loadId || base.revision !== application.snapshot.revision) {
      recovery(bytes, "OPEN_SUPERSEDED");
      input.value = "";
      return;
    }
    let raw;
    try {
      raw = decodeInput(new Uint8Array(bytes), file.name);
    } catch (error) {
      recovery(bytes, error instanceof Error ? error.message : String(error));
      input.value = "";
      return;
    }
    currentReview = application.inspectText(raw);
    document.querySelector("#recovery h2").textContent = text("reviewTitle");
    recovery(bytes, currentReview.status + ": " + currentReview.reason);
    reviewDetails.textContent = JSON.stringify(
      {
        diagnostics: currentReview.diagnostics,
        repairs: currentReview.repairs,
        provenance: currentReview.provenance,
        unknownPaths: currentReview.read.status === "recovery-readonly" ? currentReview.read.unknownPaths : [],
        candidate: currentReview.candidate
      },
      null,
      2
    );
    rawPreview.textContent = raw.slice(0, 12e3);
    loadButton.hidden = currentReview.read.status !== "editable" || !currentReview.document || currentReview.reason === "NETWORK_SIZE";
    refreshReplacement();
    input.value = "";
  })().catch(report);
});
action("generate", () => {
  const result = application.generate();
  if (result.status !== "success")
    throw Error(
      result.diagnostics.map((d) => d.code + ": " + d.message).join(" · ")
    );
});
action("second", () => {
  addCanvas();
});
const lockButton = action(
  "lock",
  () => application.setReadonly(!application.readonly)
);
lockButton.setAttribute("aria-checked", "false");
let original = "";
let currentReview = null, reviewTicket = 0;
const reviewDialog = document.querySelector("#recovery");
reviewDialog.style.width = "min(900px, 90vw)";
const reviewDetails = document.createElement("pre"), rawPreview = document.createElement("pre"), explanation = document.createElement("p"), replacementMessage = document.createElement("p"), acceptButton = document.createElement("button"), loadButton = document.createElement("button");
reviewDetails.setAttribute("aria-label", text("reviewDetails"));
rawPreview.setAttribute("aria-label", text("originalPreview"));
reviewDetails.style.maxHeight = "30vh";
rawPreview.style.maxHeight = "15vh";
reviewDetails.style.overflow = rawPreview.style.overflow = "auto";
explanation.textContent = text("loadExplanation");
replacementMessage.id = "replacement-message";
replacementMessage.setAttribute("role", "status");
acceptButton.textContent = text("acceptImport");
loadButton.textContent = text("openPreserved");
acceptButton.hidden = loadButton.hidden = true;
reviewDialog.append(
  explanation,
  reviewDetails,
  rawPreview,
  replacementMessage,
  acceptButton,
  loadButton
);
function refreshReplacement() {
  if (!currentReview) {
    replacementMessage.textContent = "";
    return;
  }
  const eligibility = application.replacementEligibility(currentReview);
  acceptButton.hidden = !currentReview.candidate;
  acceptButton.disabled = !eligibility.available;
  const code = eligibility.available ? null : eligibility.code;
  replacementMessage.textContent = !currentReview.candidate ? "" : code === null ? text("replaceReady") : code === "IMPORT_DEFINITIONS" ? text("replaceDefinitions") : code === "IMPORT_STALE" || code === "REVIEW_CLOSED" ? text("replaceStale", { code }) : code === "IMPORT_READONLY" ? text("replaceReadonly") : code === "HISTORY_BUSY" ? text("replaceBusy") : text("replaceUnavailable", { code });
  loadButton.disabled = application.readonly || application.busy || code === "IMPORT_STALE" || code === "REVIEW_CLOSED";
}
function closeReview() {
  reviewTicket++;
  if (currentReview) application.cancelReview(currentReview);
  currentReview = null;
  reviewDetails.textContent = rawPreview.textContent = "";
  replacementMessage.textContent = "";
  acceptButton.hidden = loadButton.hidden = true;
  reviewDialog.close();
  input.value = "";
}
reviewDialog.addEventListener("cancel", (event) => {
  event.preventDefault();
  closeReview();
});
acceptButton.onclick = () => {
  try {
    if (workspace?.records().some((r) => r.instance && !r.instance.canClose()))
      throw Error(text("draftBusy"));
    if (currentReview) application.acceptReview(currentReview);
    closeReview();
  } catch (error) {
    document.querySelector("#recovery-message").textContent = error instanceof Error ? error.message : String(error);
    refreshReplacement();
  }
};
loadButton.onclick = () => {
  try {
    if (!currentReview || !replacing()) return;
    application.openReviewed(currentReview);
    buildWorkspace();
    closeReview();
  } catch (error) {
    document.querySelector("#recovery-message").textContent = error instanceof Error ? error.message : String(error);
  }
};
function recovery(raw, reason) {
  original = raw;
  document.querySelector("#recovery-message").textContent = text("recovery", {
    reason
  });
  if (!reviewDialog.open) reviewDialog.showModal();
}
document.querySelector("#export-original").addEventListener(
  "click",
  () => void downloadBytes("recovery-original.json", original)
);
document.querySelector("#close-recovery").addEventListener("click", closeReview);
document.querySelector("#cancel-open").addEventListener(
  "click",
  () => document.querySelector("#open-dialog").close()
);
application.subscribe(() => {
  hover.invalidate();
  refreshReplacement();
  saveState.textContent = application.saving ? text("saving") : application.dirty ? text("dirty") : text("saved");
  saveButton.disabled = application.saving;
  lockButton.setAttribute("aria-checked", String(application.readonly));
});
application.newDocument();
buildWorkspace();
mountPersonal(
  nav,
  application,
  () => {
    const id = workspace?.records().find((r) => r.saved.id === "inspector")?.update.target?.scope.contextId;
    if (!id) throw Error("Select a Canvas first.");
    return application.context(id);
  },
  new PersonalLibrary(
    new BrowserLibraryStore(),
    definitions.pin(definitions.pins()),
    functionProfile,
    probeDefinitions
  ),
  (error, operation) => {
    const key = "personal:" + operation;
    if (error === void 0) {
      if (errors.delete(key)) renderErrors();
    } else report(error, key);
  }
);
const menuTrigger = document.createElement("button"), menuContent = document.createElement("div"), hintsTrigger = document.createElement("button"), hintsContent = document.createElement("div");
menuTrigger.type = "button";
menuTrigger.textContent = "Project actions";
menuTrigger.className = "project-actions";
menuContent.className = "function-actions";
menuContent.tabIndex = -1;
const documentGroup = document.createElement("div"), workspaceGroup = document.createElement("div");
for (const [group, label] of [
  [documentGroup, "Documents and library"],
  [workspaceGroup, "Workspace"]
]) {
  group.setAttribute("role", "group");
  group.ariaLabel = label;
  menuContent.append(group);
}
for (const child of Array.from(nav.children)) {
  const key = child.dataset.action;
  if (!(child instanceof HTMLButtonElement)) app.append(child);
  else if (key !== "save" && key !== "generate") {
    child.setAttribute(
      "role",
      key === "lock" ? "menuitemcheckbox" : "menuitem"
    );
    (key === "second" || key === "lock" ? workspaceGroup : documentGroup).append(child);
  }
}
footer.prepend(menuTrigger);
const projectMenu = floatingSurface({
  host: app,
  trigger: menuTrigger,
  content: menuContent,
  title: "Project actions",
  closeLabel: "Close project actions",
  kind: "menu",
  width: 310,
  maxHeight: 520
});
menuTrigger.onclick = () => projectMenu.toggle();
menuContent.addEventListener("click", (event) => {
  const action2 = event.target.closest("button")?.dataset.action;
  if (action2 && ["new", "export", "file", "second", "lock"].includes(action2))
    projectMenu.close(false);
});
hintsTrigger.type = "button";
hintsTrigger.textContent = "Hints";
hintsContent.tabIndex = 0;
for (const hint of Array.from(footer.querySelectorAll(":scope > span")))
  hintsContent.append(hint);
const inspectHint = document.createElement("span");
inspectHint.textContent = "F2 · Read the focused object information (read-only). Close or Escape returns focus.";
hintsContent.append(inspectHint);
footer.append(hintsTrigger);
const hintsView = floatingSurface({
  host: app,
  trigger: hintsTrigger,
  content: hintsContent,
  title: "Workspace hints",
  closeLabel: "Close hints",
  kind: "anchored",
  width: 370,
  maxHeight: 300,
  align: "end"
});
hintsTrigger.onclick = () => hintsView.toggle();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgemVyb091dHB1dE1vZHVsZSwgemVyb0dyYXBoS2luZHMsIHplcm9JbWFnZUtpbmQsIHplcm9Tb3VyY2VzLCB6ZXJvT3V0cHV0VGV4dCB9IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9pbWFnZS16ZXJvLnRzXCI7XG5pbXBvcnQgeyBmbG9hdGluZ1N1cmZhY2UgfSBmcm9tIFwiLi4vLi4vc3JjL3VpL2Zsb2F0aW5nLnRzXCI7XG5pbXBvcnQgeyBtb3VudEJ1aWxkSW5mbyB9IGZyb20gXCIuL2J1aWxkLWluZm8udHNcIjtcbmltcG9ydCB7IGljb24gfSBmcm9tIFwiLi4vLi4vc3JjL2ZlYXR1cmVzL25vZGUtYnJvd3Nlci50c1wiO1xuaW1wb3J0IHsgbW91bnRIb3ZlciB9IGZyb20gXCIuLi8uLi9zcmMvdWkvaG92ZXIudHNcIjtcbmltcG9ydCB7IGN1cnJlbnRTb3VyY2VzIH0gZnJvbSBcIi4uLy4uL3NyYy9tb2R1bGVzL3NvdXJjZXMtY3VycmVudC50c1wiO1xuaW1wb3J0IHtcbiAgZml4ZWRWYWx1ZXMsXG4gIEZJWEVEX1ZBTFVFU19QSU4sXG59IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9maXhlZC12YWx1ZXMudHNcIjtcbmltcG9ydCB7IHZlY3RvcldpZGdldCB9IGZyb20gXCIuLi8uLi9zcmMvZmVhdHVyZXMvdmVjdG9yLWNvbnRyb2wudHNcIjtcbmltcG9ydCB7IGJyb3dzZXJJZGVudGl0eSB9IGZyb20gXCIuLi8uLi9zcmMvYWRhcHRlcnMvYnJvd3Nlci9pZGVudGl0eS50c1wiO1xuaW1wb3J0IHsgZnVuY3Rpb25OZXR3b3JrcyB9IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9mdW5jdGlvbi1uZXR3b3Jrcy50c1wiO1xuaW1wb3J0IHtcbiAgZnVuY3Rpb25PcGVyYXRpb25zLFxuICBmdW5jdGlvblByb2ZpbGUsXG59IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9mdW5jdGlvbi1vcGVyYXRpb25zLnRzXCI7XG5pbXBvcnQgeyBuZXR3b3JrTW9kdWxlIH0gZnJvbSBcIi4uLy4uL3NyYy9tb2R1bGVzL25ldHdvcmtzLnRzXCI7XG5pbXBvcnQgeyBwcm9iZURlZmluaXRpb25zIH0gZnJvbSBcIi4uLy4uL3NyYy9tb2R1bGVzL3BhY2thZ2UtcHJvYmUudHNcIjtcbmltcG9ydCB7IGV4dGVudE1vZHVsZSB9IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9leHRlbnRzLnRzXCI7XG5pbXBvcnQgeyBCcm93c2VyTGlicmFyeVN0b3JlIH0gZnJvbSBcIi4uLy4uL3NyYy9hZGFwdGVycy9icm93c2VyL2xpYnJhcnkudHNcIjtcbmltcG9ydCB7IFBlcnNvbmFsTGlicmFyeSB9IGZyb20gXCIuLi8uLi9zcmMvYXBwbGljYXRpb24vcGVyc29uYWwudHNcIjtcbmltcG9ydCB7IG1vdW50UGVyc29uYWwgfSBmcm9tIFwiLi9wZXJzb25hbC50c1wiO1xuaW1wb3J0IHtcbiAgY3VycmVudE91dHB1dE1vZHVsZSxcbiAgY3VycmVudEdyYXBoS2luZHMsXG4gIGN1cnJlbnRJbWFnZUtpbmQsXG4gIGN1cnJlbnRPdXRwdXRUZXh0LFxufSBmcm9tIFwiLi4vLi4vc3JjL21vZHVsZXMvaW1hZ2UtY3VycmVudC50c1wiO1xuaW1wb3J0IHsgc2hlbGxUZXh0LCBzaGVsbFByZXNlbnRhdGlvbiwgc2hlbGxEZWZhdWx0cyB9IGZyb20gXCIuL3NoZWxsLWNvcHkudHNcIjtcbmltcG9ydCB7IERlZmluaXRpb25zIH0gZnJvbSBcIi4uLy4uL3NyYy9kZWZpbml0aW9ucy9yZWdpc3RyeS50c1wiO1xuaW1wb3J0IHsgYmFzaWNOb2Rlcywgbm9kZVRleHQgfSBmcm9tIFwiLi4vLi4vc3JjL21vZHVsZXMvbm9kZXMudHNcIjtcbmltcG9ydCB7XG4gIGdyYXBoS2luZHMsXG4gIGltYWdlS2luZCxcbiAgc3RhZ2VzLFxuICBlc1Byb2ZpbGUsXG59IGZyb20gXCIuLi8uLi9zcmMvbW9kdWxlcy9pbWFnZS50c1wiO1xuaW1wb3J0IHsgRWRpdG9yQXBwbGljYXRpb24gfSBmcm9tIFwiLi4vLi4vc3JjL2FwcGxpY2F0aW9uL2VkaXRvci50c1wiO1xuaW1wb3J0IHR5cGUgeyBEb2N1bWVudEluc3BlY3Rpb24gfSBmcm9tIFwiLi4vLi4vc3JjL2FwcGxpY2F0aW9uL2luc3BlY3Rpb24udHNcIjtcbmltcG9ydCB7IGRlY29kZUlucHV0IH0gZnJvbSBcIi4uLy4uL3NyYy9wZXJzaXN0ZW5jZS9wbmcudHNcIjtcbmltcG9ydCB7IHJlbmRlckRvY3VtZW50UE5HIH0gZnJvbSBcIi4uLy4uL3NyYy9hZGFwdGVycy9icm93c2VyL3BuZy50c1wiO1xuaW1wb3J0IHtcbiAgQnJvd3NlclN0b3JhZ2UsXG4gIGJyb3dzZXJPdXRwdXQsXG4gIGRvd25sb2FkQnl0ZXMsXG59IGZyb20gXCIuLi8uLi9zcmMvYWRhcHRlcnMvYnJvd3Nlci9zdG9yYWdlLnRzXCI7XG5pbXBvcnQgeyBicm93c2VyRmVlZGJhY2sgfSBmcm9tIFwiLi4vLi4vc3JjL2FkYXB0ZXJzL2Jyb3dzZXIvcHJlc2VudGF0aW9uLnRzXCI7XG5pbXBvcnQgeyBMb2NhbGl6YXRpb24gfSBmcm9tIFwiLi4vLi4vc3JjL2xvY2FsaXphdGlvbi9zZXJ2aWNlLnRzXCI7XG5pbXBvcnQgeyBXb3Jrc3BhY2UgfSBmcm9tIFwiLi4vLi4vc3JjL3VpL3dvcmtzcGFjZS50c1wiO1xuaW1wb3J0IHsgUGFuZWxSZW5kZXJlciB9IGZyb20gXCIuLi8uLi9zcmMvdWkvbW91bnQudHNcIjtcbmltcG9ydCB7IFdpZGdldFJlZ2lzdHJ5IH0gZnJvbSBcIi4uLy4uL3NyYy91aS93aWRnZXRzLnRzXCI7XG5pbXBvcnQge1xuICBjYW52YXNUeXBlLFxuICBjYW52YXNDb21tYW5kcyxcbiAgY2FudmFzVGV4dCxcbn0gZnJvbSBcIi4uLy4uL3NyYy9mZWF0dXJlcy9jYW52YXMudHNcIjtcbmltcG9ydCB7IGluc3BlY3RvclR5cGUsIGluc3BlY3RvclRleHQgfSBmcm9tIFwiLi4vLi4vc3JjL2ZlYXR1cmVzL2luc3BlY3Rvci50c1wiO1xuaW1wb3J0IHsgYWN0aW9uc1R5cGUsIGFjdGlvbnNUZXh0IH0gZnJvbSBcIi4uLy4uL3NyYy9mZWF0dXJlcy9hY3Rpb25zLnRzXCI7XG5pbXBvcnQgeyBjb2RlVHlwZSwgY29kZVRleHQgfSBmcm9tIFwiLi4vLi4vc3JjL2ZlYXR1cmVzL2NvZGUudHNcIjtcbmltcG9ydCB7XG4gIGpzb25XaWRnZXQsXG4gIG51bWJlcldpZGdldCxcbiAgY2hvaWNlV2lkZ2V0LFxuICBjb250cm9sc1RleHQsXG59IGZyb20gXCIuLi8uLi9zcmMvZmVhdHVyZXMvY29udHJvbHMudHNcIjtcblxuY29uc3QgZGVmaW5pdGlvbnMgPSBuZXcgRGVmaW5pdGlvbnMoKTtcbnN0YWdlcy5mb3JFYWNoKChzKSA9PiBkZWZpbml0aW9ucy5yZWdpc3RlclN0YWdlKHMpKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyKGJhc2ljTm9kZXMpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIoZml4ZWRWYWx1ZXMpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIobmV0d29ya01vZHVsZSk7XG5kZWZpbml0aW9ucy5yZWdpc3RlcihleHRlbnRNb2R1bGUpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIoY3VycmVudFNvdXJjZXMpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIoZnVuY3Rpb25OZXR3b3Jrcyk7XG5kZWZpbml0aW9ucy5yZWdpc3RlcihmdW5jdGlvbk9wZXJhdGlvbnMpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIoZ3JhcGhLaW5kcyk7XG5kZWZpbml0aW9ucy5yZWdpc3RlcktpbmQoaW1hZ2VLaW5kKTtcbmRlZmluaXRpb25zLnJlZ2lzdGVyKGN1cnJlbnRPdXRwdXRNb2R1bGUpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIoY3VycmVudEdyYXBoS2luZHMpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXJLaW5kKGN1cnJlbnRJbWFnZUtpbmQpO1xuZGVmaW5pdGlvbnMucmVnaXN0ZXIoemVyb091dHB1dE1vZHVsZSk7XG5kZWZpbml0aW9ucy5yZWdpc3Rlcih6ZXJvR3JhcGhLaW5kcyk7XG5kZWZpbml0aW9ucy5yZWdpc3RlcktpbmQoemVyb0ltYWdlS2luZCk7XG5kZWZpbml0aW9ucy5yZWdpc3Rlcih6ZXJvU291cmNlcyk7XG5jb25zdCBsb2NhbGUgPSBuZXcgTG9jYWxpemF0aW9uKCk7XG5sb2NhbGUucmVnaXN0ZXJNb2R1bGUoc2hlbGxQcmVzZW50YXRpb24sIHNoZWxsRGVmYXVsdHMpO1xuZm9yIChjb25zdCBjb250cmlidXRpb24gb2YgW1xuICBub2RlVGV4dCxcbiAgY3VycmVudE91dHB1dFRleHQsXG4gIHplcm9PdXRwdXRUZXh0LFxuICBjYW52YXNUZXh0LFxuICBpbnNwZWN0b3JUZXh0LFxuICBhY3Rpb25zVGV4dCxcbiAgY29kZVRleHQsXG4gIGNvbnRyb2xzVGV4dCxcbl0pXG4gIGxvY2FsZS5yZWdpc3Rlck1vZHVsZShjb250cmlidXRpb24ucHJlc2VudGF0aW9uLCBjb250cmlidXRpb24uZGVmYXVsdHMpO1xuY29uc3QgdGV4dCA9IChcbiAga2V5OiBQYXJhbWV0ZXJzPHR5cGVvZiBzaGVsbFRleHQ+WzBdLFxuICBwYXJhbXM/OiBQYXJhbWV0ZXJzPHR5cGVvZiBzaGVsbFRleHQ+WzFdLFxuKSA9PiBsb2NhbGUucmVzb2x2ZShzaGVsbFRleHQoa2V5LCBwYXJhbXMpKS50ZXh0O1xuY29uc3QgZmVlZGJhY2sgPSBicm93c2VyRmVlZGJhY2sobG9jYWxlKTtcbmNvbnN0IHdpZGdldHMgPSBuZXcgV2lkZ2V0UmVnaXN0cnkoZmVlZGJhY2spO1xud2lkZ2V0cy5yZWdpc3Rlcihqc29uV2lkZ2V0LCAocCkgPT4gcC5zcGVjLnR5cGUgPT09IFwianNvblwiKTtcbndpZGdldHMucmVnaXN0ZXIobnVtYmVyV2lkZ2V0LCAocCkgPT4gcC5zcGVjLnR5cGUgPT09IFwibnVtYmVyXCIpO1xud2lkZ2V0cy5yZWdpc3RlcihjaG9pY2VXaWRnZXQsIChwKSA9PiBwLnNwZWMudHlwZSA9PT0gXCJjaG9pY2VcIik7XG53aWRnZXRzLnJlZ2lzdGVyKFxuICB2ZWN0b3JXaWRnZXQsXG4gIChwKSA9PlxuICAgIHAuc3BlYy5wcmVzZW50YXRpb24ud2lkZ2V0ID09PSBcImdyYXBlLndpZGdldC52ZWN0b3JcIiAmJlxuICAgIEFycmF5LmlzQXJyYXkocC52YWx1ZSksXG4pO1xuY29uc3QgYXBwbGljYXRpb24gPSBuZXcgRWRpdG9yQXBwbGljYXRpb24oXG4gIGRlZmluaXRpb25zLFxuICBicm93c2VySWRlbnRpdHkoKSxcbiAgemVyb0ltYWdlS2luZC5yZWYsXG4gIGZ1bmN0aW9uUHJvZmlsZSxcbiAgbmV3IEJyb3dzZXJTdG9yYWdlKCksXG4gIGJyb3dzZXJPdXRwdXQsXG4gIHByb2JlRGVmaW5pdGlvbnMsXG4pO1xuY29uc3QgYXBwID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcjxIVE1MRWxlbWVudD4oXCIjYXBwXCIpITtcbmFwcC5pbm5lckhUTUwgPVxuICAnPGhlYWRlcj48ZGl2IGNsYXNzPVwiYnJhbmRcIj48c3ZnIGNsYXNzPVwiZ3JhcGUtbWFya1wiIHZpZXdCb3g9XCIwIDAgNjQgNjRcIiB3aWR0aD1cIjI4XCIgaGVpZ2h0PVwiMjhcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48Y2lyY2xlIGN4PVwiMjBcIiBjeT1cIjIzXCIgcj1cIjExXCIgZmlsbD1cIiNiZmE1ZjRcIi8+PGNpcmNsZSBjeD1cIjQ0XCIgY3k9XCIyM1wiIHI9XCIxMVwiIGZpbGw9XCIjYTk4YmUyXCIvPjxjaXJjbGUgY3g9XCIzMlwiIGN5PVwiNDRcIiByPVwiMTFcIiBmaWxsPVwiI2I0OTllZlwiLz48L3N2Zz4gR3JhcGUgPHNtYWxsPlNIQURFUiBXT1JLU1BBQ0U8L3NtYWxsPjwvZGl2PjxuYXYgYXJpYS1sYWJlbD1cIkRvY3VtZW50IGFjdGlvbnNcIj48L25hdj48ZGl2IGNsYXNzPVwic3RhdHVzXCI+PHNwYW4gaWQ9XCJzYXZlLXN0YXRlXCI+PC9zcGFuPjxzcGFuIGNsYXNzPVwiaG9zdFwiPkhvc3QtZnJlZTwvc3Bhbj48L2Rpdj48L2hlYWRlcj48ZGl2IGlkPVwibWVzc2FnZVwiIHJvbGU9XCJzdGF0dXNcIj48L2Rpdj48ZGl2IGlkPVwiYWN0aW9uc1wiPjwvZGl2PjxtYWluPjxzZWN0aW9uIGlkPVwiY2FudmFzZXNcIj48L3NlY3Rpb24+PGFzaWRlIGlkPVwiaW5zcGVjdG9yXCI+PC9hc2lkZT48L21haW4+PHNlY3Rpb24gaWQ9XCJjb2RlXCI+PC9zZWN0aW9uPjxmb290ZXI+PHNwYW4gZGF0YS1oaW50PVwiY29ubmVjdGlvbnNcIj5DbGljayBhbiBvdXRwdXQgcG9ydCwgdGhlbiBhbiBpbnB1dCB0byBjb25uZWN0LiBTaGlmdC1jbGljayByZXBsYWNlcyBhIGNvbm5lY3Rpb24uPC9zcGFuPjxzcGFuIGRhdGEtaGludD1cIm5hdmlnYXRpb25cIj5TY3JvbGwgdG8gem9vbSDCtyBEcmFnIGVtcHR5IHNwYWNlIHRvIHBhbjwvc3Bhbj48L2Zvb3Rlcj48ZGlhbG9nIGlkPVwib3Blbi1kaWFsb2dcIj48aDI+T3BlbiBzYXZlZCBkb2N1bWVudDwvaDI+PGRpdiBpZD1cInNhdmVkLWxpc3RcIj48L2Rpdj48YnV0dG9uIGlkPVwiY2FuY2VsLW9wZW5cIj5DYW5jZWw8L2J1dHRvbj48L2RpYWxvZz48ZGlhbG9nIGlkPVwicmVjb3ZlcnlcIj48aDI+RG9jdW1lbnQgcmV0YWluZWQ8L2gyPjxwIGlkPVwicmVjb3ZlcnktbWVzc2FnZVwiPjwvcD48YnV0dG9uIGlkPVwiZXhwb3J0LW9yaWdpbmFsXCI+RXhwb3J0IG9yaWdpbmFsPC9idXR0b24+PGJ1dHRvbiBpZD1cImNsb3NlLXJlY292ZXJ5XCI+Q2xvc2U8L2J1dHRvbj48L2RpYWxvZz4nO1xuY29uc3Qgc3RhdGljVGV4dCA9IFtcbiAgW1wiLmJyYW5kIHNtYWxsXCIsIFwic3VidGl0bGVcIl0sXG4gIFtcIi5ob3N0XCIsIFwiaG9zdEZyZWVcIl0sXG4gIFtcIltkYXRhLWhpbnQ9Y29ubmVjdGlvbnNdXCIsIFwiY29ubmVjdGlvbnNcIl0sXG4gIFtcIltkYXRhLWhpbnQ9bmF2aWdhdGlvbl1cIiwgXCJuYXZpZ2F0aW9uXCJdLFxuICBbXCIjb3Blbi1kaWFsb2cgaDJcIiwgXCJvcGVuVGl0bGVcIl0sXG4gIFtcIiNjYW5jZWwtb3BlblwiLCBcImNhbmNlbFwiXSxcbiAgW1wiI3JlY292ZXJ5IGgyXCIsIFwicmVjb3ZlcnlUaXRsZVwiXSxcbiAgW1wiI2V4cG9ydC1vcmlnaW5hbFwiLCBcIm9yaWdpbmFsXCJdLFxuICBbXCIjY2xvc2UtcmVjb3ZlcnlcIiwgXCJjbG9zZVwiXSxcbl0gYXMgY29uc3Q7XG5jb25zdCByZW5kZXJTaGVsbCA9ICgpID0+IHtcbiAgZm9yIChjb25zdCBbc2VsZWN0b3IsIGtleV0gb2Ygc3RhdGljVGV4dClcbiAgICBhcHAucXVlcnlTZWxlY3RvcihzZWxlY3RvcikhLnRleHRDb250ZW50ID0gdGV4dChrZXkpO1xuICBhcHAucXVlcnlTZWxlY3RvcihcIm5hdlwiKSEuc2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiLCB0ZXh0KFwiZG9jdW1lbnRBY3Rpb25zXCIpKTtcbn07XG5yZW5kZXJTaGVsbCgpO1xubG9jYWxlLnN1YnNjcmliZShyZW5kZXJTaGVsbCk7XG5tb3VudEJ1aWxkSW5mbyhhcHAucXVlcnlTZWxlY3RvcjxIVE1MRWxlbWVudD4oXCIuYnJhbmRcIikhKTtcbmNvbnN0IG9sZE1lc3NhZ2UgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PihcIiNtZXNzYWdlXCIpISxcbiAgbWVzc2FnZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiksXG4gIHN0YXR1c0JhciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksXG4gIG5hdiA9IGFwcC5xdWVyeVNlbGVjdG9yKFwibmF2XCIpISxcbiAgc2F2ZVN0YXRlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcjxIVE1MRWxlbWVudD4oXCIjc2F2ZS1zdGF0ZVwiKSE7XG5tZXNzYWdlLmlkID0gXCJtZXNzYWdlXCI7XG5tZXNzYWdlLnR5cGUgPSBcImJ1dHRvblwiO1xubWVzc2FnZS5hcmlhTGFiZWwgPSBcIlJlYWQgZnVsbCBhcHBsaWNhdGlvbiBzdGF0dXNcIjtcbm1lc3NhZ2Uuc2V0QXR0cmlidXRlKFwiYXJpYS1oYXNwb3B1cFwiLCBcImRpYWxvZ1wiKTtcbnN0YXR1c0Jhci5jbGFzc05hbWUgPSBcImFwcGxpY2F0aW9uLXN0YXR1c1wiO1xuc3RhdHVzQmFyLnNldEF0dHJpYnV0ZShcInJvbGVcIiwgXCJzdGF0dXNcIik7XG5vbGRNZXNzYWdlLnJlcGxhY2VXaXRoKHN0YXR1c0Jhcik7XG5zdGF0dXNCYXIuYXBwZW5kKG1lc3NhZ2UpO1xuYXBwLnF1ZXJ5U2VsZWN0b3IoXCJmb290ZXJcIikhLmFwcGVuZChzdGF0dXNCYXIpO1xuY29uc3Qgc3RhdHVzVGV4dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG5zdGF0dXNUZXh0LmNsYXNzTmFtZSA9IFwic3RhdHVzLWRldGFpbHMtdGV4dFwiO1xuc3RhdHVzVGV4dC50YWJJbmRleCA9IDA7XG5zdGF0dXNUZXh0LnNldEF0dHJpYnV0ZShcInJvbGVcIiwgXCJyZWdpb25cIik7XG5zdGF0dXNUZXh0LmFyaWFMYWJlbCA9IFwiRnVsbCBjdXJyZW50IGFwcGxpY2F0aW9uIHN0YXR1c1wiO1xuY29uc3Qgc3RhdHVzVmlldyA9IGZsb2F0aW5nU3VyZmFjZSh7XG4gIGhvc3Q6IGFwcCxcbiAgdHJpZ2dlcjogbWVzc2FnZSxcbiAgY29udGVudDogc3RhdHVzVGV4dCxcbiAgdGl0bGU6IFwiQXBwbGljYXRpb24gc3RhdHVzIGRldGFpbHNcIixcbiAgY2xvc2VMYWJlbDogXCJDbG9zZSBzdGF0dXMgZGV0YWlsc1wiLFxuICBraW5kOiBcImFuY2hvcmVkXCIsXG4gIHdpZHRoOiA2ODAsXG4gIG1heEhlaWdodDogNDIwLFxuICBiZWZvcmVPcGVuOiAoKSA9PiAhIW1lc3NhZ2UudGV4dENvbnRlbnQsXG4gIGZhbGxiYWNrRm9jdXM6ICgpID0+XG4gICAgbmF2LnF1ZXJ5U2VsZWN0b3I8SFRNTEJ1dHRvbkVsZW1lbnQ+KFwiYnV0dG9uOm5vdCg6ZGlzYWJsZWQpXCIpLFxufSk7XG5jb25zdCBjbG9zZVN0YXR1cyA9ICgpID0+IHN0YXR1c1ZpZXcuY2xvc2UoKTtcbm1lc3NhZ2Uub25jbGljayA9ICgpID0+IHtcbiAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9IG1lc3NhZ2UudGV4dENvbnRlbnQ7XG4gIHN0YXR1c1ZpZXcudG9nZ2xlKCk7XG59O1xuY29uc3Qgc2V0TWVzc2FnZSA9ICh0ZXh0OiBzdHJpbmcpID0+IHtcbiAgbWVzc2FnZS50ZXh0Q29udGVudCA9IHRleHQ7XG4gIG1lc3NhZ2UuZGlzYWJsZWQgPSAhdGV4dDtcbiAgc3RhdHVzVGV4dC50ZXh0Q29udGVudCA9IHRleHQ7XG4gIGlmICghdGV4dCkgY2xvc2VTdGF0dXMoKTtcbn07XG5zZXRNZXNzYWdlKFwiXCIpO1xuY29uc3QgZXJyb3JzID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcbmNvbnN0IHN1Y2Nlc3MgPSAodGV4dDogc3RyaW5nKSA9PiB7XG4gIGlmICghZXJyb3JzLnNpemUpIHNldE1lc3NhZ2UodGV4dCk7XG59O1xuY29uc3QgcmVuZGVyRXJyb3JzID0gKCkgPT4ge1xuICBzZXRNZXNzYWdlKFsuLi5lcnJvcnMudmFsdWVzKCldLmpvaW4oXCIgwrcgXCIpKTtcbiAgbWVzc2FnZS5jbGFzc0xpc3QudG9nZ2xlKFwiZXJyb3JcIiwgISFlcnJvcnMuc2l6ZSk7XG4gIHN0YXR1c0Jhci5zZXRBdHRyaWJ1dGUoXCJyb2xlXCIsIGVycm9ycy5zaXplID8gXCJhbGVydFwiIDogXCJzdGF0dXNcIik7XG59O1xuY29uc3QgcmVwb3J0ID0gKGVycm9yOiB1bmtub3duLCBrZXkgPSBcIm9wZXJhdGlvblwiKSA9PiB7XG4gIGVycm9ycy5zZXQoa2V5LCBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcikpO1xuICByZW5kZXJFcnJvcnMoKTtcbn07XG5jb25zdCBhY3Rpb24gPSAoXG4gIGtleTogUGFyYW1ldGVyczx0eXBlb2Ygc2hlbGxUZXh0PlswXSxcbiAgZm46ICgpID0+IHZvaWQgfCBQcm9taXNlPHZvaWQ+LFxuKSA9PiB7XG4gIGNvbnN0IGJ1dHRvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIik7XG4gIGJ1dHRvbi5kYXRhc2V0LmFjdGlvbiA9IGtleTtcbiAgY29uc3Qgc3ltYm9sOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgIG5ldzogXCJhZGRcIixcbiAgICBzYXZlOiBcInNhdmVcIixcbiAgICBvcGVuOiBcImZvbGRlclwiLFxuICAgIGZpbGU6IFwiZm9sZGVyXCIsXG4gICAgZXhwb3J0OiBcImRvd25sb2FkXCIsXG4gICAgcG5nOiBcImltYWdlXCIsXG4gICAgZ2VuZXJhdGU6IFwiY29kZVwiLFxuICAgIHNlY29uZDogXCJwYW5lbHNcIixcbiAgICBsb2NrOiBcImxvY2tcIixcbiAgfTtcbiAgY29uc3QgcmVuZGVyQWN0aW9uID0gKCkgPT5cbiAgICBidXR0b24ucmVwbGFjZUNoaWxkcmVuKFxuICAgICAgaWNvbihzeW1ib2xba2V5XSA/PyBcImZvbGRlclwiKSxcbiAgICAgIGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKHRleHQoa2V5KSksXG4gICAgKTtcbiAgcmVuZGVyQWN0aW9uKCk7XG4gIGxvY2FsZS5zdWJzY3JpYmUocmVuZGVyQWN0aW9uKTtcbiAgYnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIFByb21pc2UucmVzb2x2ZShmbigpKVxuICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgaWYgKGVycm9ycy5kZWxldGUoa2V5KSkgcmVuZGVyRXJyb3JzKCk7XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHJlcG9ydChlcnJvciwga2V5KSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJlcG9ydChlcnJvciwga2V5KTtcbiAgICB9XG4gIH0pO1xuICBuYXYuYXBwZW5kKGJ1dHRvbik7XG4gIHJldHVybiBidXR0b247XG59O1xubGV0IHdvcmtzcGFjZTogV29ya3NwYWNlIHwgbnVsbCA9IG51bGwsXG4gIHJlbmRlcmVyOiBQYW5lbFJlbmRlcmVyIHwgbnVsbCA9IG51bGwsXG4gIGNhbnZhc0NvdW50ID0gMDtcbmNvbnN0IGZvb3RlciA9IGFwcC5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PihcImZvb3RlclwiKSE7XG5jb25zdCBvdXRwdXRUcmlnZ2VyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKSxcbiAgb3V0cHV0ID0gYXBwLnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KFwiI2NvZGVcIikhO1xub3V0cHV0VHJpZ2dlci50eXBlID0gXCJidXR0b25cIjtcbm91dHB1dFRyaWdnZXIudGV4dENvbnRlbnQgPSBcIlNoYWRlciBvdXRwdXRcIjtcbmZvb3Rlci5hcHBlbmQob3V0cHV0VHJpZ2dlcik7XG5vdXRwdXQudGFiSW5kZXggPSAwO1xuY29uc3Qgb3V0cHV0VmlldyA9IGZsb2F0aW5nU3VyZmFjZSh7XG4gIGhvc3Q6IGFwcCxcbiAgdHJpZ2dlcjogb3V0cHV0VHJpZ2dlcixcbiAgY29udGVudDogb3V0cHV0LFxuICB0aXRsZTogXCJTaGFkZXIgb3V0cHV0IGFuZCBkaWFnbm9zdGljc1wiLFxuICBjbG9zZUxhYmVsOiBcIkNsb3NlIHNoYWRlciBvdXRwdXRcIixcbiAga2luZDogXCJhbmNob3JlZFwiLFxuICB3aWR0aDogODYwLFxuICBtYXhIZWlnaHQ6IDU1MCxcbiAgYWxpZ246IFwiZW5kXCIsXG4gIGRpc21pc3NPdXRzaWRlOiBmYWxzZSxcbn0pO1xub3V0cHV0VHJpZ2dlci5vbmNsaWNrID0gKCkgPT4gb3V0cHV0Vmlldy50b2dnbGUoKTtcbmNvbnN0IGhvdmVyID0gbW91bnRIb3ZlcihhcHAsICgpID0+IGFwcGxpY2F0aW9uLmJ1c3kgfHwgYXBwbGljYXRpb24uc2F2aW5nKTtcbmZ1bmN0aW9uIGJ1aWxkV29ya3NwYWNlKCkge1xuICBob3Zlci5pbnZhbGlkYXRlKCk7XG4gIHJlbmRlcmVyPy5kaXNwb3NlKCk7XG4gIHdvcmtzcGFjZT8uZGlzcG9zZSgpO1xuICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NhbnZhc2VzXCIpIS5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNpbnNwZWN0b3JcIikhLnJlcGxhY2VDaGlsZHJlbigpO1xuICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NvZGVcIikhLnJlcGxhY2VDaGlsZHJlbigpO1xuICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2FjdGlvbnNcIikhLnJlcGxhY2VDaGlsZHJlbigpO1xuICB3b3Jrc3BhY2UgPSBuZXcgV29ya3NwYWNlKGFwcGxpY2F0aW9uKTtcbiAgd29ya3NwYWNlLnJlZ2lzdGVyKGNhbnZhc1R5cGUpO1xuICB3b3Jrc3BhY2UucmVnaXN0ZXIoaW5zcGVjdG9yVHlwZSh3aWRnZXRzLCBsb2NhbGUpKTtcbiAgd29ya3NwYWNlLnJlZ2lzdGVyKFxuICAgIGFjdGlvbnNUeXBlKFxuICAgICAgYXBwbGljYXRpb24uY2F0YWxvZygpLm1hcCgoaXRlbSkgPT5cbiAgICAgICAgaXRlbS5yZWYubW9kdWxlSWQgPT09IEZJWEVEX1ZBTFVFU19QSU4ubW9kdWxlSWQgJiZcbiAgICAgICAgaXRlbS5yZWYudHlwZUlkID09PSBcImZsb2F0XCJcbiAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgICAgcHJlc2VudGF0aW9uOiB7XG4gICAgICAgICAgICAgICAgLi4uaXRlbS5wcmVzZW50YXRpb24sXG4gICAgICAgICAgICAgICAgbGFiZWw6IHtcbiAgICAgICAgICAgICAgICAgIC4uLml0ZW0ucHJlc2VudGF0aW9uLmxhYmVsLFxuICAgICAgICAgICAgICAgICAga2V5OiBcImZsb2F0LmF1dGhvcmluZ1wiLFxuICAgICAgICAgICAgICAgICAgZmFsbGJhY2s6IFwiRmxvYXQgKGZpeGVkKVwiLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9XG4gICAgICAgICAgOiBpdGVtLFxuICAgICAgKSxcbiAgICAgICgpID0+ICh7XG4gICAgICAgIHVuZG86IGFwcGxpY2F0aW9uLmNhblVuZG8sXG4gICAgICAgIHJlZG86IGFwcGxpY2F0aW9uLmNhblJlZG8sXG4gICAgICAgIGVkaXRpbmc6ICFhcHBsaWNhdGlvbi5yZWFkb25seSAmJiAhYXBwbGljYXRpb24uYnVzeSxcbiAgICAgIH0pLFxuICAgICksXG4gICk7XG4gIHdvcmtzcGFjZS5yZWdpc3RlcihcbiAgICBjb2RlVHlwZSgoKSA9PiAoe1xuICAgICAgY29tcGlsYXRpb246IGFwcGxpY2F0aW9uLmNvbXBpbGF0aW9uLFxuICAgICAgc25hcHNob3Q6IGFwcGxpY2F0aW9uLnNuYXBzaG90LFxuICAgIH0pKSxcbiAgKTtcbiAgY2FudmFzQ291bnQgPSAwO1xuICB3b3Jrc3BhY2Uub3Blbih7XG4gICAgaWQ6IFwiYWN0aW9uc1wiLFxuICAgIHR5cGVJZDogXCJncmFwZS5wYW5lbC5hY3Rpb25zXCIsXG4gICAgdmlld1N0YXRlVmVyc2lvbjogMSxcbiAgICBzdGF0ZToge30sXG4gICAgcGFuZUlkOiBcImFjdGlvbnNcIixcbiAgICBoaWRkZW46IGZhbHNlLFxuICB9KTtcbiAgd29ya3NwYWNlLm9wZW4oe1xuICAgIGlkOiBcImluc3BlY3RvclwiLFxuICAgIHR5cGVJZDogXCJncmFwZS5wYW5lbC5pbnNwZWN0b3JcIixcbiAgICB2aWV3U3RhdGVWZXJzaW9uOiAxLFxuICAgIHN0YXRlOiB7fSxcbiAgICBwYW5lSWQ6IFwiaW5zcGVjdG9yXCIsXG4gICAgaGlkZGVuOiBmYWxzZSxcbiAgfSk7XG4gIHdvcmtzcGFjZS5vcGVuKHtcbiAgICBpZDogXCJjb2RlXCIsXG4gICAgdHlwZUlkOiBcImdyYXBlLnBhbmVsLmNvZGVcIixcbiAgICB2aWV3U3RhdGVWZXJzaW9uOiAxLFxuICAgIHN0YXRlOiB7fSxcbiAgICBwYW5lSWQ6IFwiY29kZVwiLFxuICAgIGhpZGRlbjogZmFsc2UsXG4gIH0pO1xuICBhZGRDYW52YXMoKTtcbiAgcmVuZGVyZXIgPSBuZXcgUGFuZWxSZW5kZXJlcihcbiAgICB3b3Jrc3BhY2UsXG4gICAgbG9jYWxlLFxuICAgIChwYW5lLCBpZCkgPT4gKHtcbiAgICAgIHByb3RvY29sOiBcImdyYXBlLmRvbS52MVwiLFxuICAgICAgdGFyZ2V0OiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChwYW5lKSEsXG4gICAgfSksXG4gICAgZmVlZGJhY2ssXG4gICk7XG59XG5mdW5jdGlvbiBhZGRDYW52YXMoKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBhcHBsaWNhdGlvbi5jb250ZXh0KCksXG4gICAgaWQgPSBcImNhbnZhcy1cIiArICsrY2FudmFzQ291bnQ7XG4gIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzZWN0aW9uXCIpO1xuICBjb250YWluZXIuaWQgPSBpZDtcbiAgY29udGFpbmVyLmNsYXNzTmFtZSA9IFwiY2FudmFzLXBhbmVcIjtcbiAgY29uc3QgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICBsYWJlbC5jbGFzc05hbWUgPSBcInBhbmUtdGl0bGVcIjtcbiAgbGFiZWwudGV4dENvbnRlbnQgPSB0ZXh0KFwiY2FudmFzXCIsIHsgbnVtYmVyOiBjYW52YXNDb3VudCB9KTtcbiAgY29udGFpbmVyLmFwcGVuZChsYWJlbCk7XG4gIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjY2FudmFzZXNcIikhLmFwcGVuZChjb250YWluZXIpO1xuICB3b3Jrc3BhY2UhLm9wZW4oe1xuICAgIGlkLFxuICAgIHR5cGVJZDogY2FudmFzVHlwZS50eXBlSWQsXG4gICAgdmlld1N0YXRlVmVyc2lvbjogMSxcbiAgICBzdGF0ZToge30sXG4gICAgcGFuZUlkOiBpZCxcbiAgICBoaWRkZW46IGZhbHNlLFxuICAgIGNvbnRleHRJZDogY29udGV4dC5pZCxcbiAgfSk7XG4gIHdvcmtzcGFjZSEuYWN0aXZhdGUoaWQpO1xufVxuYXBwbGljYXRpb24uZ3JhbnQoY2FudmFzVHlwZS50eXBlSWQsIGNhbnZhc0NvbW1hbmRzKTtcbmFwcGxpY2F0aW9uLmdyYW50KFwiZ3JhcGUucGFuZWwuYWN0aW9uc1wiLCBbXG4gIFwiZ3JhcGUubm9kZS5hZGRcIixcbiAgXCJncmFwZS5ub2RlLmRlbGV0ZVwiLFxuICBcImdyYXBlLnVuZG9cIixcbiAgXCJncmFwZS5yZWRvXCIsXG5dKTtcbmFwcGxpY2F0aW9uLmdyYW50KFwiZ3JhcGUucGFuZWwuaW5zcGVjdG9yXCIsIFtcbiAgXCJncmFwZS5lZGdlLmRpc2Nvbm5lY3RcIixcbiAgXCJncmFwZS5ub2RlLnJlbmFtZVwiLFxuXSk7XG5jb25zdCByZXBsYWNpbmcgPSAoKSA9PiB7XG4gIGlmIChhcHBsaWNhdGlvbi5idXN5KSB0aHJvdyBFcnJvcih0ZXh0KFwiZ2VzdHVyZUJ1c3lcIikpO1xuICBpZiAod29ya3NwYWNlPy5yZWNvcmRzKCkuc29tZSgocikgPT4gci5pbnN0YW5jZSAmJiAhci5pbnN0YW5jZS5jYW5DbG9zZSgpKSlcbiAgICB0aHJvdyBFcnJvcih0ZXh0KFwiZHJhZnRCdXN5XCIpKTtcbiAgcmV0dXJuICFhcHBsaWNhdGlvbi5kaXJ0eSB8fCBjb25maXJtKHRleHQoXCJkaXNjYXJkXCIpKTtcbn07XG4vLyBEaXNwb3NlIHJvdXRlZCBwcmVzZW50YXRpb24gYmVmb3JlIHJlcGxhY2luZyBkb2N1bWVudCBsaWZldGltZXM7IHRoZSBuZXcgZG9jdW1lbnQgZ2V0cyBmcmVzaCBjb250ZXh0cy5cbmZ1bmN0aW9uIHByZXBhcmVSZXBsYWNlKCkge1xuICByZW5kZXJlcj8uZGlzcG9zZSgpO1xuICByZW5kZXJlciA9IG51bGw7XG4gIHdvcmtzcGFjZT8uZGlzcG9zZSgpO1xuICB3b3Jrc3BhY2UgPSBudWxsO1xufVxuYWN0aW9uKFwibmV3XCIsICgpID0+IHtcbiAgaWYgKCFyZXBsYWNpbmcoKSkgcmV0dXJuO1xuICBwcmVwYXJlUmVwbGFjZSgpO1xuICBhcHBsaWNhdGlvbi5uZXdEb2N1bWVudCgpO1xuICBidWlsZFdvcmtzcGFjZSgpO1xufSk7XG5jb25zdCB1cGdyYWRlQnV0dG9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcbnVwZ3JhZGVCdXR0b24udGV4dENvbnRlbnQgPSBcIlVwZ3JhZGUgc3ViZ3JhcGggb3duZXJzXCI7XG51cGdyYWRlQnV0dG9uLm9uY2xpY2sgPSAoKSA9PiB7XG4gIHRyeSB7XG4gICAgaWYgKCFyZXBsYWNpbmcoKSkgcmV0dXJuO1xuICAgIHByZXBhcmVSZXBsYWNlKCk7XG4gICAgYXBwbGljYXRpb24udXBncmFkZU93bmVycygpO1xuICAgIGJ1aWxkV29ya3NwYWNlKCk7XG4gICAgc2V0TWVzc2FnZShcbiAgICAgIFwiU3ViZ3JhcGggb3duZXJzIHVwZ3JhZGVkIGV4cGxpY2l0bHk7IGV4aXN0aW5nIGRlZmluaXRpb25zIHJlbWFpbiBleHBhbmRlZC4gU2F2ZSB0byByZXRhaW4gdGhlIHVwZ3JhZGVkIGRvY3VtZW50LlwiLFxuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmVwb3J0KGVycm9yKTtcbiAgfVxufTtcbm5hdi5hcHBlbmQodXBncmFkZUJ1dHRvbik7XG5jb25zdCBpbWFnZVVwZ3JhZGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpO1xuaW1hZ2VVcGdyYWRlLnRleHRDb250ZW50ID0gXCJVcGdyYWRlIEltYWdlIE91dHB1dFwiO1xuaW1hZ2VVcGdyYWRlLm9uY2xpY2sgPSAoKSA9PiB7XG4gIHRyeSB7XG4gICAgaWYgKCFyZXBsYWNpbmcoKSkgcmV0dXJuO1xuICAgIHByZXBhcmVSZXBsYWNlKCk7XG4gICAgYXBwbGljYXRpb24udXBncmFkZUdyYXBoS2luZCh6ZXJvSW1hZ2VLaW5kLnJlZik7XG4gICAgYnVpbGRXb3Jrc3BhY2UoKTtcbiAgICBzZXRNZXNzYWdlKFwiSW1hZ2UgT3V0cHV0IGFuZCBjb21wYXRpYmxlIGltYWdlIHNvdXJjZSBvd25lcnMgZXhwbGljaXRseSB1cGdyYWRlZCB0byAwLjMuMCBpbiBhIG5ldyBzZXNzaW9uLiBVbmNvbm5lY3RlZCBjb2xvciBpcyB0cmFuc3BhcmVudCB6ZXJvLiBTYXZlIHRvIHJldGFpbiB0aGlzIHZlcnNpb24uXCIpO1xuICB9IGNhdGNoIChlcnJvcikgeyByZXBvcnQoZXJyb3IpOyB9XG59O1xubmF2LmFwcGVuZChpbWFnZVVwZ3JhZGUpO1xuY29uc3Qgc2F2ZUJ1dHRvbiA9IGFjdGlvbihcInNhdmVcIiwgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBhcHBsaWNhdGlvbi5zYXZlKCk7XG4gIHN1Y2Nlc3ModGV4dChcInN0b3JlZFwiKSk7XG59KTtcbmFjdGlvbihcIm9wZW5cIiwgYXN5bmMgKCkgPT4ge1xuICBjb25zdCBsaXN0ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNzYXZlZC1saXN0XCIpITtcbiAgbGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgZm9yIChjb25zdCBlbnRyeSBvZiBhd2FpdCBhcHBsaWNhdGlvbi5zYXZlZERvY3VtZW50cygpKSB7XG4gICAgY29uc3QgYiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIik7XG4gICAgYi50ZXh0Q29udGVudCA9IGVudHJ5Lm5hbWU7XG4gICAgYi5kYXRhc2V0LmRvY3VtZW50S2V5ID0gZW50cnkua2V5O1xuICAgIGIub25jbGljayA9ICgpID0+IHtcbiAgICAgIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKCFyZXBsYWNpbmcoKSkgcmV0dXJuO1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhcHBsaWNhdGlvbi5yZW9wZW4oZW50cnkua2V5KTtcbiAgICAgICAgaWYgKHJlc3VsdC5zdGF0dXMgPT09IFwiZWRpdGFibGVcIikge1xuICAgICAgICAgIGJ1aWxkV29ya3NwYWNlKCk7XG4gICAgICAgICAgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjb3Blbi1kaWFsb2dcIikgYXMgSFRNTERpYWxvZ0VsZW1lbnQpLmNsb3NlKCk7XG4gICAgICAgIH0gZWxzZSByZWNvdmVyeShyZXN1bHQucmF3LCByZXN1bHQucmVhc29uKTtcbiAgICAgIH0pKCkuY2F0Y2gocmVwb3J0KTtcbiAgICB9O1xuICAgIGxpc3QuYXBwZW5kKGIpO1xuICB9XG4gIGlmICghbGlzdC5jaGlsZE5vZGVzLmxlbmd0aCkgbGlzdC50ZXh0Q29udGVudCA9IHRleHQoXCJub0RvY3VtZW50c1wiKTtcbiAgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjb3Blbi1kaWFsb2dcIikgYXMgSFRNTERpYWxvZ0VsZW1lbnQpLnNob3dNb2RhbCgpO1xufSk7XG5hY3Rpb24oXCJleHBvcnRcIiwgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBhcHBsaWNhdGlvbi5kb3dubG9hZCgpO1xuICBzdWNjZXNzKHRleHQoXCJleHBvcnRlZFwiKSk7XG59KTtcbmNvbnN0IHBuZ0RpYWxvZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaWFsb2dcIik7XG5jb25zdCBwbmdUaXRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJoMlwiKSxcbiAgcG5nSW1hZ2UgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW1nXCIpLFxuICBwbmdEb3dubG9hZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiksXG4gIHBuZ0Nsb3NlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcbnBuZ1RpdGxlLnRleHRDb250ZW50ID0gdGV4dChcInBuZ1RpdGxlXCIpO1xucG5nRG93bmxvYWQudGV4dENvbnRlbnQgPSB0ZXh0KFwicG5nRG93bmxvYWRcIik7XG5wbmdDbG9zZS50ZXh0Q29udGVudCA9IHRleHQoXCJjYW5jZWxcIik7XG5wbmdEaWFsb2cuc3R5bGUud2lkdGggPSBcIm1pbigxMTAwcHgsIDkwdncpXCI7XG5wbmdJbWFnZS5hbHQgPSB0ZXh0KFwicG5nVGl0bGVcIik7XG5wbmdJbWFnZS5zdHlsZS5tYXhXaWR0aCA9IFwiMTAwJVwiO1xucG5nSW1hZ2Uuc3R5bGUubWF4SGVpZ2h0ID0gXCI2NXZoXCI7XG5wbmdJbWFnZS5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xucG5nSW1hZ2Uuc3R5bGUubWFyZ2luID0gXCIwIGF1dG8gMTZweFwiO1xucG5nRGlhbG9nLmFwcGVuZChwbmdUaXRsZSwgcG5nSW1hZ2UsIHBuZ0Rvd25sb2FkLCBwbmdDbG9zZSk7XG5hcHAuYXBwZW5kKHBuZ0RpYWxvZyk7XG5sZXQgcG5nVGlja2V0ID0gMCxcbiAgcG5nVVJMID0gXCJcIixcbiAgcG5nQnl0ZXM6IFVpbnQ4QXJyYXkgfCBudWxsID0gbnVsbCxcbiAgcG5nTmFtZSA9IFwiXCI7XG5jb25zdCBjYW5jZWxQTkcgPSAoKSA9PiB7XG4gIHBuZ1RpY2tldCsrO1xuICBwbmdCeXRlcyA9IG51bGw7XG4gIGlmIChwbmdVUkwpIFVSTC5yZXZva2VPYmplY3RVUkwocG5nVVJMKTtcbiAgcG5nVVJMID0gXCJcIjtcbiAgcG5nSW1hZ2UucmVtb3ZlQXR0cmlidXRlKFwic3JjXCIpO1xuICBwbmdEaWFsb2cuY2xvc2UoKTtcbn07XG5wbmdDbG9zZS5vbmNsaWNrID0gY2FuY2VsUE5HO1xucG5nRGlhbG9nLmFkZEV2ZW50TGlzdGVuZXIoXCJjYW5jZWxcIiwgKGV2ZW50KSA9PiB7XG4gIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gIGNhbmNlbFBORygpO1xufSk7XG5wbmdEb3dubG9hZC5vbmNsaWNrID0gKCkgPT4ge1xuICBpZiAocG5nQnl0ZXMpXG4gICAgdm9pZCBkb3dubG9hZEJ5dGVzKHBuZ05hbWUsIHBuZ0J5dGVzLnNsaWNlKCkuYnVmZmVyKS5jYXRjaChyZXBvcnQpO1xufTtcbmFjdGlvbihcInBuZ1wiLCBhc3luYyAoKSA9PiB7XG4gIGNhbmNlbFBORygpO1xuICBjb25zdCB0aWNrZXQgPSBwbmdUaWNrZXQsXG4gICAgc25hcHNob3QgPSBhcHBsaWNhdGlvbi5zbmFwc2hvdDtcbiAgY29uc3QgcGFuZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY2FudmFzLXBhbmVcIik7XG4gIGNvbnN0IGxheW91dCA9IG5ldyBNYXA8c3RyaW5nLCB7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH0+KCk7XG4gIHBhbmU/LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KFwiLm5vZGVbZGF0YS1ub2RlXVwiKS5mb3JFYWNoKChub2RlKSA9PlxuICAgIGxheW91dC5zZXQobm9kZS5kYXRhc2V0Lm5vZGUhLCB7XG4gICAgICB3aWR0aDogbm9kZS5vZmZzZXRXaWR0aCxcbiAgICAgIGhlaWdodDogbm9kZS5vZmZzZXRIZWlnaHQsXG4gICAgfSksXG4gICk7XG4gIGNvbnN0IHN0YWdlID0gc25hcHNob3QuZG9jdW1lbnQuZ3JhcGguc3RhZ2VzLmZpbmQoKHMpID0+XG4gICAgcy5uZXR3b3JrLm5vZGVzLnNvbWUoKG4pID0+IGxheW91dC5oYXMobi5pZCkpLFxuICApO1xuICBpZiAoIXN0YWdlKSB0aHJvdyBFcnJvcihcIlBOR19MQVlPVVRfTUlTU0lOR1wiKTtcbiAgcG5nRG93bmxvYWQuZGlzYWJsZWQgPSB0cnVlO1xuICBwbmdEaWFsb2cuc2hvd01vZGFsKCk7XG4gIHRyeSB7XG4gICAgY29uc3QgYnl0ZXMgPSBhd2FpdCByZW5kZXJEb2N1bWVudFBORyhzbmFwc2hvdC5kb2N1bWVudCwgc3RhZ2UuaWQsIGxheW91dCk7XG4gICAgaWYgKHRpY2tldCAhPT0gcG5nVGlja2V0KSByZXR1cm47XG4gICAgcG5nQnl0ZXMgPSBieXRlcztcbiAgICBwbmdOYW1lID0gYCR7c25hcHNob3QuZG9jdW1lbnQuZ3JhcGgubmFtZX0tJHtzbmFwc2hvdC5kb2N1bWVudC5ncmFwaC5raW5kLmtpbmRJZH0tJHtzdGFnZS5rZXl9LnBuZ2A7XG4gICAgcG5nVVJMID0gVVJMLmNyZWF0ZU9iamVjdFVSTChcbiAgICAgIG5ldyBCbG9iKFtieXRlcy5zbGljZSgpLmJ1ZmZlcl0sIHsgdHlwZTogXCJpbWFnZS9wbmdcIiB9KSxcbiAgICApO1xuICAgIHBuZ0ltYWdlLnNyYyA9IHBuZ1VSTDtcbiAgICBwbmdEb3dubG9hZC5kaXNhYmxlZCA9IGZhbHNlO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGlmICh0aWNrZXQgPT09IHBuZ1RpY2tldCkge1xuICAgICAgY2FuY2VsUE5HKCk7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cbn0pO1xuY29uc3QgaW5wdXQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW5wdXRcIik7XG5pbnB1dC50eXBlID0gXCJmaWxlXCI7XG5pbnB1dC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIsIFwiT3BlbiBkb2N1bWVudCBmaWxlXCIpO1xuaW5wdXQuYWNjZXB0ID0gXCIuanNvbiwuZ3JhcGUuanNvbiwucG5nLGFwcGxpY2F0aW9uL2pzb24saW1hZ2UvcG5nXCI7XG5pbnB1dC5oaWRkZW4gPSB0cnVlO1xuYXBwLmFwcGVuZChpbnB1dCk7XG5hY3Rpb24oXCJmaWxlXCIsICgpID0+IHtcbiAgaW5wdXQuY2xpY2soKTtcbn0pO1xuaW5wdXQuYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCAoKSA9PiB7XG4gIHZvaWQgKGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBmaWxlID0gaW5wdXQuZmlsZXM/LlswXTtcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcbiAgICBjbG9zZVJldmlldygpO1xuICAgIGNvbnN0IHRpY2tldCA9IHJldmlld1RpY2tldDtcbiAgICBjb25zdCBiYXNlID0gYXBwbGljYXRpb24uc25hcHNob3Q7XG4gICAgcmVjb3ZlcnkoZmlsZSwgXCJSRUFESU5HX0lOUFVUXCIpO1xuICAgIGxldCBieXRlczogQXJyYXlCdWZmZXI7XG4gICAgdHJ5IHtcbiAgICAgIGJ5dGVzID0gYXdhaXQgZmlsZS5hcnJheUJ1ZmZlcigpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgaWYgKHRpY2tldCA9PT0gcmV2aWV3VGlja2V0KSByZWNvdmVyeShmaWxlLCBcIkZJTEVfUkVBRF9GQUlMRURcIik7XG4gICAgICBpbnB1dC52YWx1ZSA9IFwiXCI7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0aWNrZXQgIT09IHJldmlld1RpY2tldCkgcmV0dXJuO1xuICAgIGlmIChcbiAgICAgIGJhc2UubG9hZElkICE9PSBhcHBsaWNhdGlvbi5zbmFwc2hvdC5sb2FkSWQgfHxcbiAgICAgIGJhc2UucmV2aXNpb24gIT09IGFwcGxpY2F0aW9uLnNuYXBzaG90LnJldmlzaW9uXG4gICAgKSB7XG4gICAgICByZWNvdmVyeShieXRlcywgXCJPUEVOX1NVUEVSU0VERURcIik7XG4gICAgICBpbnB1dC52YWx1ZSA9IFwiXCI7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCByYXc6IHN0cmluZztcbiAgICB0cnkge1xuICAgICAgcmF3ID0gZGVjb2RlSW5wdXQobmV3IFVpbnQ4QXJyYXkoYnl0ZXMpLCBmaWxlLm5hbWUpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZWNvdmVyeShieXRlcywgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpKTtcbiAgICAgIGlucHV0LnZhbHVlID0gXCJcIjtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY3VycmVudFJldmlldyA9IGFwcGxpY2F0aW9uLmluc3BlY3RUZXh0KHJhdyk7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZWNvdmVyeSBoMlwiKSEudGV4dENvbnRlbnQgPSB0ZXh0KFwicmV2aWV3VGl0bGVcIik7XG4gICAgcmVjb3ZlcnkoYnl0ZXMsIGN1cnJlbnRSZXZpZXcuc3RhdHVzICsgXCI6IFwiICsgY3VycmVudFJldmlldy5yZWFzb24pO1xuICAgIHJldmlld0RldGFpbHMudGV4dENvbnRlbnQgPSBKU09OLnN0cmluZ2lmeShcbiAgICAgIHtcbiAgICAgICAgZGlhZ25vc3RpY3M6IGN1cnJlbnRSZXZpZXcuZGlhZ25vc3RpY3MsXG4gICAgICAgIHJlcGFpcnM6IGN1cnJlbnRSZXZpZXcucmVwYWlycyxcbiAgICAgICAgcHJvdmVuYW5jZTogY3VycmVudFJldmlldy5wcm92ZW5hbmNlLFxuICAgICAgICB1bmtub3duUGF0aHM6XG4gICAgICAgICAgY3VycmVudFJldmlldy5yZWFkLnN0YXR1cyA9PT0gXCJyZWNvdmVyeS1yZWFkb25seVwiXG4gICAgICAgICAgICA/IGN1cnJlbnRSZXZpZXcucmVhZC51bmtub3duUGF0aHNcbiAgICAgICAgICAgIDogW10sXG4gICAgICAgIGNhbmRpZGF0ZTogY3VycmVudFJldmlldy5jYW5kaWRhdGUsXG4gICAgICB9LFxuICAgICAgbnVsbCxcbiAgICAgIDIsXG4gICAgKTtcbiAgICByYXdQcmV2aWV3LnRleHRDb250ZW50ID0gcmF3LnNsaWNlKDAsIDEyMDAwKTtcbiAgICBsb2FkQnV0dG9uLmhpZGRlbiA9XG4gICAgICBjdXJyZW50UmV2aWV3LnJlYWQuc3RhdHVzICE9PSBcImVkaXRhYmxlXCIgfHxcbiAgICAgICFjdXJyZW50UmV2aWV3LmRvY3VtZW50IHx8XG4gICAgICBjdXJyZW50UmV2aWV3LnJlYXNvbiA9PT0gXCJORVRXT1JLX1NJWkVcIjtcbiAgICByZWZyZXNoUmVwbGFjZW1lbnQoKTtcbiAgICBpbnB1dC52YWx1ZSA9IFwiXCI7XG4gIH0pKCkuY2F0Y2gocmVwb3J0KTtcbn0pO1xuYWN0aW9uKFwiZ2VuZXJhdGVcIiwgKCkgPT4ge1xuICBjb25zdCByZXN1bHQgPSBhcHBsaWNhdGlvbi5nZW5lcmF0ZSgpO1xuICBpZiAocmVzdWx0LnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIpXG4gICAgdGhyb3cgRXJyb3IoXG4gICAgICByZXN1bHQuZGlhZ25vc3RpY3MubWFwKChkKSA9PiBkLmNvZGUgKyBcIjogXCIgKyBkLm1lc3NhZ2UpLmpvaW4oXCIgwrcgXCIpLFxuICAgICk7XG59KTtcbmFjdGlvbihcInNlY29uZFwiLCAoKSA9PiB7XG4gIGFkZENhbnZhcygpO1xufSk7XG5jb25zdCBsb2NrQnV0dG9uID0gYWN0aW9uKFwibG9ja1wiLCAoKSA9PlxuICBhcHBsaWNhdGlvbi5zZXRSZWFkb25seSghYXBwbGljYXRpb24ucmVhZG9ubHkpLFxuKTtcbmxvY2tCdXR0b24uc2V0QXR0cmlidXRlKFwiYXJpYS1jaGVja2VkXCIsIFwiZmFsc2VcIik7XG5sZXQgb3JpZ2luYWw6IHN0cmluZyB8IEFycmF5QnVmZmVyIHwgQmxvYiA9IFwiXCI7XG5sZXQgY3VycmVudFJldmlldzogRG9jdW1lbnRJbnNwZWN0aW9uIHwgbnVsbCA9IG51bGwsXG4gIHJldmlld1RpY2tldCA9IDA7XG5jb25zdCByZXZpZXdEaWFsb2cgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxEaWFsb2dFbGVtZW50PihcIiNyZWNvdmVyeVwiKSE7XG5yZXZpZXdEaWFsb2cuc3R5bGUud2lkdGggPSBcIm1pbig5MDBweCwgOTB2dylcIjtcbmNvbnN0IHJldmlld0RldGFpbHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwicHJlXCIpLFxuICByYXdQcmV2aWV3ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInByZVwiKSxcbiAgZXhwbGFuYXRpb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwicFwiKSxcbiAgcmVwbGFjZW1lbnRNZXNzYWdlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInBcIiksXG4gIGFjY2VwdEJ1dHRvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiksXG4gIGxvYWRCdXR0b24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpO1xucmV2aWV3RGV0YWlscy5zZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIsIHRleHQoXCJyZXZpZXdEZXRhaWxzXCIpKTtcbnJhd1ByZXZpZXcuc2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiLCB0ZXh0KFwib3JpZ2luYWxQcmV2aWV3XCIpKTtcbnJldmlld0RldGFpbHMuc3R5bGUubWF4SGVpZ2h0ID0gXCIzMHZoXCI7XG5yYXdQcmV2aWV3LnN0eWxlLm1heEhlaWdodCA9IFwiMTV2aFwiO1xucmV2aWV3RGV0YWlscy5zdHlsZS5vdmVyZmxvdyA9IHJhd1ByZXZpZXcuc3R5bGUub3ZlcmZsb3cgPSBcImF1dG9cIjtcbmV4cGxhbmF0aW9uLnRleHRDb250ZW50ID0gdGV4dChcImxvYWRFeHBsYW5hdGlvblwiKTtcbnJlcGxhY2VtZW50TWVzc2FnZS5pZCA9IFwicmVwbGFjZW1lbnQtbWVzc2FnZVwiO1xucmVwbGFjZW1lbnRNZXNzYWdlLnNldEF0dHJpYnV0ZShcInJvbGVcIiwgXCJzdGF0dXNcIik7XG5hY2NlcHRCdXR0b24udGV4dENvbnRlbnQgPSB0ZXh0KFwiYWNjZXB0SW1wb3J0XCIpO1xubG9hZEJ1dHRvbi50ZXh0Q29udGVudCA9IHRleHQoXCJvcGVuUHJlc2VydmVkXCIpO1xuYWNjZXB0QnV0dG9uLmhpZGRlbiA9IGxvYWRCdXR0b24uaGlkZGVuID0gdHJ1ZTtcbnJldmlld0RpYWxvZy5hcHBlbmQoXG4gIGV4cGxhbmF0aW9uLFxuICByZXZpZXdEZXRhaWxzLFxuICByYXdQcmV2aWV3LFxuICByZXBsYWNlbWVudE1lc3NhZ2UsXG4gIGFjY2VwdEJ1dHRvbixcbiAgbG9hZEJ1dHRvbixcbik7XG5mdW5jdGlvbiByZWZyZXNoUmVwbGFjZW1lbnQoKSB7XG4gIGlmICghY3VycmVudFJldmlldykge1xuICAgIHJlcGxhY2VtZW50TWVzc2FnZS50ZXh0Q29udGVudCA9IFwiXCI7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGVsaWdpYmlsaXR5ID0gYXBwbGljYXRpb24ucmVwbGFjZW1lbnRFbGlnaWJpbGl0eShjdXJyZW50UmV2aWV3KTtcbiAgYWNjZXB0QnV0dG9uLmhpZGRlbiA9ICFjdXJyZW50UmV2aWV3LmNhbmRpZGF0ZTtcbiAgYWNjZXB0QnV0dG9uLmRpc2FibGVkID0gIWVsaWdpYmlsaXR5LmF2YWlsYWJsZTtcbiAgY29uc3QgY29kZSA9IGVsaWdpYmlsaXR5LmF2YWlsYWJsZSA/IG51bGwgOiBlbGlnaWJpbGl0eS5jb2RlO1xuICByZXBsYWNlbWVudE1lc3NhZ2UudGV4dENvbnRlbnQgPSAhY3VycmVudFJldmlldy5jYW5kaWRhdGVcbiAgICA/IFwiXCJcbiAgICA6IGNvZGUgPT09IG51bGxcbiAgICAgID8gdGV4dChcInJlcGxhY2VSZWFkeVwiKVxuICAgICAgOiBjb2RlID09PSBcIklNUE9SVF9ERUZJTklUSU9OU1wiXG4gICAgICAgID8gdGV4dChcInJlcGxhY2VEZWZpbml0aW9uc1wiKVxuICAgICAgICA6IGNvZGUgPT09IFwiSU1QT1JUX1NUQUxFXCIgfHwgY29kZSA9PT0gXCJSRVZJRVdfQ0xPU0VEXCJcbiAgICAgICAgICA/IHRleHQoXCJyZXBsYWNlU3RhbGVcIiwgeyBjb2RlIH0pXG4gICAgICAgICAgOiBjb2RlID09PSBcIklNUE9SVF9SRUFET05MWVwiXG4gICAgICAgICAgICA/IHRleHQoXCJyZXBsYWNlUmVhZG9ubHlcIilcbiAgICAgICAgICAgIDogY29kZSA9PT0gXCJISVNUT1JZX0JVU1lcIlxuICAgICAgICAgICAgICA/IHRleHQoXCJyZXBsYWNlQnVzeVwiKVxuICAgICAgICAgICAgICA6IHRleHQoXCJyZXBsYWNlVW5hdmFpbGFibGVcIiwgeyBjb2RlIH0pO1xuICBsb2FkQnV0dG9uLmRpc2FibGVkID1cbiAgICBhcHBsaWNhdGlvbi5yZWFkb25seSB8fFxuICAgIGFwcGxpY2F0aW9uLmJ1c3kgfHxcbiAgICBjb2RlID09PSBcIklNUE9SVF9TVEFMRVwiIHx8XG4gICAgY29kZSA9PT0gXCJSRVZJRVdfQ0xPU0VEXCI7XG59XG5mdW5jdGlvbiBjbG9zZVJldmlldygpIHtcbiAgcmV2aWV3VGlja2V0Kys7XG4gIGlmIChjdXJyZW50UmV2aWV3KSBhcHBsaWNhdGlvbi5jYW5jZWxSZXZpZXcoY3VycmVudFJldmlldyk7XG4gIGN1cnJlbnRSZXZpZXcgPSBudWxsO1xuICByZXZpZXdEZXRhaWxzLnRleHRDb250ZW50ID0gcmF3UHJldmlldy50ZXh0Q29udGVudCA9IFwiXCI7XG4gIHJlcGxhY2VtZW50TWVzc2FnZS50ZXh0Q29udGVudCA9IFwiXCI7XG4gIGFjY2VwdEJ1dHRvbi5oaWRkZW4gPSBsb2FkQnV0dG9uLmhpZGRlbiA9IHRydWU7XG4gIHJldmlld0RpYWxvZy5jbG9zZSgpO1xuICBpbnB1dC52YWx1ZSA9IFwiXCI7XG59XG5yZXZpZXdEaWFsb2cuYWRkRXZlbnRMaXN0ZW5lcihcImNhbmNlbFwiLCAoZXZlbnQpID0+IHtcbiAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgY2xvc2VSZXZpZXcoKTtcbn0pO1xuYWNjZXB0QnV0dG9uLm9uY2xpY2sgPSAoKSA9PiB7XG4gIHRyeSB7XG4gICAgaWYgKHdvcmtzcGFjZT8ucmVjb3JkcygpLnNvbWUoKHIpID0+IHIuaW5zdGFuY2UgJiYgIXIuaW5zdGFuY2UuY2FuQ2xvc2UoKSkpXG4gICAgICB0aHJvdyBFcnJvcih0ZXh0KFwiZHJhZnRCdXN5XCIpKTtcbiAgICBpZiAoY3VycmVudFJldmlldykgYXBwbGljYXRpb24uYWNjZXB0UmV2aWV3KGN1cnJlbnRSZXZpZXcpO1xuICAgIGNsb3NlUmV2aWV3KCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZWNvdmVyeS1tZXNzYWdlXCIpIS50ZXh0Q29udGVudCA9XG4gICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcik7XG4gICAgcmVmcmVzaFJlcGxhY2VtZW50KCk7XG4gIH1cbn07XG5sb2FkQnV0dG9uLm9uY2xpY2sgPSAoKSA9PiB7XG4gIHRyeSB7XG4gICAgaWYgKCFjdXJyZW50UmV2aWV3IHx8ICFyZXBsYWNpbmcoKSkgcmV0dXJuO1xuICAgIGFwcGxpY2F0aW9uLm9wZW5SZXZpZXdlZChjdXJyZW50UmV2aWV3KTtcbiAgICBidWlsZFdvcmtzcGFjZSgpO1xuICAgIGNsb3NlUmV2aWV3KCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZWNvdmVyeS1tZXNzYWdlXCIpIS50ZXh0Q29udGVudCA9XG4gICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcik7XG4gIH1cbn07XG5mdW5jdGlvbiByZWNvdmVyeShyYXc6IHN0cmluZyB8IEFycmF5QnVmZmVyIHwgQmxvYiwgcmVhc29uOiBzdHJpbmcpIHtcbiAgb3JpZ2luYWwgPSByYXc7XG4gIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjcmVjb3ZlcnktbWVzc2FnZVwiKSEudGV4dENvbnRlbnQgPSB0ZXh0KFwicmVjb3ZlcnlcIiwge1xuICAgIHJlYXNvbixcbiAgfSk7XG4gIGlmICghcmV2aWV3RGlhbG9nLm9wZW4pIHJldmlld0RpYWxvZy5zaG93TW9kYWwoKTtcbn1cbmRvY3VtZW50XG4gIC5xdWVyeVNlbGVjdG9yKFwiI2V4cG9ydC1vcmlnaW5hbFwiKSFcbiAgLmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgXCJjbGlja1wiLFxuICAgICgpID0+IHZvaWQgZG93bmxvYWRCeXRlcyhcInJlY292ZXJ5LW9yaWdpbmFsLmpzb25cIiwgb3JpZ2luYWwpLFxuICApO1xuZG9jdW1lbnRcbiAgLnF1ZXJ5U2VsZWN0b3IoXCIjY2xvc2UtcmVjb3ZlcnlcIikhXG4gIC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgY2xvc2VSZXZpZXcpO1xuZG9jdW1lbnRcbiAgLnF1ZXJ5U2VsZWN0b3IoXCIjY2FuY2VsLW9wZW5cIikhXG4gIC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT5cbiAgICAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNvcGVuLWRpYWxvZ1wiKSBhcyBIVE1MRGlhbG9nRWxlbWVudCkuY2xvc2UoKSxcbiAgKTtcbmFwcGxpY2F0aW9uLnN1YnNjcmliZSgoKSA9PiB7XG4gIGhvdmVyLmludmFsaWRhdGUoKTtcbiAgcmVmcmVzaFJlcGxhY2VtZW50KCk7XG4gIHNhdmVTdGF0ZS50ZXh0Q29udGVudCA9IGFwcGxpY2F0aW9uLnNhdmluZ1xuICAgID8gdGV4dChcInNhdmluZ1wiKVxuICAgIDogYXBwbGljYXRpb24uZGlydHlcbiAgICAgID8gdGV4dChcImRpcnR5XCIpXG4gICAgICA6IHRleHQoXCJzYXZlZFwiKTtcbiAgc2F2ZUJ1dHRvbi5kaXNhYmxlZCA9IGFwcGxpY2F0aW9uLnNhdmluZztcbiAgbG9ja0J1dHRvbi5zZXRBdHRyaWJ1dGUoXCJhcmlhLWNoZWNrZWRcIiwgU3RyaW5nKGFwcGxpY2F0aW9uLnJlYWRvbmx5KSk7XG59KTtcbmFwcGxpY2F0aW9uLm5ld0RvY3VtZW50KCk7XG5idWlsZFdvcmtzcGFjZSgpO1xubW91bnRQZXJzb25hbChcbiAgbmF2LFxuICBhcHBsaWNhdGlvbixcbiAgKCkgPT4ge1xuICAgIGNvbnN0IGlkID0gd29ya3NwYWNlPy5yZWNvcmRzKCkuZmluZCgocikgPT4gci5zYXZlZC5pZCA9PT0gXCJpbnNwZWN0b3JcIilcbiAgICAgID8udXBkYXRlLnRhcmdldD8uc2NvcGUuY29udGV4dElkO1xuICAgIGlmICghaWQpIHRocm93IEVycm9yKFwiU2VsZWN0IGEgQ2FudmFzIGZpcnN0LlwiKTtcbiAgICByZXR1cm4gYXBwbGljYXRpb24uY29udGV4dChpZCk7XG4gIH0sXG4gIG5ldyBQZXJzb25hbExpYnJhcnkoXG4gICAgbmV3IEJyb3dzZXJMaWJyYXJ5U3RvcmUoKSxcbiAgICBkZWZpbml0aW9ucy5waW4oZGVmaW5pdGlvbnMucGlucygpKSxcbiAgICBmdW5jdGlvblByb2ZpbGUsXG4gICAgcHJvYmVEZWZpbml0aW9ucyxcbiAgKSxcbiAgKGVycm9yLCBvcGVyYXRpb24pID0+IHtcbiAgICBjb25zdCBrZXkgPSBcInBlcnNvbmFsOlwiICsgb3BlcmF0aW9uO1xuICAgIGlmIChlcnJvciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAoZXJyb3JzLmRlbGV0ZShrZXkpKSByZW5kZXJFcnJvcnMoKTtcbiAgICB9IGVsc2UgcmVwb3J0KGVycm9yLCBrZXkpO1xuICB9LFxuKTtcblxuLy8gRXhpc3RpbmcgZG9jdW1lbnQgY29tbWFuZHMga2VlcCB0aGVpciBvd24gaGFuZGxlcnMgYW5kIGd1YXJkczsgb25seSB0aGVpclxuLy8gcHJlc2VudGF0aW9uIG1vdmVzIGludG8gdGhlIHNoYXJlZCBvd25lZCBkaXNjbG9zdXJlLlxuY29uc3QgbWVudVRyaWdnZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpLFxuICBtZW51Q29udGVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksXG4gIGhpbnRzVHJpZ2dlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiksXG4gIGhpbnRzQ29udGVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG5tZW51VHJpZ2dlci50eXBlID0gXCJidXR0b25cIjtcbm1lbnVUcmlnZ2VyLnRleHRDb250ZW50ID0gXCJQcm9qZWN0IGFjdGlvbnNcIjtcbm1lbnVUcmlnZ2VyLmNsYXNzTmFtZSA9IFwicHJvamVjdC1hY3Rpb25zXCI7XG5tZW51Q29udGVudC5jbGFzc05hbWUgPSBcImZ1bmN0aW9uLWFjdGlvbnNcIjtcbm1lbnVDb250ZW50LnRhYkluZGV4ID0gLTE7XG5jb25zdCBkb2N1bWVudEdyb3VwID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSxcbiAgd29ya3NwYWNlR3JvdXAgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuZm9yIChjb25zdCBbZ3JvdXAsIGxhYmVsXSBvZiBbXG4gIFtkb2N1bWVudEdyb3VwLCBcIkRvY3VtZW50cyBhbmQgbGlicmFyeVwiXSxcbiAgW3dvcmtzcGFjZUdyb3VwLCBcIldvcmtzcGFjZVwiXSxcbl0gYXMgY29uc3QpIHtcbiAgZ3JvdXAuc2V0QXR0cmlidXRlKFwicm9sZVwiLCBcImdyb3VwXCIpO1xuICBncm91cC5hcmlhTGFiZWwgPSBsYWJlbDtcbiAgbWVudUNvbnRlbnQuYXBwZW5kKGdyb3VwKTtcbn1cbmZvciAoY29uc3QgY2hpbGQgb2YgQXJyYXkuZnJvbShuYXYuY2hpbGRyZW4pKSB7XG4gIGNvbnN0IGtleSA9IChjaGlsZCBhcyBIVE1MRWxlbWVudCkuZGF0YXNldC5hY3Rpb247XG4gIGlmICghKGNoaWxkIGluc3RhbmNlb2YgSFRNTEJ1dHRvbkVsZW1lbnQpKSBhcHAuYXBwZW5kKGNoaWxkKTtcbiAgZWxzZSBpZiAoa2V5ICE9PSBcInNhdmVcIiAmJiBrZXkgIT09IFwiZ2VuZXJhdGVcIikge1xuICAgIGNoaWxkLnNldEF0dHJpYnV0ZShcbiAgICAgIFwicm9sZVwiLFxuICAgICAga2V5ID09PSBcImxvY2tcIiA/IFwibWVudWl0ZW1jaGVja2JveFwiIDogXCJtZW51aXRlbVwiLFxuICAgICk7XG4gICAgKGtleSA9PT0gXCJzZWNvbmRcIiB8fCBrZXkgPT09IFwibG9ja1wiXG4gICAgICA/IHdvcmtzcGFjZUdyb3VwXG4gICAgICA6IGRvY3VtZW50R3JvdXBcbiAgICApLmFwcGVuZChjaGlsZCk7XG4gIH1cbn1cbmZvb3Rlci5wcmVwZW5kKG1lbnVUcmlnZ2VyKTtcbmNvbnN0IHByb2plY3RNZW51ID0gZmxvYXRpbmdTdXJmYWNlKHtcbiAgaG9zdDogYXBwLFxuICB0cmlnZ2VyOiBtZW51VHJpZ2dlcixcbiAgY29udGVudDogbWVudUNvbnRlbnQsXG4gIHRpdGxlOiBcIlByb2plY3QgYWN0aW9uc1wiLFxuICBjbG9zZUxhYmVsOiBcIkNsb3NlIHByb2plY3QgYWN0aW9uc1wiLFxuICBraW5kOiBcIm1lbnVcIixcbiAgd2lkdGg6IDMxMCxcbiAgbWF4SGVpZ2h0OiA1MjAsXG59KTtcbm1lbnVUcmlnZ2VyLm9uY2xpY2sgPSAoKSA9PiBwcm9qZWN0TWVudS50b2dnbGUoKTtcbm1lbnVDb250ZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZXZlbnQpID0+IHtcbiAgY29uc3QgYWN0aW9uID0gKGV2ZW50LnRhcmdldCBhcyBFbGVtZW50KS5jbG9zZXN0PEhUTUxCdXR0b25FbGVtZW50PihcImJ1dHRvblwiKVxuICAgID8uZGF0YXNldC5hY3Rpb247XG4gIC8vIERpYWxvZy1vcGVuaW5nIGNhbGxlcnMgcmV0YWluIHRoZWlyIHZpc2libGUgb3BlbmVyIHVudGlsIHRoZWlyIG93biBDbG9zZS5cbiAgaWYgKGFjdGlvbiAmJiBbXCJuZXdcIiwgXCJleHBvcnRcIiwgXCJmaWxlXCIsIFwic2Vjb25kXCIsIFwibG9ja1wiXS5pbmNsdWRlcyhhY3Rpb24pKVxuICAgIHByb2plY3RNZW51LmNsb3NlKGZhbHNlKTtcbn0pO1xuaGludHNUcmlnZ2VyLnR5cGUgPSBcImJ1dHRvblwiO1xuaGludHNUcmlnZ2VyLnRleHRDb250ZW50ID0gXCJIaW50c1wiO1xuaGludHNDb250ZW50LnRhYkluZGV4ID0gMDtcbmZvciAoY29uc3QgaGludCBvZiBBcnJheS5mcm9tKGZvb3Rlci5xdWVyeVNlbGVjdG9yQWxsKFwiOnNjb3BlID4gc3BhblwiKSkpXG4gIGhpbnRzQ29udGVudC5hcHBlbmQoaGludCk7XG5jb25zdCBpbnNwZWN0SGludCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuaW5zcGVjdEhpbnQudGV4dENvbnRlbnQgPVxuICBcIkYyIMK3IFJlYWQgdGhlIGZvY3VzZWQgb2JqZWN0IGluZm9ybWF0aW9uIChyZWFkLW9ubHkpLiBDbG9zZSBvciBFc2NhcGUgcmV0dXJucyBmb2N1cy5cIjtcbmhpbnRzQ29udGVudC5hcHBlbmQoaW5zcGVjdEhpbnQpO1xuZm9vdGVyLmFwcGVuZChoaW50c1RyaWdnZXIpO1xuY29uc3QgaGludHNWaWV3ID0gZmxvYXRpbmdTdXJmYWNlKHtcbiAgaG9zdDogYXBwLFxuICB0cmlnZ2VyOiBoaW50c1RyaWdnZXIsXG4gIGNvbnRlbnQ6IGhpbnRzQ29udGVudCxcbiAgdGl0bGU6IFwiV29ya3NwYWNlIGhpbnRzXCIsXG4gIGNsb3NlTGFiZWw6IFwiQ2xvc2UgaGludHNcIixcbiAga2luZDogXCJhbmNob3JlZFwiLFxuICB3aWR0aDogMzcwLFxuICBtYXhIZWlnaHQ6IDMwMCxcbiAgYWxpZ246IFwiZW5kXCIsXG59KTtcbmhpbnRzVHJpZ2dlci5vbmNsaWNrID0gKCkgPT4gaGludHNWaWV3LnRvZ2dsZSgpO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGtCQUFrQixnQkFBZ0IsZUFBZSxhQUFhLHNCQUFzQjtBQUM3RixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLFlBQVk7QUFDckIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxzQkFBc0I7QUFDL0I7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHdCQUF3QjtBQUNqQztBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsT0FDSztBQUNQLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsMkJBQTJCO0FBQ3BDLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMscUJBQXFCO0FBQzlCO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLFdBQVcsbUJBQW1CLHFCQUFxQjtBQUM1RCxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLFlBQVksZ0JBQWdCO0FBQ3JDO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLHlCQUF5QjtBQUVsQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHlCQUF5QjtBQUNsQztBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHNCQUFzQjtBQUMvQjtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLGVBQWUscUJBQXFCO0FBQzdDLFNBQVMsYUFBYSxtQkFBbUI7QUFDekMsU0FBUyxVQUFVLGdCQUFnQjtBQUNuQztBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxPQUNLO0FBRVAsTUFBTSxjQUFjLElBQUksWUFBWTtBQUNwQyxPQUFPLFFBQVEsQ0FBQyxNQUFNLFlBQVksY0FBYyxDQUFDLENBQUM7QUFDbEQsWUFBWSxTQUFTLFVBQVU7QUFDL0IsWUFBWSxTQUFTLFdBQVc7QUFDaEMsWUFBWSxTQUFTLGFBQWE7QUFDbEMsWUFBWSxTQUFTLFlBQVk7QUFDakMsWUFBWSxTQUFTLGNBQWM7QUFDbkMsWUFBWSxTQUFTLGdCQUFnQjtBQUNyQyxZQUFZLFNBQVMsa0JBQWtCO0FBQ3ZDLFlBQVksU0FBUyxVQUFVO0FBQy9CLFlBQVksYUFBYSxTQUFTO0FBQ2xDLFlBQVksU0FBUyxtQkFBbUI7QUFDeEMsWUFBWSxTQUFTLGlCQUFpQjtBQUN0QyxZQUFZLGFBQWEsZ0JBQWdCO0FBQ3pDLFlBQVksU0FBUyxnQkFBZ0I7QUFDckMsWUFBWSxTQUFTLGNBQWM7QUFDbkMsWUFBWSxhQUFhLGFBQWE7QUFDdEMsWUFBWSxTQUFTLFdBQVc7QUFDaEMsTUFBTSxTQUFTLElBQUksYUFBYTtBQUNoQyxPQUFPLGVBQWUsbUJBQW1CLGFBQWE7QUFDdEQsV0FBVyxnQkFBZ0I7QUFBQSxFQUN6QjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRjtBQUNFLFNBQU8sZUFBZSxhQUFhLGNBQWMsYUFBYSxRQUFRO0FBQ3hFLE1BQU0sT0FBTyxDQUNYLEtBQ0EsV0FDRyxPQUFPLFFBQVEsVUFBVSxLQUFLLE1BQU0sQ0FBQyxFQUFFO0FBQzVDLE1BQU0sV0FBVyxnQkFBZ0IsTUFBTTtBQUN2QyxNQUFNLFVBQVUsSUFBSSxlQUFlLFFBQVE7QUFDM0MsUUFBUSxTQUFTLFlBQVksQ0FBQyxNQUFNLEVBQUUsS0FBSyxTQUFTLE1BQU07QUFDMUQsUUFBUSxTQUFTLGNBQWMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxTQUFTLFFBQVE7QUFDOUQsUUFBUSxTQUFTLGNBQWMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxTQUFTLFFBQVE7QUFDOUQsUUFBUTtBQUFBLEVBQ047QUFBQSxFQUNBLENBQUMsTUFDQyxFQUFFLEtBQUssYUFBYSxXQUFXLHlCQUMvQixNQUFNLFFBQVEsRUFBRSxLQUFLO0FBQ3pCO0FBQ0EsTUFBTSxjQUFjLElBQUk7QUFBQSxFQUN0QjtBQUFBLEVBQ0EsZ0JBQWdCO0FBQUEsRUFDaEIsY0FBYztBQUFBLEVBQ2Q7QUFBQSxFQUNBLElBQUksZUFBZTtBQUFBLEVBQ25CO0FBQUEsRUFDQTtBQUNGO0FBQ0EsTUFBTSxNQUFNLFNBQVMsY0FBMkIsTUFBTTtBQUN0RCxJQUFJLFlBQ0Y7QUFDRixNQUFNLGFBQWE7QUFBQSxFQUNqQixDQUFDLGdCQUFnQixVQUFVO0FBQUEsRUFDM0IsQ0FBQyxTQUFTLFVBQVU7QUFBQSxFQUNwQixDQUFDLDJCQUEyQixhQUFhO0FBQUEsRUFDekMsQ0FBQywwQkFBMEIsWUFBWTtBQUFBLEVBQ3ZDLENBQUMsbUJBQW1CLFdBQVc7QUFBQSxFQUMvQixDQUFDLGdCQUFnQixRQUFRO0FBQUEsRUFDekIsQ0FBQyxnQkFBZ0IsZUFBZTtBQUFBLEVBQ2hDLENBQUMsb0JBQW9CLFVBQVU7QUFBQSxFQUMvQixDQUFDLG1CQUFtQixPQUFPO0FBQzdCO0FBQ0EsTUFBTSxjQUFjLE1BQU07QUFDeEIsYUFBVyxDQUFDLFVBQVUsR0FBRyxLQUFLO0FBQzVCLFFBQUksY0FBYyxRQUFRLEVBQUcsY0FBYyxLQUFLLEdBQUc7QUFDckQsTUFBSSxjQUFjLEtBQUssRUFBRyxhQUFhLGNBQWMsS0FBSyxpQkFBaUIsQ0FBQztBQUM5RTtBQUNBLFlBQVk7QUFDWixPQUFPLFVBQVUsV0FBVztBQUM1QixlQUFlLElBQUksY0FBMkIsUUFBUSxDQUFFO0FBQ3hELE1BQU0sYUFBYSxTQUFTLGNBQTJCLFVBQVUsR0FDL0QsVUFBVSxTQUFTLGNBQWMsUUFBUSxHQUN6QyxZQUFZLFNBQVMsY0FBYyxLQUFLLEdBQ3hDLE1BQU0sSUFBSSxjQUFjLEtBQUssR0FDN0IsWUFBWSxTQUFTLGNBQTJCLGFBQWE7QUFDL0QsUUFBUSxLQUFLO0FBQ2IsUUFBUSxPQUFPO0FBQ2YsUUFBUSxZQUFZO0FBQ3BCLFFBQVEsYUFBYSxpQkFBaUIsUUFBUTtBQUM5QyxVQUFVLFlBQVk7QUFDdEIsVUFBVSxhQUFhLFFBQVEsUUFBUTtBQUN2QyxXQUFXLFlBQVksU0FBUztBQUNoQyxVQUFVLE9BQU8sT0FBTztBQUN4QixJQUFJLGNBQWMsUUFBUSxFQUFHLE9BQU8sU0FBUztBQUM3QyxNQUFNLGFBQWEsU0FBUyxjQUFjLEtBQUs7QUFDL0MsV0FBVyxZQUFZO0FBQ3ZCLFdBQVcsV0FBVztBQUN0QixXQUFXLGFBQWEsUUFBUSxRQUFRO0FBQ3hDLFdBQVcsWUFBWTtBQUN2QixNQUFNLGFBQWEsZ0JBQWdCO0FBQUEsRUFDakMsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsU0FBUztBQUFBLEVBQ1QsT0FBTztBQUFBLEVBQ1AsWUFBWTtBQUFBLEVBQ1osTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsWUFBWSxNQUFNLENBQUMsQ0FBQyxRQUFRO0FBQUEsRUFDNUIsZUFBZSxNQUNiLElBQUksY0FBaUMsdUJBQXVCO0FBQ2hFLENBQUM7QUFDRCxNQUFNLGNBQWMsTUFBTSxXQUFXLE1BQU07QUFDM0MsUUFBUSxVQUFVLE1BQU07QUFDdEIsYUFBVyxjQUFjLFFBQVE7QUFDakMsYUFBVyxPQUFPO0FBQ3BCO0FBQ0EsTUFBTSxhQUFhLENBQUNBLFVBQWlCO0FBQ25DLFVBQVEsY0FBY0E7QUFDdEIsVUFBUSxXQUFXLENBQUNBO0FBQ3BCLGFBQVcsY0FBY0E7QUFDekIsTUFBSSxDQUFDQSxNQUFNLGFBQVk7QUFDekI7QUFDQSxXQUFXLEVBQUU7QUFDYixNQUFNLFNBQVMsb0JBQUksSUFBb0I7QUFDdkMsTUFBTSxVQUFVLENBQUNBLFVBQWlCO0FBQ2hDLE1BQUksQ0FBQyxPQUFPLEtBQU0sWUFBV0EsS0FBSTtBQUNuQztBQUNBLE1BQU0sZUFBZSxNQUFNO0FBQ3pCLGFBQVcsQ0FBQyxHQUFHLE9BQU8sT0FBTyxDQUFDLEVBQUUsS0FBSyxLQUFLLENBQUM7QUFDM0MsVUFBUSxVQUFVLE9BQU8sU0FBUyxDQUFDLENBQUMsT0FBTyxJQUFJO0FBQy9DLFlBQVUsYUFBYSxRQUFRLE9BQU8sT0FBTyxVQUFVLFFBQVE7QUFDakU7QUFDQSxNQUFNLFNBQVMsQ0FBQyxPQUFnQixNQUFNLGdCQUFnQjtBQUNwRCxTQUFPLElBQUksS0FBSyxpQkFBaUIsUUFBUSxNQUFNLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFDdEUsZUFBYTtBQUNmO0FBQ0EsTUFBTSxTQUFTLENBQ2IsS0FDQSxPQUNHO0FBQ0gsUUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0FBQzlDLFNBQU8sUUFBUSxTQUFTO0FBQ3hCLFFBQU0sU0FBaUM7QUFBQSxJQUNyQyxLQUFLO0FBQUEsSUFDTCxNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsSUFDUixLQUFLO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixRQUFRO0FBQUEsSUFDUixNQUFNO0FBQUEsRUFDUjtBQUNBLFFBQU0sZUFBZSxNQUNuQixPQUFPO0FBQUEsSUFDTCxLQUFLLE9BQU8sR0FBRyxLQUFLLFFBQVE7QUFBQSxJQUM1QixTQUFTLGVBQWUsS0FBSyxHQUFHLENBQUM7QUFBQSxFQUNuQztBQUNGLGVBQWE7QUFDYixTQUFPLFVBQVUsWUFBWTtBQUM3QixTQUFPLGlCQUFpQixTQUFTLE1BQU07QUFDckMsUUFBSTtBQUNGLGNBQVEsUUFBUSxHQUFHLENBQUMsRUFDakIsS0FBSyxNQUFNO0FBQ1YsWUFBSSxPQUFPLE9BQU8sR0FBRyxFQUFHLGNBQWE7QUFBQSxNQUN2QyxDQUFDLEVBQ0EsTUFBTSxDQUFDLFVBQVUsT0FBTyxPQUFPLEdBQUcsQ0FBQztBQUFBLElBQ3hDLFNBQVMsT0FBTztBQUNkLGFBQU8sT0FBTyxHQUFHO0FBQUEsSUFDbkI7QUFBQSxFQUNGLENBQUM7QUFDRCxNQUFJLE9BQU8sTUFBTTtBQUNqQixTQUFPO0FBQ1Q7QUFDQSxJQUFJLFlBQThCLE1BQ2hDLFdBQWlDLE1BQ2pDLGNBQWM7QUFDaEIsTUFBTSxTQUFTLElBQUksY0FBMkIsUUFBUTtBQUN0RCxNQUFNLGdCQUFnQixTQUFTLGNBQWMsUUFBUSxHQUNuRCxTQUFTLElBQUksY0FBMkIsT0FBTztBQUNqRCxjQUFjLE9BQU87QUFDckIsY0FBYyxjQUFjO0FBQzVCLE9BQU8sT0FBTyxhQUFhO0FBQzNCLE9BQU8sV0FBVztBQUNsQixNQUFNLGFBQWEsZ0JBQWdCO0FBQUEsRUFDakMsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsU0FBUztBQUFBLEVBQ1QsT0FBTztBQUFBLEVBQ1AsWUFBWTtBQUFBLEVBQ1osTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZ0JBQWdCO0FBQ2xCLENBQUM7QUFDRCxjQUFjLFVBQVUsTUFBTSxXQUFXLE9BQU87QUFDaEQsTUFBTSxRQUFRLFdBQVcsS0FBSyxNQUFNLFlBQVksUUFBUSxZQUFZLE1BQU07QUFDMUUsU0FBUyxpQkFBaUI7QUFDeEIsUUFBTSxXQUFXO0FBQ2pCLFlBQVUsUUFBUTtBQUNsQixhQUFXLFFBQVE7QUFDbkIsV0FBUyxjQUFjLFdBQVcsRUFBRyxnQkFBZ0I7QUFDckQsV0FBUyxjQUFjLFlBQVksRUFBRyxnQkFBZ0I7QUFDdEQsV0FBUyxjQUFjLE9BQU8sRUFBRyxnQkFBZ0I7QUFDakQsV0FBUyxjQUFjLFVBQVUsRUFBRyxnQkFBZ0I7QUFDcEQsY0FBWSxJQUFJLFVBQVUsV0FBVztBQUNyQyxZQUFVLFNBQVMsVUFBVTtBQUM3QixZQUFVLFNBQVMsY0FBYyxTQUFTLE1BQU0sQ0FBQztBQUNqRCxZQUFVO0FBQUEsSUFDUjtBQUFBLE1BQ0UsWUFBWSxRQUFRLEVBQUU7QUFBQSxRQUFJLENBQUMsU0FDekIsS0FBSyxJQUFJLGFBQWEsaUJBQWlCLFlBQ3ZDLEtBQUssSUFBSSxXQUFXLFVBQ2hCO0FBQUEsVUFDRSxHQUFHO0FBQUEsVUFDSCxjQUFjO0FBQUEsWUFDWixHQUFHLEtBQUs7QUFBQSxZQUNSLE9BQU87QUFBQSxjQUNMLEdBQUcsS0FBSyxhQUFhO0FBQUEsY0FDckIsS0FBSztBQUFBLGNBQ0wsVUFBVTtBQUFBLFlBQ1o7QUFBQSxVQUNGO0FBQUEsUUFDRixJQUNBO0FBQUEsTUFDTjtBQUFBLE1BQ0EsT0FBTztBQUFBLFFBQ0wsTUFBTSxZQUFZO0FBQUEsUUFDbEIsTUFBTSxZQUFZO0FBQUEsUUFDbEIsU0FBUyxDQUFDLFlBQVksWUFBWSxDQUFDLFlBQVk7QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsWUFBVTtBQUFBLElBQ1IsU0FBUyxPQUFPO0FBQUEsTUFDZCxhQUFhLFlBQVk7QUFBQSxNQUN6QixVQUFVLFlBQVk7QUFBQSxJQUN4QixFQUFFO0FBQUEsRUFDSjtBQUNBLGdCQUFjO0FBQ2QsWUFBVSxLQUFLO0FBQUEsSUFDYixJQUFJO0FBQUEsSUFDSixRQUFRO0FBQUEsSUFDUixrQkFBa0I7QUFBQSxJQUNsQixPQUFPLENBQUM7QUFBQSxJQUNSLFFBQVE7QUFBQSxJQUNSLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDRCxZQUFVLEtBQUs7QUFBQSxJQUNiLElBQUk7QUFBQSxJQUNKLFFBQVE7QUFBQSxJQUNSLGtCQUFrQjtBQUFBLElBQ2xCLE9BQU8sQ0FBQztBQUFBLElBQ1IsUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELFlBQVUsS0FBSztBQUFBLElBQ2IsSUFBSTtBQUFBLElBQ0osUUFBUTtBQUFBLElBQ1Isa0JBQWtCO0FBQUEsSUFDbEIsT0FBTyxDQUFDO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixRQUFRO0FBQUEsRUFDVixDQUFDO0FBQ0QsWUFBVTtBQUNWLGFBQVcsSUFBSTtBQUFBLElBQ2I7QUFBQSxJQUNBO0FBQUEsSUFDQSxDQUFDLE1BQU0sUUFBUTtBQUFBLE1BQ2IsVUFBVTtBQUFBLE1BQ1YsUUFBUSxTQUFTLGVBQWUsSUFBSTtBQUFBLElBQ3RDO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsWUFBWTtBQUNuQixRQUFNLFVBQVUsWUFBWSxRQUFRLEdBQ2xDLEtBQUssWUFBWSxFQUFFO0FBQ3JCLFFBQU0sWUFBWSxTQUFTLGNBQWMsU0FBUztBQUNsRCxZQUFVLEtBQUs7QUFDZixZQUFVLFlBQVk7QUFDdEIsUUFBTSxRQUFRLFNBQVMsY0FBYyxLQUFLO0FBQzFDLFFBQU0sWUFBWTtBQUNsQixRQUFNLGNBQWMsS0FBSyxVQUFVLEVBQUUsUUFBUSxZQUFZLENBQUM7QUFDMUQsWUFBVSxPQUFPLEtBQUs7QUFDdEIsV0FBUyxjQUFjLFdBQVcsRUFBRyxPQUFPLFNBQVM7QUFDckQsWUFBVyxLQUFLO0FBQUEsSUFDZDtBQUFBLElBQ0EsUUFBUSxXQUFXO0FBQUEsSUFDbkIsa0JBQWtCO0FBQUEsSUFDbEIsT0FBTyxDQUFDO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFDUixXQUFXLFFBQVE7QUFBQSxFQUNyQixDQUFDO0FBQ0QsWUFBVyxTQUFTLEVBQUU7QUFDeEI7QUFDQSxZQUFZLE1BQU0sV0FBVyxRQUFRLGNBQWM7QUFDbkQsWUFBWSxNQUFNLHVCQUF1QjtBQUFBLEVBQ3ZDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUNELFlBQVksTUFBTSx5QkFBeUI7QUFBQSxFQUN6QztBQUFBLEVBQ0E7QUFDRixDQUFDO0FBQ0QsTUFBTSxZQUFZLE1BQU07QUFDdEIsTUFBSSxZQUFZLEtBQU0sT0FBTSxNQUFNLEtBQUssYUFBYSxDQUFDO0FBQ3JELE1BQUksV0FBVyxRQUFRLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxTQUFTLFNBQVMsQ0FBQztBQUN2RSxVQUFNLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFDL0IsU0FBTyxDQUFDLFlBQVksU0FBUyxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQ3REO0FBRUEsU0FBUyxpQkFBaUI7QUFDeEIsWUFBVSxRQUFRO0FBQ2xCLGFBQVc7QUFDWCxhQUFXLFFBQVE7QUFDbkIsY0FBWTtBQUNkO0FBQ0EsT0FBTyxPQUFPLE1BQU07QUFDbEIsTUFBSSxDQUFDLFVBQVUsRUFBRztBQUNsQixpQkFBZTtBQUNmLGNBQVksWUFBWTtBQUN4QixpQkFBZTtBQUNqQixDQUFDO0FBQ0QsTUFBTSxnQkFBZ0IsU0FBUyxjQUFjLFFBQVE7QUFDckQsY0FBYyxjQUFjO0FBQzVCLGNBQWMsVUFBVSxNQUFNO0FBQzVCLE1BQUk7QUFDRixRQUFJLENBQUMsVUFBVSxFQUFHO0FBQ2xCLG1CQUFlO0FBQ2YsZ0JBQVksY0FBYztBQUMxQixtQkFBZTtBQUNmO0FBQUEsTUFDRTtBQUFBLElBQ0Y7QUFBQSxFQUNGLFNBQVMsT0FBTztBQUNkLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDRjtBQUNBLElBQUksT0FBTyxhQUFhO0FBQ3hCLE1BQU0sZUFBZSxTQUFTLGNBQWMsUUFBUTtBQUNwRCxhQUFhLGNBQWM7QUFDM0IsYUFBYSxVQUFVLE1BQU07QUFDM0IsTUFBSTtBQUNGLFFBQUksQ0FBQyxVQUFVLEVBQUc7QUFDbEIsbUJBQWU7QUFDZixnQkFBWSxpQkFBaUIsY0FBYyxHQUFHO0FBQzlDLG1CQUFlO0FBQ2YsZUFBVyxvS0FBb0s7QUFBQSxFQUNqTCxTQUFTLE9BQU87QUFBRSxXQUFPLEtBQUs7QUFBQSxFQUFHO0FBQ25DO0FBQ0EsSUFBSSxPQUFPLFlBQVk7QUFDdkIsTUFBTSxhQUFhLE9BQU8sUUFBUSxZQUFZO0FBQzVDLFFBQU0sWUFBWSxLQUFLO0FBQ3ZCLFVBQVEsS0FBSyxRQUFRLENBQUM7QUFDeEIsQ0FBQztBQUNELE9BQU8sUUFBUSxZQUFZO0FBQ3pCLFFBQU0sT0FBTyxTQUFTLGNBQWMsYUFBYTtBQUNqRCxPQUFLLGdCQUFnQjtBQUNyQixhQUFXLFNBQVMsTUFBTSxZQUFZLGVBQWUsR0FBRztBQUN0RCxVQUFNLElBQUksU0FBUyxjQUFjLFFBQVE7QUFDekMsTUFBRSxjQUFjLE1BQU07QUFDdEIsTUFBRSxRQUFRLGNBQWMsTUFBTTtBQUM5QixNQUFFLFVBQVUsTUFBTTtBQUNoQixZQUFNLFlBQVk7QUFDaEIsWUFBSSxDQUFDLFVBQVUsRUFBRztBQUNsQixjQUFNLFNBQVMsTUFBTSxZQUFZLE9BQU8sTUFBTSxHQUFHO0FBQ2pELFlBQUksT0FBTyxXQUFXLFlBQVk7QUFDaEMseUJBQWU7QUFDZixVQUFDLFNBQVMsY0FBYyxjQUFjLEVBQXdCLE1BQU07QUFBQSxRQUN0RSxNQUFPLFVBQVMsT0FBTyxLQUFLLE9BQU8sTUFBTTtBQUFBLE1BQzNDLEdBQUcsRUFBRSxNQUFNLE1BQU07QUFBQSxJQUNuQjtBQUNBLFNBQUssT0FBTyxDQUFDO0FBQUEsRUFDZjtBQUNBLE1BQUksQ0FBQyxLQUFLLFdBQVcsT0FBUSxNQUFLLGNBQWMsS0FBSyxhQUFhO0FBQ2xFLEVBQUMsU0FBUyxjQUFjLGNBQWMsRUFBd0IsVUFBVTtBQUMxRSxDQUFDO0FBQ0QsT0FBTyxVQUFVLFlBQVk7QUFDM0IsUUFBTSxZQUFZLFNBQVM7QUFDM0IsVUFBUSxLQUFLLFVBQVUsQ0FBQztBQUMxQixDQUFDO0FBQ0QsTUFBTSxZQUFZLFNBQVMsY0FBYyxRQUFRO0FBQ2pELE1BQU0sV0FBVyxTQUFTLGNBQWMsSUFBSSxHQUMxQyxXQUFXLFNBQVMsY0FBYyxLQUFLLEdBQ3ZDLGNBQWMsU0FBUyxjQUFjLFFBQVEsR0FDN0MsV0FBVyxTQUFTLGNBQWMsUUFBUTtBQUM1QyxTQUFTLGNBQWMsS0FBSyxVQUFVO0FBQ3RDLFlBQVksY0FBYyxLQUFLLGFBQWE7QUFDNUMsU0FBUyxjQUFjLEtBQUssUUFBUTtBQUNwQyxVQUFVLE1BQU0sUUFBUTtBQUN4QixTQUFTLE1BQU0sS0FBSyxVQUFVO0FBQzlCLFNBQVMsTUFBTSxXQUFXO0FBQzFCLFNBQVMsTUFBTSxZQUFZO0FBQzNCLFNBQVMsTUFBTSxVQUFVO0FBQ3pCLFNBQVMsTUFBTSxTQUFTO0FBQ3hCLFVBQVUsT0FBTyxVQUFVLFVBQVUsYUFBYSxRQUFRO0FBQzFELElBQUksT0FBTyxTQUFTO0FBQ3BCLElBQUksWUFBWSxHQUNkLFNBQVMsSUFDVCxXQUE4QixNQUM5QixVQUFVO0FBQ1osTUFBTSxZQUFZLE1BQU07QUFDdEI7QUFDQSxhQUFXO0FBQ1gsTUFBSSxPQUFRLEtBQUksZ0JBQWdCLE1BQU07QUFDdEMsV0FBUztBQUNULFdBQVMsZ0JBQWdCLEtBQUs7QUFDOUIsWUFBVSxNQUFNO0FBQ2xCO0FBQ0EsU0FBUyxVQUFVO0FBQ25CLFVBQVUsaUJBQWlCLFVBQVUsQ0FBQyxVQUFVO0FBQzlDLFFBQU0sZUFBZTtBQUNyQixZQUFVO0FBQ1osQ0FBQztBQUNELFlBQVksVUFBVSxNQUFNO0FBQzFCLE1BQUk7QUFDRixTQUFLLGNBQWMsU0FBUyxTQUFTLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxNQUFNO0FBQ3JFO0FBQ0EsT0FBTyxPQUFPLFlBQVk7QUFDeEIsWUFBVTtBQUNWLFFBQU0sU0FBUyxXQUNiLFdBQVcsWUFBWTtBQUN6QixRQUFNLE9BQU8sU0FBUyxjQUFjLGNBQWM7QUFDbEQsUUFBTSxTQUFTLG9CQUFJLElBQStDO0FBQ2xFLFFBQU0saUJBQThCLGtCQUFrQixFQUFFO0FBQUEsSUFBUSxDQUFDLFNBQy9ELE9BQU8sSUFBSSxLQUFLLFFBQVEsTUFBTztBQUFBLE1BQzdCLE9BQU8sS0FBSztBQUFBLE1BQ1osUUFBUSxLQUFLO0FBQUEsSUFDZixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sUUFBUSxTQUFTLFNBQVMsTUFBTSxPQUFPO0FBQUEsSUFBSyxDQUFDLE1BQ2pELEVBQUUsUUFBUSxNQUFNLEtBQUssQ0FBQyxNQUFNLE9BQU8sSUFBSSxFQUFFLEVBQUUsQ0FBQztBQUFBLEVBQzlDO0FBQ0EsTUFBSSxDQUFDLE1BQU8sT0FBTSxNQUFNLG9CQUFvQjtBQUM1QyxjQUFZLFdBQVc7QUFDdkIsWUFBVSxVQUFVO0FBQ3BCLE1BQUk7QUFDRixVQUFNLFFBQVEsTUFBTSxrQkFBa0IsU0FBUyxVQUFVLE1BQU0sSUFBSSxNQUFNO0FBQ3pFLFFBQUksV0FBVyxVQUFXO0FBQzFCLGVBQVc7QUFDWCxjQUFVLEdBQUcsU0FBUyxTQUFTLE1BQU0sSUFBSSxJQUFJLFNBQVMsU0FBUyxNQUFNLEtBQUssTUFBTSxJQUFJLE1BQU0sR0FBRztBQUM3RixhQUFTLElBQUk7QUFBQSxNQUNYLElBQUksS0FBSyxDQUFDLE1BQU0sTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQUEsSUFDeEQ7QUFDQSxhQUFTLE1BQU07QUFDZixnQkFBWSxXQUFXO0FBQUEsRUFDekIsU0FBUyxPQUFPO0FBQ2QsUUFBSSxXQUFXLFdBQVc7QUFDeEIsZ0JBQVU7QUFDVixZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsTUFBTSxRQUFRLFNBQVMsY0FBYyxPQUFPO0FBQzVDLE1BQU0sT0FBTztBQUNiLE1BQU0sYUFBYSxjQUFjLG9CQUFvQjtBQUNyRCxNQUFNLFNBQVM7QUFDZixNQUFNLFNBQVM7QUFDZixJQUFJLE9BQU8sS0FBSztBQUNoQixPQUFPLFFBQVEsTUFBTTtBQUNuQixRQUFNLE1BQU07QUFDZCxDQUFDO0FBQ0QsTUFBTSxpQkFBaUIsVUFBVSxNQUFNO0FBQ3JDLFFBQU0sWUFBWTtBQUNoQixVQUFNLE9BQU8sTUFBTSxRQUFRLENBQUM7QUFDNUIsUUFBSSxDQUFDLEtBQU07QUFDWCxnQkFBWTtBQUNaLFVBQU0sU0FBUztBQUNmLFVBQU0sT0FBTyxZQUFZO0FBQ3pCLGFBQVMsTUFBTSxlQUFlO0FBQzlCLFFBQUk7QUFDSixRQUFJO0FBQ0YsY0FBUSxNQUFNLEtBQUssWUFBWTtBQUFBLElBQ2pDLFFBQVE7QUFDTixVQUFJLFdBQVcsYUFBYyxVQUFTLE1BQU0sa0JBQWtCO0FBQzlELFlBQU0sUUFBUTtBQUNkO0FBQUEsSUFDRjtBQUNBLFFBQUksV0FBVyxhQUFjO0FBQzdCLFFBQ0UsS0FBSyxXQUFXLFlBQVksU0FBUyxVQUNyQyxLQUFLLGFBQWEsWUFBWSxTQUFTLFVBQ3ZDO0FBQ0EsZUFBUyxPQUFPLGlCQUFpQjtBQUNqQyxZQUFNLFFBQVE7QUFDZDtBQUFBLElBQ0Y7QUFDQSxRQUFJO0FBQ0osUUFBSTtBQUNGLFlBQU0sWUFBWSxJQUFJLFdBQVcsS0FBSyxHQUFHLEtBQUssSUFBSTtBQUFBLElBQ3BELFNBQVMsT0FBTztBQUNkLGVBQVMsT0FBTyxpQkFBaUIsUUFBUSxNQUFNLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFDdEUsWUFBTSxRQUFRO0FBQ2Q7QUFBQSxJQUNGO0FBQ0Esb0JBQWdCLFlBQVksWUFBWSxHQUFHO0FBQzNDLGFBQVMsY0FBYyxjQUFjLEVBQUcsY0FBYyxLQUFLLGFBQWE7QUFDeEUsYUFBUyxPQUFPLGNBQWMsU0FBUyxPQUFPLGNBQWMsTUFBTTtBQUNsRSxrQkFBYyxjQUFjLEtBQUs7QUFBQSxNQUMvQjtBQUFBLFFBQ0UsYUFBYSxjQUFjO0FBQUEsUUFDM0IsU0FBUyxjQUFjO0FBQUEsUUFDdkIsWUFBWSxjQUFjO0FBQUEsUUFDMUIsY0FDRSxjQUFjLEtBQUssV0FBVyxzQkFDMUIsY0FBYyxLQUFLLGVBQ25CLENBQUM7QUFBQSxRQUNQLFdBQVcsY0FBYztBQUFBLE1BQzNCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsZUFBVyxjQUFjLElBQUksTUFBTSxHQUFHLElBQUs7QUFDM0MsZUFBVyxTQUNULGNBQWMsS0FBSyxXQUFXLGNBQzlCLENBQUMsY0FBYyxZQUNmLGNBQWMsV0FBVztBQUMzQix1QkFBbUI7QUFDbkIsVUFBTSxRQUFRO0FBQUEsRUFDaEIsR0FBRyxFQUFFLE1BQU0sTUFBTTtBQUNuQixDQUFDO0FBQ0QsT0FBTyxZQUFZLE1BQU07QUFDdkIsUUFBTSxTQUFTLFlBQVksU0FBUztBQUNwQyxNQUFJLE9BQU8sV0FBVztBQUNwQixVQUFNO0FBQUEsTUFDSixPQUFPLFlBQVksSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLE9BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSyxLQUFLO0FBQUEsSUFDckU7QUFDSixDQUFDO0FBQ0QsT0FBTyxVQUFVLE1BQU07QUFDckIsWUFBVTtBQUNaLENBQUM7QUFDRCxNQUFNLGFBQWE7QUFBQSxFQUFPO0FBQUEsRUFBUSxNQUNoQyxZQUFZLFlBQVksQ0FBQyxZQUFZLFFBQVE7QUFDL0M7QUFDQSxXQUFXLGFBQWEsZ0JBQWdCLE9BQU87QUFDL0MsSUFBSSxXQUF3QztBQUM1QyxJQUFJLGdCQUEyQyxNQUM3QyxlQUFlO0FBQ2pCLE1BQU0sZUFBZSxTQUFTLGNBQWlDLFdBQVc7QUFDMUUsYUFBYSxNQUFNLFFBQVE7QUFDM0IsTUFBTSxnQkFBZ0IsU0FBUyxjQUFjLEtBQUssR0FDaEQsYUFBYSxTQUFTLGNBQWMsS0FBSyxHQUN6QyxjQUFjLFNBQVMsY0FBYyxHQUFHLEdBQ3hDLHFCQUFxQixTQUFTLGNBQWMsR0FBRyxHQUMvQyxlQUFlLFNBQVMsY0FBYyxRQUFRLEdBQzlDLGFBQWEsU0FBUyxjQUFjLFFBQVE7QUFDOUMsY0FBYyxhQUFhLGNBQWMsS0FBSyxlQUFlLENBQUM7QUFDOUQsV0FBVyxhQUFhLGNBQWMsS0FBSyxpQkFBaUIsQ0FBQztBQUM3RCxjQUFjLE1BQU0sWUFBWTtBQUNoQyxXQUFXLE1BQU0sWUFBWTtBQUM3QixjQUFjLE1BQU0sV0FBVyxXQUFXLE1BQU0sV0FBVztBQUMzRCxZQUFZLGNBQWMsS0FBSyxpQkFBaUI7QUFDaEQsbUJBQW1CLEtBQUs7QUFDeEIsbUJBQW1CLGFBQWEsUUFBUSxRQUFRO0FBQ2hELGFBQWEsY0FBYyxLQUFLLGNBQWM7QUFDOUMsV0FBVyxjQUFjLEtBQUssZUFBZTtBQUM3QyxhQUFhLFNBQVMsV0FBVyxTQUFTO0FBQzFDLGFBQWE7QUFBQSxFQUNYO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRjtBQUNBLFNBQVMscUJBQXFCO0FBQzVCLE1BQUksQ0FBQyxlQUFlO0FBQ2xCLHVCQUFtQixjQUFjO0FBQ2pDO0FBQUEsRUFDRjtBQUNBLFFBQU0sY0FBYyxZQUFZLHVCQUF1QixhQUFhO0FBQ3BFLGVBQWEsU0FBUyxDQUFDLGNBQWM7QUFDckMsZUFBYSxXQUFXLENBQUMsWUFBWTtBQUNyQyxRQUFNLE9BQU8sWUFBWSxZQUFZLE9BQU8sWUFBWTtBQUN4RCxxQkFBbUIsY0FBYyxDQUFDLGNBQWMsWUFDNUMsS0FDQSxTQUFTLE9BQ1AsS0FBSyxjQUFjLElBQ25CLFNBQVMsdUJBQ1AsS0FBSyxvQkFBb0IsSUFDekIsU0FBUyxrQkFBa0IsU0FBUyxrQkFDbEMsS0FBSyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsSUFDN0IsU0FBUyxvQkFDUCxLQUFLLGlCQUFpQixJQUN0QixTQUFTLGlCQUNQLEtBQUssYUFBYSxJQUNsQixLQUFLLHNCQUFzQixFQUFFLEtBQUssQ0FBQztBQUNqRCxhQUFXLFdBQ1QsWUFBWSxZQUNaLFlBQVksUUFDWixTQUFTLGtCQUNULFNBQVM7QUFDYjtBQUNBLFNBQVMsY0FBYztBQUNyQjtBQUNBLE1BQUksY0FBZSxhQUFZLGFBQWEsYUFBYTtBQUN6RCxrQkFBZ0I7QUFDaEIsZ0JBQWMsY0FBYyxXQUFXLGNBQWM7QUFDckQscUJBQW1CLGNBQWM7QUFDakMsZUFBYSxTQUFTLFdBQVcsU0FBUztBQUMxQyxlQUFhLE1BQU07QUFDbkIsUUFBTSxRQUFRO0FBQ2hCO0FBQ0EsYUFBYSxpQkFBaUIsVUFBVSxDQUFDLFVBQVU7QUFDakQsUUFBTSxlQUFlO0FBQ3JCLGNBQVk7QUFDZCxDQUFDO0FBQ0QsYUFBYSxVQUFVLE1BQU07QUFDM0IsTUFBSTtBQUNGLFFBQUksV0FBVyxRQUFRLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxTQUFTLFNBQVMsQ0FBQztBQUN2RSxZQUFNLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFDL0IsUUFBSSxjQUFlLGFBQVksYUFBYSxhQUFhO0FBQ3pELGdCQUFZO0FBQUEsRUFDZCxTQUFTLE9BQU87QUFDZCxhQUFTLGNBQWMsbUJBQW1CLEVBQUcsY0FDM0MsaUJBQWlCLFFBQVEsTUFBTSxVQUFVLE9BQU8sS0FBSztBQUN2RCx1QkFBbUI7QUFBQSxFQUNyQjtBQUNGO0FBQ0EsV0FBVyxVQUFVLE1BQU07QUFDekIsTUFBSTtBQUNGLFFBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUc7QUFDcEMsZ0JBQVksYUFBYSxhQUFhO0FBQ3RDLG1CQUFlO0FBQ2YsZ0JBQVk7QUFBQSxFQUNkLFNBQVMsT0FBTztBQUNkLGFBQVMsY0FBYyxtQkFBbUIsRUFBRyxjQUMzQyxpQkFBaUIsUUFBUSxNQUFNLFVBQVUsT0FBTyxLQUFLO0FBQUEsRUFDekQ7QUFDRjtBQUNBLFNBQVMsU0FBUyxLQUFrQyxRQUFnQjtBQUNsRSxhQUFXO0FBQ1gsV0FBUyxjQUFjLG1CQUFtQixFQUFHLGNBQWMsS0FBSyxZQUFZO0FBQUEsSUFDMUU7QUFBQSxFQUNGLENBQUM7QUFDRCxNQUFJLENBQUMsYUFBYSxLQUFNLGNBQWEsVUFBVTtBQUNqRDtBQUNBLFNBQ0csY0FBYyxrQkFBa0IsRUFDaEM7QUFBQSxFQUNDO0FBQUEsRUFDQSxNQUFNLEtBQUssY0FBYywwQkFBMEIsUUFBUTtBQUM3RDtBQUNGLFNBQ0csY0FBYyxpQkFBaUIsRUFDL0IsaUJBQWlCLFNBQVMsV0FBVztBQUN4QyxTQUNHLGNBQWMsY0FBYyxFQUM1QjtBQUFBLEVBQWlCO0FBQUEsRUFBUyxNQUN4QixTQUFTLGNBQWMsY0FBYyxFQUF3QixNQUFNO0FBQ3RFO0FBQ0YsWUFBWSxVQUFVLE1BQU07QUFDMUIsUUFBTSxXQUFXO0FBQ2pCLHFCQUFtQjtBQUNuQixZQUFVLGNBQWMsWUFBWSxTQUNoQyxLQUFLLFFBQVEsSUFDYixZQUFZLFFBQ1YsS0FBSyxPQUFPLElBQ1osS0FBSyxPQUFPO0FBQ2xCLGFBQVcsV0FBVyxZQUFZO0FBQ2xDLGFBQVcsYUFBYSxnQkFBZ0IsT0FBTyxZQUFZLFFBQVEsQ0FBQztBQUN0RSxDQUFDO0FBQ0QsWUFBWSxZQUFZO0FBQ3hCLGVBQWU7QUFDZjtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQSxNQUFNO0FBQ0osVUFBTSxLQUFLLFdBQVcsUUFBUSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxPQUFPLFdBQVcsR0FDbEUsT0FBTyxRQUFRLE1BQU07QUFDekIsUUFBSSxDQUFDLEdBQUksT0FBTSxNQUFNLHdCQUF3QjtBQUM3QyxXQUFPLFlBQVksUUFBUSxFQUFFO0FBQUEsRUFDL0I7QUFBQSxFQUNBLElBQUk7QUFBQSxJQUNGLElBQUksb0JBQW9CO0FBQUEsSUFDeEIsWUFBWSxJQUFJLFlBQVksS0FBSyxDQUFDO0FBQUEsSUFDbEM7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EsQ0FBQyxPQUFPLGNBQWM7QUFDcEIsVUFBTSxNQUFNLGNBQWM7QUFDMUIsUUFBSSxVQUFVLFFBQVc7QUFDdkIsVUFBSSxPQUFPLE9BQU8sR0FBRyxFQUFHLGNBQWE7QUFBQSxJQUN2QyxNQUFPLFFBQU8sT0FBTyxHQUFHO0FBQUEsRUFDMUI7QUFDRjtBQUlBLE1BQU0sY0FBYyxTQUFTLGNBQWMsUUFBUSxHQUNqRCxjQUFjLFNBQVMsY0FBYyxLQUFLLEdBQzFDLGVBQWUsU0FBUyxjQUFjLFFBQVEsR0FDOUMsZUFBZSxTQUFTLGNBQWMsS0FBSztBQUM3QyxZQUFZLE9BQU87QUFDbkIsWUFBWSxjQUFjO0FBQzFCLFlBQVksWUFBWTtBQUN4QixZQUFZLFlBQVk7QUFDeEIsWUFBWSxXQUFXO0FBQ3ZCLE1BQU0sZ0JBQWdCLFNBQVMsY0FBYyxLQUFLLEdBQ2hELGlCQUFpQixTQUFTLGNBQWMsS0FBSztBQUMvQyxXQUFXLENBQUMsT0FBTyxLQUFLLEtBQUs7QUFBQSxFQUMzQixDQUFDLGVBQWUsdUJBQXVCO0FBQUEsRUFDdkMsQ0FBQyxnQkFBZ0IsV0FBVztBQUM5QixHQUFZO0FBQ1YsUUFBTSxhQUFhLFFBQVEsT0FBTztBQUNsQyxRQUFNLFlBQVk7QUFDbEIsY0FBWSxPQUFPLEtBQUs7QUFDMUI7QUFDQSxXQUFXLFNBQVMsTUFBTSxLQUFLLElBQUksUUFBUSxHQUFHO0FBQzVDLFFBQU0sTUFBTyxNQUFzQixRQUFRO0FBQzNDLE1BQUksRUFBRSxpQkFBaUIsbUJBQW9CLEtBQUksT0FBTyxLQUFLO0FBQUEsV0FDbEQsUUFBUSxVQUFVLFFBQVEsWUFBWTtBQUM3QyxVQUFNO0FBQUEsTUFDSjtBQUFBLE1BQ0EsUUFBUSxTQUFTLHFCQUFxQjtBQUFBLElBQ3hDO0FBQ0EsS0FBQyxRQUFRLFlBQVksUUFBUSxTQUN6QixpQkFDQSxlQUNGLE9BQU8sS0FBSztBQUFBLEVBQ2hCO0FBQ0Y7QUFDQSxPQUFPLFFBQVEsV0FBVztBQUMxQixNQUFNLGNBQWMsZ0JBQWdCO0FBQUEsRUFDbEMsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsU0FBUztBQUFBLEVBQ1QsT0FBTztBQUFBLEVBQ1AsWUFBWTtBQUFBLEVBQ1osTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLEVBQ1AsV0FBVztBQUNiLENBQUM7QUFDRCxZQUFZLFVBQVUsTUFBTSxZQUFZLE9BQU87QUFDL0MsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLFVBQVU7QUFDL0MsUUFBTUMsVUFBVSxNQUFNLE9BQW1CLFFBQTJCLFFBQVEsR0FDeEUsUUFBUTtBQUVaLE1BQUlBLFdBQVUsQ0FBQyxPQUFPLFVBQVUsUUFBUSxVQUFVLE1BQU0sRUFBRSxTQUFTQSxPQUFNO0FBQ3ZFLGdCQUFZLE1BQU0sS0FBSztBQUMzQixDQUFDO0FBQ0QsYUFBYSxPQUFPO0FBQ3BCLGFBQWEsY0FBYztBQUMzQixhQUFhLFdBQVc7QUFDeEIsV0FBVyxRQUFRLE1BQU0sS0FBSyxPQUFPLGlCQUFpQixlQUFlLENBQUM7QUFDcEUsZUFBYSxPQUFPLElBQUk7QUFDMUIsTUFBTSxjQUFjLFNBQVMsY0FBYyxNQUFNO0FBQ2pELFlBQVksY0FDVjtBQUNGLGFBQWEsT0FBTyxXQUFXO0FBQy9CLE9BQU8sT0FBTyxZQUFZO0FBQzFCLE1BQU0sWUFBWSxnQkFBZ0I7QUFBQSxFQUNoQyxNQUFNO0FBQUEsRUFDTixTQUFTO0FBQUEsRUFDVCxTQUFTO0FBQUEsRUFDVCxPQUFPO0FBQUEsRUFDUCxZQUFZO0FBQUEsRUFDWixNQUFNO0FBQUEsRUFDTixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQ1QsQ0FBQztBQUNELGFBQWEsVUFBVSxNQUFNLFVBQVUsT0FBTzsiLCJuYW1lcyI6WyJ0ZXh0IiwiYWN0aW9uIl19